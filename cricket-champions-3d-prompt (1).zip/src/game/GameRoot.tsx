import { useEffect } from "react";
import { useGameStore } from "./state/store";
import { MainMenu } from "./components/screens/MainMenu";
import { QuickMatchSetup } from "./components/screens/QuickMatchSetup";
import { TossScreen } from "./components/screens/TossScreen";
import { MatchIntro } from "./components/screens/MatchIntro";
import { MatchScreen } from "./components/screens/MatchScreen";
import { InningsBreak } from "./components/screens/InningsBreak";
import { MatchResult } from "./components/screens/MatchResult";
import { Scorecard } from "./components/screens/Scorecard";
import { SettingsScreen } from "./components/screens/Settings";
import { CareerScreen } from "./components/screens/Career";
import { TournamentScreen } from "./components/screens/Tournament";
import { PracticeScreen } from "./components/screens/Practice";
import { ChallengesScreen } from "./components/screens/Challenges";
import { TutorialScreen } from "./components/screens/Tutorial";
import { RosterEditorScreen } from "./components/screens/RosterEditor";
import { PauseOverlay } from "./components/match/PauseOverlay";

export function GameRoot() {
  const screen = useGameStore((s) => s.screen);
  const init = useGameStore((s) => s.init);
  const isPaused = useGameStore((s) => s.isPaused);

  useEffect(() => {
    init();
  }, [init]);

  let content;
  switch (screen) {
    case "menu":
      content = <MainMenu />;
      break;
    case "team-select":
    case "stadium-select":
    case "format-select":
    case "local-multiplayer-setup":
      content = <QuickMatchSetup />;
      break;
    case "toss":
      content = <TossScreen />;
      break;
    case "intro":
      content = <MatchIntro />;
      break;
    case "innings":
      content = <MatchScreen chrome="innings" />;
      break;
    case "innings-break":
      content = <InningsBreak />;
      break;
    case "result":
    case "super-over":
      content = <MatchResult />;
      break;
    case "scorecard":
      content = <Scorecard />;
      break;
    case "settings":
      content = <SettingsScreen />;
      break;
    case "career":
    case "career-create":
      content = <CareerScreen />;
      break;
    case "tournament":
      content = <TournamentScreen />;
      break;
    case "practice":
      content = <PracticeScreen />;
      break;
    case "challenges":
    case "challenge-play":
      content = <ChallengesScreen />;
      break;
    case "tutorial":
      content = <TutorialScreen />;
      break;
    case "roster-editor":
      content = <RosterEditorScreen />;
      break;
    default:
      content = <MainMenu />;
  }

  return (
    <div className="font-sans">
      {content}
      {isPaused && <PauseOverlay />}
    </div>
  );
}
