import { Stadium } from "./types";

// 12+ data-driven stadiums (StadiumSO equivalent). No logos/trademarks used —
// generic ad-board colors only. Names reference real grounds for flavor per the
// brief; a "Use Real Names" toggle (see settings) can rename these to a fictional
// safe set for public release (see FICTIONAL_STADIUM_NAMES below).
export const STADIUMS: Stadium[] = [
  { id: "wankhede", name: "Wankhede Stadium", city: "Mumbai", capacity: 33000, boundaryStraight: 65, boundarySquare: 62, pitchType: "Flat", pitchTendency: "Batting-friendly, dew at night", lighting: "Night", primaryColor: "#1d4ed8", secondaryColor: "#facc15", dewFactor: 0.7 },
  { id: "eden", name: "Eden Gardens", city: "Kolkata", capacity: 66000, boundaryStraight: 68, boundarySquare: 65, pitchType: "Dry", pitchTendency: "Big crowd, spins later", lighting: "Evening", primaryColor: "#15803d", secondaryColor: "#fbbf24", dewFactor: 0.4 },
  { id: "modi", name: "Narendra Modi Stadium", city: "Ahmedabad", capacity: 132000, boundaryStraight: 70, boundarySquare: 68, pitchType: "Cracked", pitchTendency: "Large ground, black/red soil mix", lighting: "Day", primaryColor: "#dc2626", secondaryColor: "#1e3a8a", dewFactor: 0.3 },
  { id: "mcg", name: "MCG", city: "Melbourne", capacity: 100000, boundaryStraight: 75, boundarySquare: 72, pitchType: "Flat", pitchTendency: "Huge boundaries, pace and bounce", lighting: "Day", primaryColor: "#166534", secondaryColor: "#eab308", dewFactor: 0.1 },
  { id: "scg", name: "SCG", city: "Sydney", capacity: 48000, boundaryStraight: 64, boundarySquare: 63, pitchType: "Dry", pitchTendency: "Spin-friendly late", lighting: "Day", primaryColor: "#0891b2", secondaryColor: "#f1f5f9", dewFactor: 0.15 },
  { id: "lords", name: "Lord's", city: "London", capacity: 30000, boundaryStraight: 67, boundarySquare: 64, pitchType: "Green", pitchTendency: "Slope, seam and swing", lighting: "Day", primaryColor: "#7f1d1d", secondaryColor: "#f8fafc", dewFactor: 0.1 },
  { id: "oval", name: "The Oval", city: "London", capacity: 25500, boundaryStraight: 66, boundarySquare: 63, pitchType: "Green", pitchTendency: "Pace early, spin later", lighting: "Day", primaryColor: "#1e3a8a", secondaryColor: "#fbbf24", dewFactor: 0.1 },
  { id: "gaddafi", name: "Gaddafi Stadium", city: "Lahore", capacity: 27000, boundaryStraight: 63, boundarySquare: 60, pitchType: "Flat", pitchTendency: "Batting-friendly", lighting: "Evening", primaryColor: "#0b6623", secondaryColor: "#ffffff", dewFactor: 0.3 },
  { id: "karachi", name: "National Stadium", city: "Karachi", capacity: 34000, boundaryStraight: 68, boundarySquare: 65, pitchType: "Flat", pitchTendency: "True pace and bounce", lighting: "Day", primaryColor: "#0b6623", secondaryColor: "#facc15", dewFactor: 0.2 },
  { id: "newlands", name: "Newlands", city: "Cape Town", capacity: 25000, boundaryStraight: 64, boundarySquare: 61, pitchType: "Green", pitchTendency: "Seam and swing", lighting: "Day", primaryColor: "#065f46", secondaryColor: "#fbbf24", dewFactor: 0.2 },
  { id: "wanderers", name: "Wanderers", city: "Johannesburg", capacity: 34000, boundaryStraight: 70, boundarySquare: 67, pitchType: "Flat", pitchTendency: "High altitude, fast outfield", lighting: "Day", primaryColor: "#facc15", secondaryColor: "#111827", dewFactor: 0.15 },
  { id: "galle", name: "Galle International Stadium", city: "Galle", capacity: 35000, boundaryStraight: 62, boundarySquare: 60, pitchType: "Dry", pitchTendency: "Dry, big turn", lighting: "Day", primaryColor: "#1e40af", secondaryColor: "#facc15", dewFactor: 0.2 },
  { id: "dubai", name: "Dubai International Stadium", city: "Dubai", capacity: 25000, boundaryStraight: 65, boundarySquare: 62, pitchType: "Dry", pitchTendency: "Slow-low, spin", lighting: "Night", primaryColor: "#b91c1c", secondaryColor: "#f8fafc", dewFactor: 0.5 },
  { id: "sharjah", name: "Sharjah Cricket Stadium", city: "Sharjah", capacity: 16000, boundaryStraight: 58, boundarySquare: 56, pitchType: "Dry", pitchTendency: "Small, slow, spin", lighting: "Night", primaryColor: "#065f46", secondaryColor: "#f8fafc", dewFactor: 0.6 },
  { id: "kensington", name: "Kensington Oval", city: "Bridgetown", capacity: 28000, boundaryStraight: 66, boundarySquare: 63, pitchType: "Flat", pitchTendency: "True bounce, fast outfield", lighting: "Day", primaryColor: "#7f1d1d", secondaryColor: "#fbbf24", dewFactor: 0.2 },
  { id: "hagley", name: "Hagley Oval", city: "Christchurch", capacity: 20000, boundaryStraight: 64, boundarySquare: 61, pitchType: "Green", pitchTendency: "Seam-friendly", lighting: "Day", primaryColor: "#111827", secondaryColor: "#f8fafc", dewFactor: 0.15 },
  { id: "mirpur", name: "Sher-e-Bangla", city: "Mirpur", capacity: 25000, boundaryStraight: 60, boundarySquare: 58, pitchType: "Dry", pitchTendency: "Slow turner", lighting: "Evening", primaryColor: "#065f46", secondaryColor: "#dc2626", dewFactor: 0.4 },
];

// Licence-safe fictional name mapping used when "Use Real Names" is off.
export const FICTIONAL_STADIUM_NAMES: Record<string, string> = {
  wankhede: "Coastal City Arena",
  eden: "Garden City Grounds",
  modi: "Riverside Colossus",
  mcg: "Southern Cross Stadium",
  scg: "Harbour Bowl",
  lords: "Old Ground",
  oval: "Thames Park",
  gaddafi: "Gate City Stadium",
  karachi: "Coastal Arena South",
  newlands: "Vineyard Park",
  wanderers: "Highveld Arena",
  galle: "Fort Stadium",
  dubai: "Desert Dome",
  sharjah: "Oasis Ground",
  kensington: "Island Bowl",
  hagley: "Garden Park South",
  mirpur: "Delta Stadium",
};

export function getStadium(id: string): Stadium {
  const s = STADIUMS.find((x) => x.id === id);
  if (!s) {
    console.warn(`[StadiumLoader] Stadium ${id} not found, falling back to default.`);
    return STADIUMS[0];
  }
  return s;
}
