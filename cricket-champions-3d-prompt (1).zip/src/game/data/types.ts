// Core data types for Cricket Champions 3D
// All gameplay data (teams, players, stadiums, formats, difficulty) is data-driven,
// loaded from these TS data modules (acting as our "ScriptableObjects" / JSON rosters
// equivalent inside a web build). Nothing here is hardcoded into game logic.

export type Role =
  | "Opener"
  | "Top Order"
  | "Middle Order"
  | "Finisher"
  | "WK-Batter"
  | "Allrounder"
  | "Fast"
  | "Spinner";

export type BattingHand = "Right" | "Left";
export type BowlingHand = "Right" | "Left" | "None";
export type BowlingType =
  | "Fast"
  | "Fast-Medium"
  | "Medium"
  | "Off Spin"
  | "Leg Spin"
  | "Left-Arm Orthodox"
  | "Left-Arm Wrist"
  | "Left-Arm Fast"
  | "None";

export interface PlayerRatings {
  power: number;
  timing: number;
  technique: number;
  running: number;
  sixHitting: number;
  vsPace: number;
  vsSpin: number;
  pace: number;
  swing: number;
  seam: number;
  spin: number;
  accuracy: number;
  variation: number;
  stamina: number;
  catching: number;
  throwing: number;
  fieldSpeed: number;
  reaction: number;
  temperament: number;
  form: number;
  fitness: number;
}

export interface Player {
  id: string;
  displayName: string;
  shortName: string;
  teamId: string;
  role: Role;
  tags: Array<"WK" | "AR" | "F" | "S" | "C" | "VC">;
  battingHand: BattingHand;
  bowlingHand: BowlingHand;
  bowlingType: BowlingType;
  battingStyle: "Aggressive" | "Balanced" | "Defensive";
  ratings: PlayerRatings;
  jerseyNumber: number;
}

export interface Team {
  id: string;
  name: string;
  shortName: string;
  color: string;
  colorSecondary: string;
  captainId: string;
  viceCaptainId: string;
  wicketkeeperId: string;
  playingXI: string[]; // 11 player ids
  reserves: string[]; // 5 player ids
}

export type PitchType = "Green" | "Dry" | "Flat" | "Cracked";
export type LightingDefault = "Day" | "Evening" | "Night";

export interface Stadium {
  id: string;
  name: string;
  city: string;
  capacity: number;
  boundaryStraight: number; // metres
  boundarySquare: number; // metres
  pitchType: PitchType;
  pitchTendency: string;
  lighting: LightingDefault;
  primaryColor: string;
  secondaryColor: string;
  dewFactor: number; // 0-1, affects night dew / outfield speed
}

export type MatchFormatId = "QUICK" | "T20" | "ODI" | "TEST";

export interface MatchFormat {
  id: MatchFormatId;
  name: string;
  overs: number;
  wicketsPerInnings: number;
  inningsPerSide: number;
  powerplayOvers: number;
  maxOversPerBowler: number | null; // null = no cap (Test)
  bouncersPerOver: number;
}

export type Difficulty = "Easy" | "Normal" | "Hard" | "Expert";

export interface DifficultyProfile {
  id: Difficulty;
  aiShotAggression: number; // 0-1
  aiTimingAccuracy: number; // 0-1
  aiBowlingSkill: number; // 0-1
  aiFieldingSkill: number; // 0-1
  playerTimingWindowMs: number; // window width, bigger = easier
  assist: boolean;
}
