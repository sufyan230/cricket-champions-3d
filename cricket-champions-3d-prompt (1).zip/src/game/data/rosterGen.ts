// Deterministic roster ratings generator ("RosterLoader" equivalent).
// Real rosters live as plain data below (teams.ts) instead of being hardcoded into
// game logic - this module just derives full 0-99 attribute blocks from a tier + role
// so every player plays distinctly without hand-typing 21 numbers per player.
import { Player, PlayerRatings, Role, BowlingType } from "./types";

export type Tier = "superstar" | "star" | "strong" | "solid" | "squad";

const TIER_BASE: Record<Tier, number> = {
  superstar: 91,
  star: 83,
  strong: 75,
  solid: 66,
  squad: 55,
};

// simple deterministic pseudo-random from a string seed, so re-generation is stable
function seedRand(seed: string): () => number {
  let h = 1779033703 ^ seed.length;
  for (let i = 0; i < seed.length; i++) {
    h = Math.imul(h ^ seed.charCodeAt(i), 3432918353);
    h = (h << 13) | (h >>> 19);
  }
  return function () {
    h = Math.imul(h ^ (h >>> 16), 2246822507);
    h = Math.imul(h ^ (h >>> 13), 3266489909);
    h ^= h >>> 16;
    return (h >>> 0) / 4294967296;
  };
}

const clamp = (n: number) => Math.max(30, Math.min(99, Math.round(n)));

interface GenOpts {
  id: string;
  tier: Tier;
  isBatterFocus: boolean;
  isBowlerFocus: boolean;
  isWk: boolean;
  bowlingType: BowlingType;
}

export function genRatings(opts: GenOpts): PlayerRatings {
  const rnd = seedRand(opts.id);
  const base = TIER_BASE[opts.tier];
  const v = (spread: number) => base + (rnd() * 2 - 1) * spread;

  const batLevel = opts.isBatterFocus ? base : opts.isBowlerFocus ? base - 35 : base - 12;
  const bowlLevel = opts.isBowlerFocus ? base : opts.isBatterFocus ? base - 40 : base - 15;
  const isSpin = opts.bowlingType === "Off Spin" || opts.bowlingType === "Leg Spin" || opts.bowlingType.includes("Wrist") || opts.bowlingType.includes("Orthodox");

  return {
    power: clamp(v(6) + (batLevel - base)),
    timing: clamp(v(5) + (batLevel - base)),
    technique: clamp(v(6) + (batLevel - base)),
    running: clamp(v(8) + (batLevel - base) * 0.6),
    sixHitting: clamp(v(7) + (batLevel - base)),
    vsPace: clamp(v(6) + (batLevel - base)),
    vsSpin: clamp(v(6) + (batLevel - base)),
    pace: clamp(isSpin ? bowlLevel - 45 : v(5) + (bowlLevel - base)),
    swing: clamp(isSpin ? 25 : v(8) + (bowlLevel - base)),
    seam: clamp(isSpin ? 25 : v(8) + (bowlLevel - base)),
    spin: clamp(isSpin ? v(5) + (bowlLevel - base) : 20),
    accuracy: clamp(v(6) + (bowlLevel - base) * 0.8),
    variation: clamp(v(9) + (bowlLevel - base) * 0.7),
    stamina: clamp(v(8) + base * 0.3),
    catching: clamp(opts.isWk ? base + 6 : v(10) + base * 0.5),
    throwing: clamp(v(10) + base * 0.4),
    fieldSpeed: clamp(v(10) + base * 0.35),
    reaction: clamp(opts.isWk ? base + 4 : v(9) + base * 0.4),
    temperament: clamp(v(8) + base * 0.3),
    form: clamp(70 + v(10)),
    fitness: clamp(78 + v(10)),
  };
}

export function buildPlayer(
  id: string,
  displayName: string,
  teamId: string,
  role: Role,
  tags: Player["tags"],
  battingHand: Player["battingHand"],
  bowlingHand: Player["bowlingHand"],
  bowlingType: BowlingType,
  tier: Tier,
  jerseyNumber: number,
  overrides?: Partial<PlayerRatings>
): Player {
  const isBowlerFocus = role === "Fast" || role === "Spinner";
  const isBatterFocus = role === "Opener" || role === "Top Order" || role === "Middle Order" || role === "Finisher" || role === "WK-Batter";
  const ratings = genRatings({
    id,
    tier,
    isBatterFocus,
    isBowlerFocus,
    isWk: tags.includes("WK"),
    bowlingType,
  });
  const finalRatings = { ...ratings, ...overrides };
  const shortName = displayName
    .split(" ")
    .slice(-1)[0];
  return {
    id,
    displayName,
    shortName,
    teamId,
    role,
    tags,
    battingHand,
    bowlingHand,
    bowlingType,
    battingStyle: isBatterFocus ? (tier === "superstar" || tier === "star" ? "Balanced" : "Aggressive") : "Balanced",
    ratings: finalRatings,
    jerseyNumber,
  };
}
