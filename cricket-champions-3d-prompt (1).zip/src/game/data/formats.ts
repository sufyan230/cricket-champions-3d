import { DifficultyProfile, MatchFormat } from "./types";

// Format definitions (MatchFormatSO equivalent). QUICK is a shortened 5-over format
// so a full Quick Match completes fast; T20/ODI use real over counts. Test match is
// represented as a single extended limited-declaration innings pair (simplified —
// see CareerNotes) to keep it playable in one sitting while preserving correct
// wicket/all-out logic.
export const FORMATS: Record<string, MatchFormat> = {
  QUICK: { id: "QUICK", name: "Quick Match (5 overs)", overs: 5, wicketsPerInnings: 10, inningsPerSide: 1, powerplayOvers: 1, maxOversPerBowler: 2, bouncersPerOver: 1 },
  T20: { id: "T20", name: "T20 (20 overs)", overs: 20, wicketsPerInnings: 10, inningsPerSide: 1, powerplayOvers: 6, maxOversPerBowler: 4, bouncersPerOver: 1 },
  ODI: { id: "ODI", name: "ODI (50 overs)", overs: 50, wicketsPerInnings: 10, inningsPerSide: 1, powerplayOvers: 10, maxOversPerBowler: 10, bouncersPerOver: 2 },
  TEST: { id: "TEST", name: "Test (1-innings decider)", overs: 90, wicketsPerInnings: 10, inningsPerSide: 1, powerplayOvers: 0, maxOversPerBowler: null, bouncersPerOver: 2 },
};

export const DIFFICULTIES: Record<string, DifficultyProfile> = {
  Easy: { id: "Easy", aiShotAggression: 0.35, aiTimingAccuracy: 0.55, aiBowlingSkill: 0.45, aiFieldingSkill: 0.5, playerTimingWindowMs: 260, assist: true },
  Normal: { id: "Normal", aiShotAggression: 0.5, aiTimingAccuracy: 0.68, aiBowlingSkill: 0.6, aiFieldingSkill: 0.65, playerTimingWindowMs: 200, assist: true },
  Hard: { id: "Hard", aiShotAggression: 0.65, aiTimingAccuracy: 0.8, aiBowlingSkill: 0.75, aiFieldingSkill: 0.78, playerTimingWindowMs: 150, assist: false },
  Expert: { id: "Expert", aiShotAggression: 0.8, aiTimingAccuracy: 0.92, aiBowlingSkill: 0.9, aiFieldingSkill: 0.9, playerTimingWindowMs: 110, assist: false },
};

export interface ChallengeDef {
  id: string;
  title: string;
  description: string;
  mode: "bat" | "bowl";
  overs: number;
  target?: number;
  wickets: number;
  successCondition: string;
}

export const CHALLENGES: ChallengeDef[] = [
  { id: "score30in2", title: "Power Surge", description: "Score 30 runs in 2 overs.", mode: "bat", overs: 2, target: 30, wickets: 3, successCondition: "runs>=30" },
  { id: "hit3sixes", title: "Six Hit Frenzy", description: "Hit 3 sixes in 3 overs.", mode: "bat", overs: 3, wickets: 4, successCondition: "sixes>=3" },
  { id: "defend10", title: "Final Over Nerves", description: "Defend 10 runs in the final over.", mode: "bowl", overs: 1, target: 9, wickets: 10, successCondition: "concededLessThanTarget" },
  { id: "take3wickets", title: "Wrecking Ball", description: "Take 3 wickets in 4 overs.", mode: "bowl", overs: 4, wickets: 10, successCondition: "wickets>=3" },
  { id: "chase20in3", title: "Chase Down", description: "Chase 20 runs in 3 overs with only 3 wickets.", mode: "bat", overs: 3, target: 20, wickets: 3, successCondition: "runs>=target" },
];
