// Real international rosters — data-driven (Section 29 style roster file).
// This stands in for StreamingAssets/Rosters/{teams,players}.json in the web build.
// Edit this file (or wire a JSON importer to it) to update squads; nothing in the
// engine hardcodes player names or stats.
import { Player, Team, Role, BowlingType } from "./types";
import { buildPlayer, Tier } from "./rosterGen";

let AUTO_ID = 0;
function nextId(prefix: string) {
  AUTO_ID += 1;
  return `${prefix}_${AUTO_ID}`;
}

type Tag = Player["tags"][number];

function P(
  teamId: string,
  name: string,
  role: Role,
  tags: Tag[],
  bhand: Player["battingHand"],
  bowlhand: Player["bowlingHand"],
  btype: BowlingType,
  tier: Tier,
  jersey: number,
  overrides?: Partial<Player["ratings"]>
): Player {
  return buildPlayer(nextId(teamId), name, teamId, role, tags, bhand, bowlhand, btype, tier, jersey, overrides);
}

interface TeamDef {
  id: string;
  name: string;
  shortName: string;
  color: string;
  colorSecondary: string;
  players: Player[];
  xiCount: number; // first N players in `players` = playing XI
  captainIdx: number;
  viceCaptainIdx: number;
  wkIdx: number;
}

const defs: TeamDef[] = [];

// ---------------- PAKISTAN ----------------
{
  const t = "PAK";
  const players = [
    P(t, "Fakhar Zaman", "Opener", [], "Left", "Left", "Medium", "star", 21),
    P(t, "Saim Ayub", "Opener", ["AR"], "Left", "Left", "Off Spin", "strong", 8),
    P(t, "Babar Azam", "Top Order", ["C"], "Right", "Right", "None", "superstar", 56, {
      timing: 96, technique: 94, vsPace: 93, vsSpin: 92,
    }),
    P(t, "Mohammad Rizwan", "WK-Batter", ["WK"], "Right", "None", "None", "star", 97, { catching: 92 }),
    P(t, "Saud Shakeel", "Middle Order", [], "Left", "Right", "Off Spin", "solid", 32),
    P(t, "Salman Ali Agha", "Allrounder", ["AR"], "Right", "Right", "Off Spin", "solid", 68),
    P(t, "Shadab Khan", "Allrounder", ["AR", "S", "VC"], "Right", "Right", "Leg Spin", "star", 20),
    P(t, "Faheem Ashraf", "Allrounder", ["AR", "F"], "Left", "Left", "Fast-Medium", "solid", 62),
    P(t, "Shaheen Shah Afridi", "Fast", ["F"], "Left", "Left", "Left-Arm Fast", "superstar", 10, {
      swing: 95, pace: 93, accuracy: 88,
    }),
    P(t, "Haris Rauf", "Fast", ["F"], "Right", "Right", "Fast", "star", 14, { pace: 94 }),
    P(t, "Abrar Ahmed", "Spinner", ["S"], "Right", "Right", "Leg Spin", "solid", 88),
    // reserves
    P(t, "Shan Masood", "Opener", [], "Left", "Left", "Medium", "solid", 40),
    P(t, "Hasan Nawaz", "Finisher", [], "Right", "Right", "None", "solid", 5),
    P(t, "Mohammad Nawaz", "Allrounder", ["AR", "S"], "Left", "Left", "Left-Arm Orthodox", "solid", 35),
    P(t, "Naseem Shah", "Fast", ["F"], "Right", "Right", "Fast", "strong", 90),
    P(t, "Hasan Ali", "Fast", ["F"], "Right", "Right", "Fast-Medium", "solid", 58),
  ];
  defs.push({ id: t, name: "Pakistan", shortName: "PAK", color: "#0b6623", colorSecondary: "#ffffff", players, xiCount: 11, captainIdx: 2, viceCaptainIdx: 6, wkIdx: 3 });
}

// ---------------- INDIA ----------------
{
  const t = "IND";
  const players = [
    P(t, "Rohit Sharma", "Opener", ["C"], "Right", "Right", "Off Spin", "superstar", 45, { sixHitting: 94, power: 90 }),
    P(t, "Yashasvi Jaiswal", "Opener", [], "Left", "Left", "Leg Spin", "star", 19),
    P(t, "Virat Kohli", "Top Order", [], "Right", "Right", "Medium", "superstar", 18, {
      running: 95, vsSpin: 94, technique: 95, temperament: 96,
    }),
    P(t, "Shubman Gill", "Top Order", [], "Right", "Right", "Off Spin", "star", 77),
    P(t, "Suryakumar Yadav", "Middle Order", [], "Right", "Right", "Off Spin", "superstar", 63, {
      timing: 95, power: 90,
    }),
    P(t, "KL Rahul", "WK-Batter", ["WK"], "Right", "Right", "None", "star", 1),
    P(t, "Hardik Pandya", "Allrounder", ["AR", "F", "VC"], "Right", "Right", "Fast-Medium", "star", 33),
    P(t, "Ravindra Jadeja", "Allrounder", ["AR", "S"], "Left", "Left", "Left-Arm Orthodox", "star", 8, { fieldSpeed: 92, catching: 90 }),
    P(t, "Axar Patel", "Allrounder", ["AR", "S"], "Left", "Left", "Left-Arm Orthodox", "solid", 20),
    P(t, "Jasprit Bumrah", "Fast", ["F"], "Right", "Right", "Fast", "superstar", 93, {
      accuracy: 97, variation: 95, pace: 90,
    }),
    P(t, "Mohammed Siraj", "Fast", ["F"], "Right", "Right", "Fast-Medium", "strong", 73),
    // reserves
    P(t, "Rishabh Pant", "WK-Batter", ["WK"], "Left", "Left", "None", "star", 17, { power: 90 }),
    P(t, "Washington Sundar", "Allrounder", ["AR", "S"], "Left", "Right", "Off Spin", "solid", 96),
    P(t, "Kuldeep Yadav", "Spinner", ["S"], "Left", "Left", "Left-Arm Wrist", "strong", 23),
    P(t, "Varun Chakaravarthy", "Spinner", ["S"], "Right", "Right", "Off Spin", "solid", 92),
    P(t, "Arshdeep Singh", "Fast", ["F"], "Left", "Left", "Left-Arm Fast", "strong", 2),
  ];
  defs.push({ id: t, name: "India", shortName: "IND", color: "#1e3a8a", colorSecondary: "#ff9933", players, xiCount: 11, captainIdx: 0, viceCaptainIdx: 6, wkIdx: 5 });
}

// ---------------- AUSTRALIA ----------------
{
  const t = "AUS";
  const players = [
    P(t, "Travis Head", "Opener", [], "Left", "Left", "Off Spin", "star", 34),
    P(t, "Usman Khawaja", "Opener", [], "Left", "Right", "None", "strong", 1),
    P(t, "Steve Smith", "Top Order", ["VC"], "Right", "Right", "Leg Spin", "superstar", 49, { technique: 96, temperament: 95 }),
    P(t, "Marnus Labuschagne", "Top Order", [], "Right", "Right", "Leg Spin", "strong", 33),
    P(t, "Glenn Maxwell", "Middle Order", ["AR", "S"], "Right", "Right", "Off Spin", "star", 32, { power: 93, sixHitting: 93 }),
    P(t, "Alex Carey", "WK-Batter", ["WK"], "Left", "None", "None", "strong", 26),
    P(t, "Cameron Green", "Allrounder", ["AR", "F"], "Right", "Right", "Fast-Medium", "strong", 28),
    P(t, "Marcus Stoinis", "Allrounder", ["AR"], "Right", "Right", "Medium", "solid", 17),
    P(t, "Pat Cummins", "Fast", ["F", "C"], "Right", "Right", "Fast", "superstar", 30, { pace: 93, accuracy: 90 }),
    P(t, "Mitchell Starc", "Fast", ["F"], "Left", "Left", "Left-Arm Fast", "superstar", 56, { swing: 94, pace: 94 }),
    P(t, "Adam Zampa", "Spinner", ["S"], "Right", "Right", "Leg Spin", "strong", 63),
    // reserves
    P(t, "Mitchell Marsh", "Allrounder", ["AR"], "Right", "Right", "Medium", "star", 4),
    P(t, "Josh Inglis", "WK-Batter", ["WK"], "Right", "None", "None", "solid", 35),
    P(t, "Tim David", "Finisher", [], "Right", "Right", "None", "solid", 54),
    P(t, "Josh Hazlewood", "Fast", ["F"], "Right", "Right", "Fast-Medium", "strong", 38),
    P(t, "Nathan Lyon", "Spinner", ["S"], "Right", "Right", "Off Spin", "strong", 67),
  ];
  defs.push({ id: t, name: "Australia", shortName: "AUS", color: "#eab308", colorSecondary: "#166534", players, xiCount: 11, captainIdx: 8, viceCaptainIdx: 2, wkIdx: 5 });
}

// ---------------- ENGLAND ----------------
{
  const t = "ENG";
  const players = [
    P(t, "Phil Salt", "Opener", ["WK"], "Right", "None", "None", "star", 27),
    P(t, "Ben Duckett", "Opener", [], "Left", "Left", "None", "strong", 17),
    P(t, "Joe Root", "Top Order", [], "Right", "Right", "Off Spin", "superstar", 66, { technique: 96, vsSpin: 94 }),
    P(t, "Harry Brook", "Middle Order", [], "Right", "Right", "Medium", "star", 88),
    P(t, "Jos Buttler", "WK-Batter", ["WK", "C"], "Right", "None", "None", "superstar", 63, { power: 92, timing: 94 }),
    P(t, "Ben Stokes", "Allrounder", ["AR", "F", "VC"], "Left", "Right", "Fast-Medium", "superstar", 55, { temperament: 96 }),
    P(t, "Liam Livingstone", "Allrounder", ["AR", "S"], "Right", "Right", "Leg Spin", "solid", 23),
    P(t, "Sam Curran", "Allrounder", ["AR", "F"], "Left", "Left", "Left-Arm Fast", "strong", 58),
    P(t, "Jofra Archer", "Fast", ["F"], "Right", "Right", "Fast", "superstar", 22, { pace: 94 }),
    P(t, "Mark Wood", "Fast", ["F"], "Right", "Right", "Fast", "strong", 32, { pace: 95 }),
    P(t, "Adil Rashid", "Spinner", ["S"], "Right", "Right", "Leg Spin", "strong", 19),
    // reserves
    P(t, "Zak Crawley", "Opener", [], "Right", "Right", "None", "solid", 65),
    P(t, "Jacob Bethell", "Allrounder", ["AR"], "Left", "Left", "Left-Arm Orthodox", "solid", 30),
    P(t, "Jamie Smith", "WK-Batter", ["WK"], "Right", "None", "None", "solid", 5),
    P(t, "Brydon Carse", "Fast", ["F"], "Right", "Right", "Fast-Medium", "solid", 16),
    P(t, "Jamie Overton", "Allrounder", ["AR", "F"], "Right", "Right", "Fast-Medium", "solid", 96),
  ];
  defs.push({ id: t, name: "England", shortName: "ENG", color: "#1d4ed8", colorSecondary: "#dc2626", players, xiCount: 11, captainIdx: 4, viceCaptainIdx: 5, wkIdx: 0 });
}

// ---------------- NEW ZEALAND ----------------
{
  const t = "NZ";
  const players = [
    P(t, "Finn Allen", "Opener", [], "Right", "Right", "None", "solid", 8),
    P(t, "Devon Conway", "WK-Batter", ["WK"], "Left", "None", "None", "star", 19),
    P(t, "Kane Williamson", "Top Order", ["C"], "Right", "Right", "Off Spin", "superstar", 22, { technique: 95, temperament: 95 }),
    P(t, "Daryl Mitchell", "Middle Order", ["AR"], "Right", "Right", "Medium", "strong", 34),
    P(t, "Rachin Ravindra", "Allrounder", ["AR", "S"], "Left", "Left", "Left-Arm Orthodox", "star", 13),
    P(t, "Glenn Phillips", "Allrounder", ["AR"], "Right", "Right", "Off Spin", "strong", 16),
    P(t, "Mitchell Santner", "Allrounder", ["AR", "S", "VC"], "Left", "Left", "Left-Arm Orthodox", "strong", 26),
    P(t, "Matt Henry", "Fast", ["F"], "Right", "Right", "Fast-Medium", "strong", 15),
    P(t, "Trent Boult", "Fast", ["F"], "Left", "Left", "Left-Arm Fast", "superstar", 18, { swing: 93 }),
    P(t, "Lockie Ferguson", "Fast", ["F"], "Right", "Right", "Fast", "strong", 74),
    P(t, "Michael Bracewell", "Spinner", ["S"], "Right", "Right", "Off Spin", "solid", 47),
    // reserves
    P(t, "Will Young", "Top Order", [], "Right", "Right", "None", "solid", 62),
    P(t, "Tom Latham", "WK-Batter", ["WK"], "Left", "None", "None", "strong", 76),
    P(t, "Tim Seifert", "WK-Batter", ["WK"], "Right", "None", "None", "solid", 90),
    P(t, "Kyle Jamieson", "Fast", ["F"], "Right", "Right", "Fast-Medium", "solid", 60),
    P(t, "Jacob Duffy", "Fast", ["F"], "Right", "Right", "Fast-Medium", "solid", 71),
  ];
  defs.push({ id: t, name: "New Zealand", shortName: "NZ", color: "#111827", colorSecondary: "#ffffff", players, xiCount: 11, captainIdx: 2, viceCaptainIdx: 6, wkIdx: 1 });
}

// ---------------- SOUTH AFRICA ----------------
{
  const t = "SA";
  const players = [
    P(t, "Quinton de Kock", "WK-Batter", ["WK"], "Left", "None", "None", "star", 12),
    P(t, "Aiden Markram", "Opener", ["VC"], "Right", "Right", "Off Spin", "strong", 32),
    P(t, "Temba Bavuma", "Top Order", ["C"], "Right", "Right", "None", "solid", 17),
    P(t, "Heinrich Klaasen", "WK-Batter", [], "Right", "None", "None", "star", 27, { power: 93, sixHitting: 92 }),
    P(t, "Tristan Stubbs", "Middle Order", [], "Right", "Right", "None", "strong", 15),
    P(t, "David Miller", "Finisher", [], "Left", "Left", "None", "strong", 10),
    P(t, "Wiaan Mulder", "Allrounder", ["AR", "F"], "Right", "Right", "Fast-Medium", "solid", 22),
    P(t, "Marco Jansen", "Allrounder", ["AR", "F"], "Left", "Left", "Left-Arm Fast", "strong", 14),
    P(t, "Kagiso Rabada", "Fast", ["F"], "Right", "Right", "Fast", "superstar", 25, { pace: 93 }),
    P(t, "Anrich Nortje", "Fast", ["F"], "Right", "Right", "Fast", "strong", 40, { pace: 95 }),
    P(t, "Keshav Maharaj", "Spinner", ["S"], "Left", "Left", "Left-Arm Orthodox", "strong", 44),
    // reserves
    P(t, "Ryan Rickelton", "Opener", ["WK"], "Left", "None", "None", "solid", 31),
    P(t, "Dewald Brevis", "Middle Order", [], "Right", "Right", "Leg Spin", "solid", 17),
    P(t, "Corbin Bosch", "Allrounder", ["AR", "F"], "Right", "Right", "Fast-Medium", "solid", 55),
    P(t, "Lungi Ngidi", "Fast", ["F"], "Right", "Right", "Fast-Medium", "solid", 71),
    P(t, "Tabraiz Shamsi", "Spinner", ["S"], "Left", "Left", "Left-Arm Wrist", "solid", 19),
  ];
  defs.push({ id: t, name: "South Africa", shortName: "SA", color: "#065f46", colorSecondary: "#fbbf24", players, xiCount: 11, captainIdx: 2, viceCaptainIdx: 1, wkIdx: 0 });
}

// ---------------- SRI LANKA ----------------
{
  const t = "SL";
  const players = [
    P(t, "Pathum Nissanka", "Opener", [], "Right", "Right", "None", "strong", 91),
    P(t, "Avishka Fernando", "Opener", [], "Right", "Right", "None", "solid", 22),
    P(t, "Kusal Mendis", "WK-Batter", ["WK", "C"], "Right", "Right", "Off Spin", "strong", 27),
    P(t, "Charith Asalanka", "Middle Order", ["VC"], "Left", "Left", "Off Spin", "strong", 4),
    P(t, "Kamindu Mendis", "Allrounder", ["AR"], "Left", "Left", "Off Spin", "solid", 50),
    P(t, "Dasun Shanaka", "Allrounder", ["AR", "F"], "Right", "Right", "Medium", "solid", 55),
    P(t, "Dhananjaya de Silva", "Allrounder", ["AR", "S"], "Right", "Right", "Off Spin", "solid", 25),
    P(t, "Wanindu Hasaranga", "Allrounder", ["AR", "S"], "Right", "Right", "Leg Spin", "star", 33, { spin: 92, variation: 90 }),
    P(t, "Maheesh Theekshana", "Spinner", ["S"], "Right", "Right", "Off Spin", "strong", 72),
    P(t, "Dushmantha Chameera", "Fast", ["F"], "Right", "Right", "Fast", "solid", 14),
    P(t, "Matheesha Pathirana", "Fast", ["F"], "Right", "Right", "Fast", "strong", 96, { variation: 90 }),
    // reserves
    P(t, "Kusal Perera", "WK-Batter", ["WK"], "Left", "None", "None", "solid", 51),
    P(t, "Angelo Mathews", "Allrounder", ["AR"], "Right", "Right", "Medium", "solid", 32),
    P(t, "Dunith Wellalage", "Allrounder", ["AR", "S"], "Left", "Left", "Left-Arm Orthodox", "solid", 44),
    P(t, "Nuwan Thushara", "Fast", ["F"], "Left", "Left", "Left-Arm Fast", "solid", 88),
    P(t, "Pramod Madushan", "Fast", ["F"], "Right", "Right", "Fast-Medium", "solid", 66),
  ];
  defs.push({ id: t, name: "Sri Lanka", shortName: "SL", color: "#1e40af", colorSecondary: "#facc15", players, xiCount: 11, captainIdx: 2, viceCaptainIdx: 3, wkIdx: 2 });
}

// ---------------- BANGLADESH ----------------
{
  const t = "BAN";
  const players = [
    P(t, "Tanzid Hasan", "Opener", [], "Left", "Left", "None", "solid", 18),
    P(t, "Najmul Hossain Shanto", "Top Order", ["C"], "Left", "Left", "Off Spin", "strong", 25),
    P(t, "Litton Das", "WK-Batter", ["WK", "VC"], "Right", "None", "None", "strong", 7),
    P(t, "Towhid Hridoy", "Middle Order", [], "Right", "Right", "Medium", "solid", 34),
    P(t, "Mahmudullah", "Middle Order", ["AR"], "Right", "Right", "Off Spin", "solid", 30),
    P(t, "Shakib Al Hasan", "Allrounder", ["AR", "S"], "Left", "Left", "Left-Arm Orthodox", "star", 75, { spin: 90, technique: 88 }),
    P(t, "Mehidy Hasan Miraz", "Allrounder", ["AR", "S"], "Right", "Right", "Off Spin", "strong", 8),
    P(t, "Jaker Ali", "Middle Order", ["WK"], "Right", "None", "None", "solid", 39),
    P(t, "Taskin Ahmed", "Fast", ["F"], "Right", "Right", "Fast", "strong", 68),
    P(t, "Mustafizur Rahman", "Fast", ["F"], "Left", "Left", "Left-Arm Fast", "strong", 90, { variation: 90 }),
    P(t, "Taijul Islam", "Spinner", ["S"], "Left", "Left", "Left-Arm Orthodox", "solid", 22),
    // reserves
    P(t, "Mushfiqur Rahim", "WK-Batter", ["WK"], "Right", "None", "None", "solid", 15),
    P(t, "Rishad Hossain", "Allrounder", ["AR", "S"], "Right", "Right", "Leg Spin", "solid", 27),
    P(t, "Nahid Rana", "Fast", ["F"], "Right", "Right", "Fast", "solid", 33),
    P(t, "Shoriful Islam", "Fast", ["F"], "Left", "Left", "Left-Arm Fast", "solid", 41),
    P(t, "Tanzim Hasan Sakib", "Fast", ["F"], "Right", "Right", "Fast-Medium", "solid", 51),
  ];
  defs.push({ id: t, name: "Bangladesh", shortName: "BAN", color: "#065f46", colorSecondary: "#dc2626", players, xiCount: 11, captainIdx: 1, viceCaptainIdx: 2, wkIdx: 2 });
}

// ---------------- AFGHANISTAN ----------------
{
  const t = "AFG";
  const players = [
    P(t, "Rahmanullah Gurbaz", "WK-Batter", ["WK"], "Right", "None", "None", "strong", 10),
    P(t, "Ibrahim Zadran", "Opener", [], "Right", "Right", "None", "strong", 89),
    P(t, "Hashmatullah Shahidi", "Top Order", ["C"], "Left", "Right", "None", "solid", 14),
    P(t, "Rahmat Shah", "Middle Order", [], "Right", "Right", "Off Spin", "solid", 25),
    P(t, "Najibullah Zadran", "Finisher", [], "Left", "Left", "None", "solid", 12),
    P(t, "Mohammad Nabi", "Allrounder", ["AR", "S", "VC"], "Right", "Right", "Off Spin", "strong", 7),
    P(t, "Azmatullah Omarzai", "Allrounder", ["AR", "F"], "Right", "Right", "Fast-Medium", "solid", 21),
    P(t, "Rashid Khan", "Allrounder", ["AR", "S"], "Right", "Right", "Leg Spin", "superstar", 19, {
      spin: 96, variation: 94, accuracy: 92,
    }),
    P(t, "Noor Ahmad", "Spinner", ["S"], "Left", "Left", "Left-Arm Wrist", "strong", 17),
    P(t, "Fazalhaq Farooqi", "Fast", ["F"], "Left", "Left", "Left-Arm Fast", "strong", 11),
    P(t, "Naveen-ul-Haq", "Fast", ["F"], "Right", "Right", "Fast-Medium", "solid", 68),
    // reserves
    P(t, "Darwish Rasooli", "Middle Order", [], "Right", "Right", "None", "squad", 45),
    P(t, "Sediqullah Atal", "Opener", [], "Right", "Right", "None", "squad", 60),
    P(t, "Gulbadin Naib", "Allrounder", ["AR", "F"], "Right", "Right", "Medium", "solid", 15),
    P(t, "Mujeeb Ur Rahman", "Spinner", ["S"], "Right", "Right", "Off Spin", "strong", 19),
    P(t, "Allah Ghazanfar", "Spinner", ["S"], "Right", "Right", "Off Spin", "solid", 82),
  ];
  defs.push({ id: t, name: "Afghanistan", shortName: "AFG", color: "#2563eb", colorSecondary: "#dc2626", players, xiCount: 11, captainIdx: 2, viceCaptainIdx: 5, wkIdx: 0 });
}

// ---------------- WEST INDIES ----------------
{
  const t = "WI";
  const players = [
    P(t, "Brandon King", "Opener", [], "Right", "Right", "None", "solid", 22),
    P(t, "Shai Hope", "WK-Batter", ["WK", "C"], "Right", "None", "None", "strong", 7),
    P(t, "Nicholas Pooran", "Finisher", ["WK"], "Left", "Left", "None", "star", 66, { power: 92, sixHitting: 93 }),
    P(t, "Rovman Powell", "Middle Order", [], "Right", "Right", "None", "solid", 25),
    P(t, "Shimron Hetmyer", "Middle Order", [], "Left", "Left", "None", "solid", 15),
    P(t, "Roston Chase", "Allrounder", ["AR", "S"], "Right", "Right", "Off Spin", "solid", 30),
    P(t, "Jason Holder", "Allrounder", ["AR", "F"], "Right", "Right", "Fast-Medium", "strong", 3),
    P(t, "Andre Russell", "Allrounder", ["AR", "F"], "Right", "Right", "Fast-Medium", "star", 12, {
      power: 95, sixHitting: 96, pace: 85,
    }),
    P(t, "Romario Shepherd", "Allrounder", ["AR", "F"], "Right", "Right", "Fast-Medium", "solid", 32),
    P(t, "Akeal Hosein", "Spinner", ["S"], "Left", "Left", "Left-Arm Orthodox", "strong", 13),
    P(t, "Alzarri Joseph", "Fast", ["F"], "Right", "Right", "Fast", "strong", 32),
    // reserves
    P(t, "Sherfane Rutherford", "Middle Order", [], "Left", "Left", "None", "solid", 17),
    P(t, "Kavem Hodge", "Allrounder", ["AR"], "Right", "Right", "Off Spin", "squad", 44),
    P(t, "Gudakesh Motie", "Spinner", ["S"], "Left", "Left", "Left-Arm Orthodox", "solid", 25),
    P(t, "Jayden Seales", "Fast", ["F"], "Right", "Right", "Fast-Medium", "solid", 22),
    P(t, "Shamar Joseph", "Fast", ["F"], "Right", "Right", "Fast", "strong", 46),
  ];
  defs.push({ id: t, name: "West Indies", shortName: "WI", color: "#7f1d1d", colorSecondary: "#fbbf24", players, xiCount: 11, captainIdx: 1, viceCaptainIdx: 2, wkIdx: 1 });
}

export const ALL_PLAYERS: Player[] = defs.flatMap((d) => d.players);

export const TEAMS: Team[] = defs.map((d) => ({
  id: d.id,
  name: d.name,
  shortName: d.shortName,
  color: d.color,
  colorSecondary: d.colorSecondary,
  captainId: d.players[d.captainIdx].id,
  viceCaptainId: d.players[d.viceCaptainIdx].id,
  wicketkeeperId: d.players[d.wkIdx].id,
  playingXI: d.players.slice(0, d.xiCount).map((p) => p.id),
  reserves: d.players.slice(d.xiCount).map((p) => p.id),
}));

export const PLAYERS_BY_ID: Record<string, Player> = Object.fromEntries(ALL_PLAYERS.map((p) => [p.id, p]));

export function getTeam(id: string): Team {
  const t = TEAMS.find((x) => x.id === id);
  if (!t) {
    console.warn(`[RosterLoader] Team ${id} not found, falling back to first team.`);
    return TEAMS[0];
  }
  return t;
}

export function getPlayer(id: string): Player {
  const p = PLAYERS_BY_ID[id];
  if (!p) {
    console.warn(`[RosterLoader] Player ${id} not found, falling back to default player.`);
    return ALL_PLAYERS[0];
  }
  return p;
}

export function teamXI(teamId: string): Player[] {
  const team = getTeam(teamId);
  return team.playingXI.map(getPlayer);
}
