import { Difficulty, MatchFormat, Stadium, Team } from "../data/types";

export type DeliveryType =
  | "fast"
  | "yorker"
  | "bouncer"
  | "good-length"
  | "full-toss"
  | "slower"
  | "swing"
  | "seam"
  | "off-spin"
  | "leg-spin";

export type ShotType =
  | "defend"
  | "drive"
  | "loft"
  | "sweep"
  | "cut"
  | "pull"
  | "power";

export type Intent = "defend" | "normal" | "attack" | "all-out";

export type DismissalType =
  | "Bowled"
  | "LBW"
  | "Caught"
  | "Stumped"
  | "Run Out"
  | "Hit Wicket"
  | "Retired Hurt";

export interface BatterStats {
  playerId: string;
  runs: number;
  balls: number;
  fours: number;
  sixes: number;
  out: boolean;
  dismissal?: DismissalType;
  bowlerId?: string;
  fielderId?: string;
  confidence: number; // 0-100, builds with runs
}

export interface BowlerStats {
  playerId: string;
  legalBalls: number;
  runsConceded: number;
  wickets: number;
  maidenBallsThisOver: number;
  maidens: number;
  oversBowled: number;
  wides: number;
  noBalls: number;
}

export interface BallLogEntry {
  inningsIndex: number;
  over: number;
  ballInOver: number;
  runs: number;
  extra?: "wide" | "no-ball" | "bye" | "leg-bye";
  isWicket: boolean;
  dismissal?: DismissalType;
  batterId: string;
  bowlerId: string;
  commentary: string;
  timingLabel?: string;
}

export interface FallOfWicket {
  score: number;
  overs: string;
  playerId: string;
  dismissal: DismissalType;
}

export interface InningsState {
  battingTeamId: string;
  bowlingTeamId: string;
  battingOrder: string[];
  nextBatterIdx: number;
  runs: number;
  wickets: number;
  legalBalls: number; // total legal balls bowled this innings
  extras: { wide: number; noBall: number; bye: number; legBye: number };
  batters: Record<string, BatterStats>;
  bowlers: Record<string, BowlerStats>;
  strikerId: string;
  nonStrikerId: string;
  currentBowlerId: string;
  previousBowlerId?: string;
  fallOfWickets: FallOfWicket[];
  target?: number;
  isComplete: boolean;
  currentOverEvents: BallLogEntry[];
  log: BallLogEntry[];
  bouncersThisOver: number;
}

export type MatchScreen =
  | "menu"
  | "team-select"
  | "stadium-select"
  | "format-select"
  | "toss"
  | "intro"
  | "innings"
  | "over-break"
  | "innings-break"
  | "super-over"
  | "result"
  | "scorecard"
  | "settings"
  | "career"
  | "career-create"
  | "tournament"
  | "practice"
  | "challenges"
  | "challenge-play"
  | "tutorial"
  | "roster-editor"
  | "local-multiplayer-setup";

export interface MatchConfig {
  teamAId: string;
  teamBId: string;
  stadiumId: string;
  formatId: string;
  difficulty: Difficulty;
  playerTeamId: string; // team human controls
  localMultiplayer: boolean;
  isChallenge?: string;
  isTournamentMatch?: boolean;
}

export interface MatchState {
  config: MatchConfig;
  format: MatchFormat;
  stadium: Stadium;
  teamA: Team;
  teamB: Team;
  tossWinnerId: string;
  tossChoice: "Bat" | "Bowl";
  battingFirstTeamId: string;
  innings: InningsState[];
  currentInningsIndex: number;
  isSuperOver: boolean;
  result?: MatchResult;
  weather: "Sunny" | "Cloudy" | "Overcast" | "Night";
}

export interface MatchResult {
  winnerTeamId?: string; // undefined = tie/draw
  margin: string;
  playerOfMatchId: string;
  summary: string;
}
