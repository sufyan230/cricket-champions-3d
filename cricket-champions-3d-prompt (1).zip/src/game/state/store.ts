import { create } from "zustand";
import { Difficulty } from "../data/types";
import { getPlayer, getTeam, teamXI, PLAYERS_BY_ID, TEAMS } from "../data/teams";
import { STADIUMS } from "../data/stadiums";
import { FORMATS, DIFFICULTIES, CHALLENGES, ChallengeDef } from "../data/formats";
import { CareerPlayer, CareerStats, loadSave, SaveData, writeSave } from "../engine/save";
import { createInnings, createMatch } from "../engine/matchSetup";
import { resolveBall, BallOutcome } from "../engine/ballOutcome";
import { applyBallOutcome } from "../engine/matchReducer";
import { chooseAIBatting, chooseAIBowling } from "../engine/aiBrains";
import { generateCommentary } from "../engine/commentary";
import { AudioManager } from "../engine/audio";
import { DeliveryType, InningsState, Intent, MatchScreen, MatchState, ShotType } from "./matchTypes";
import { DELIVERY_LIST } from "../engine/ballMeta";

export interface SetupState {
  teamAId: string;
  teamBId: string;
  stadiumId: string;
  formatId: string;
  difficulty: Difficulty;
  localMultiplayer: boolean;
  mode: "quick" | "career" | "tournament" | "practice" | "challenge";
  challengeId?: string;
}

type BallPhase = "ready" | "need-delivery" | "need-shot" | "showing-outcome" | "need-bowler-select" | "match-over";

interface TossState {
  call?: "Heads" | "Tails";
  result?: "Heads" | "Tails";
  winnerIsPlayer?: boolean;
  choiceMade?: boolean;
}

interface TournamentTeamRow {
  teamId: string;
  played: number;
  won: number;
  lost: number;
  tied: number;
  points: number;
  nrr: number;
  runsFor: number;
  oversFor: number;
  runsAgainst: number;
  oversAgainst: number;
}

interface TournamentState {
  active: boolean;
  teamIds: string[];
  table: TournamentTeamRow[];
  fixtures: { a: string; b: string; played: boolean; result?: string }[];
  stage: "group" | "semi" | "final" | "done";
  semiFixtures?: { a: string; b: string; played: boolean; result?: string }[];
  finalFixture?: { a: string; b: string; played: boolean; result?: string };
  champion?: string;
}

interface PracticeSession {
  kind: "batting" | "bowling";
  ballsFaced: number;
  runs: number;
  sixes: number;
  fours: number;
  wickets: number;
  active: boolean;
}

interface ChallengeSession {
  def: ChallengeDef;
  success?: boolean;
  finished: boolean;
}

interface GameStore {
  screen: MatchScreen;
  previousScreen: MatchScreen;
  save: SaveData;
  setup: SetupState;
  match: MatchState | null;
  tossState: TossState;
  ballPhase: BallPhase;
  pendingDelivery?: { type: DeliveryType; quality: number };
  lastOutcome?: BallOutcome;
  lastCommentary?: string;
  commentaryFeed: string[];
  isPaused: boolean;
  careerDraft: Partial<CareerPlayer & { country: string }>;
  careerPlayerId: string | null;
  tournament: TournamentState;
  practice: PracticeSession | null;
  challenge: ChallengeSession | null;
  rewardSummary: { coins: number; xp: number; leveledUp: boolean } | null;
  lastOverCompleted: boolean;

  init: () => void;
  goTo: (screen: MatchScreen) => void;
  updateSetup: (partial: Partial<SetupState>) => void;
  startTossFlow: () => void;
  callToss: (call: "Heads" | "Tails") => void;
  chooseBatBowl: (choice: "Bat" | "Bowl") => void;
  beginInnings: () => void;
  isTeamHuman: (teamId: string) => boolean;
  nextBall: () => void;
  humanBowl: (type: DeliveryType, quality: number) => void;
  humanBat: (shot: ShotType, timingInput: number, intent: Intent) => void;
  continueAfterOutcome: () => void;
  selectNextBowler: (bowlerId: string) => void;
  setPaused: (p: boolean) => void;
  restartMatch: () => void;
  quitToMenu: () => void;
  setDifficulty: (d: Difficulty) => void;
  setVolume: (channel: "master" | "commentary" | "crowd" | "effects" | "music", value: number) => void;
  setGraphics: (g: "Low" | "Medium" | "High") => void;
  toggleSetting: (key: "autoFielding" | "autoRunning" | "vibration" | "useRealNames") => void;
  setKeyBinding: (action: string, key: string) => void;
  createCareerPlayer: (profile: Omit<CareerPlayer, "level" | "xp">) => void;
  startTournament: () => void;
  simulateFixture: (idx: number) => void;
  playTournamentFixture: (idx: number) => void;
  startPractice: (kind: "batting" | "bowling") => void;
  endPractice: () => void;
  startChallenge: (id: string) => void;
  resetSaveData: () => void;
}

const rand = Math.random;

function avgFieldingRating(teamId: string): number {
  const xi = teamXI(teamId);
  const total = xi.reduce((s, p) => s + (p.ratings.catching + p.ratings.fieldSpeed + p.ratings.reaction) / 3, 0);
  return total / xi.length / 99;
}

function defaultSetup(): SetupState {
  return {
    teamAId: "IND",
    teamBId: "AUS",
    stadiumId: "wankhede",
    formatId: "T20",
    difficulty: "Normal",
    localMultiplayer: false,
    mode: "quick",
  };
}

export const useGameStore = create<GameStore>((set, get) => ({
  screen: "menu",
  previousScreen: "menu",
  save: loadSave(),
  setup: defaultSetup(),
  match: null,
  tossState: {},
  ballPhase: "ready",
  commentaryFeed: [],
  isPaused: false,
  careerDraft: {},
  careerPlayerId: null,
  tournament: { active: false, teamIds: [], table: [], fixtures: [], stage: "group" },
  practice: null,
  challenge: null,
  rewardSummary: null,
  lastOverCompleted: false,

  init: () => {
    const save = loadSave();
    set({ save, setup: { ...defaultSetup(), difficulty: save.settings.difficulty } });
  },

  goTo: (screen) => set((s) => ({ previousScreen: s.screen, screen })),

  updateSetup: (partial) => set((s) => ({ setup: { ...s.setup, ...partial } })),

  isTeamHuman: (teamId) => {
    const { setup, match } = get();
    if (!match) return false;
    if (setup.localMultiplayer) return teamId === match.teamA.id || teamId === match.teamB.id;
    return teamId === match.config.playerTeamId;
  },

  startTossFlow: () => {
    set({ tossState: {} });
    get().goTo("toss");
  },

  callToss: (call) => {
    const { setup } = get();
    const result: "Heads" | "Tails" = rand() < 0.5 ? "Heads" : "Tails";
    const winnerIsPlayer = call === result;
    set({ tossState: { call, result, winnerIsPlayer } });
    AudioManager.playButtonClick();
    if (!winnerIsPlayer) {
      // AI decides bat/bowl automatically
      const stadium = STADIUMS.find((s) => s.id === setup.stadiumId) ?? STADIUMS[0];
      const aiChoice: "Bat" | "Bowl" = stadium.dewFactor > 0.5 ? (rand() < 0.65 ? "Bowl" : "Bat") : rand() < 0.6 ? "Bat" : "Bowl";
      setTimeout(() => get().chooseBatBowl(aiChoice), 900);
    }
  },

  chooseBatBowl: (choice) => {
    const { setup, tossState } = get();
    const winnerTeamId = tossState.winnerIsPlayer ? setup.teamAId : setup.teamBId;
    const battingFirst = choice === "Bat" ? winnerTeamId : winnerTeamId === setup.teamAId ? setup.teamBId : setup.teamAId;
    const format = FORMATS[setup.formatId] ?? FORMATS.T20;
    const match = createMatch(
      {
        teamAId: setup.teamAId,
        teamBId: setup.teamBId,
        stadiumId: setup.stadiumId,
        formatId: setup.formatId,
        difficulty: setup.difficulty,
        playerTeamId: setup.teamAId,
        localMultiplayer: setup.localMultiplayer,
        isTournamentMatch: setup.mode === "tournament",
      },
      battingFirst,
      winnerTeamId,
      choice
    );
    void format;
    set({ match, tossState: { ...tossState, choiceMade: true }, commentaryFeed: [] });
    get().goTo("intro");
    setTimeout(() => {
      set({ ballPhase: "ready" });
      get().goTo("innings");
      get().nextBall();
    }, 1800);
  },

  beginInnings: () => {
    set({ ballPhase: "ready" });
    get().nextBall();
  },

  nextBall: () => {
    const state = get();
    const match = state.match;
    if (!match) return;
    const innings = match.innings[match.currentInningsIndex];
    if (innings.isComplete) {
      get().continueAfterOutcome();
      return;
    }
    const isBowlingHuman = get().isTeamHuman(innings.bowlingTeamId);
    const isBattingHuman = get().isTeamHuman(innings.battingTeamId);

    if (isBowlingHuman) {
      set({ ballPhase: "need-delivery", pendingDelivery: undefined });
      return;
    }

    // AI bowling
    const bowler = getPlayer(innings.currentBowlerId);
    const bouncerCap = match.format.bouncersPerOver;
    const requiredRunRate = innings.target != null ? ((innings.target - innings.runs) / Math.max(1, match.format.overs * 6 - innings.legalBalls)) * 6 : undefined;
    const aiChoice = chooseAIBowling(
      {
        over: Math.floor(innings.legalBalls / 6),
        ballInOver: innings.legalBalls % 6,
        totalOvers: match.format.overs,
        wicketsDown: innings.wickets,
        runsConceded: innings.runs,
        requiredRunRate,
        bowler,
        bouncersUsedThisOver: innings.bouncersThisOver,
        maxBouncersPerOver: bouncerCap,
      },
      match.config.difficulty,
      rand
    );
    set({ pendingDelivery: { type: aiChoice.delivery, quality: aiChoice.intendedQuality } });
    proceedToShotPhase(isBattingHuman);
  },

  humanBowl: (type, quality) => {
    set({ pendingDelivery: { type, quality } });
    const state = get();
    const match = state.match!;
    const innings = match.innings[match.currentInningsIndex];
    const isBattingHuman = get().isTeamHuman(innings.battingTeamId);
    proceedToShotPhase(isBattingHuman);
  },

  humanBat: (shot, timingInput, intent) => {
    resolveCurrentBall(shot, timingInput, intent);
  },

  continueAfterOutcome: () => {
    const state = get();
    const match = state.match;
    if (!match) return;
    const innings = match.innings[match.currentInningsIndex];

    if (innings.isComplete) {
      handleInningsCompletion();
      return;
    }
    if (state.ballPhase === "need-bowler-select") return; // waiting on user pick
    if (state.lastOverCompleted && get().isTeamHuman(innings.bowlingTeamId)) {
      set({ ballPhase: "need-bowler-select", lastOutcome: undefined, lastOverCompleted: false });
      return;
    }
    set({ ballPhase: "ready", lastOutcome: undefined, lastOverCompleted: false });
    get().nextBall();
  },

  selectNextBowler: (bowlerId) => {
    set((s) => {
      if (!s.match) return s;
      const match = structuredCloneSafe(s.match);
      const innings = match.innings[match.currentInningsIndex];
      innings.currentBowlerId = bowlerId;
      if (!innings.bowlers[bowlerId]) innings.bowlers[bowlerId] = { playerId: bowlerId, legalBalls: 0, runsConceded: 0, wickets: 0, maidenBallsThisOver: 0, maidens: 0, oversBowled: 0, wides: 0, noBalls: 0 };
      return { match, ballPhase: "ready" };
    });
    get().nextBall();
  },

  setPaused: (p) => set({ isPaused: p }),

  restartMatch: () => {
    const { setup } = get();
    get().updateSetup(setup);
    set({ match: null, ballPhase: "ready", tossState: {} });
    get().goTo("team-select");
  },

  quitToMenu: () => {
    set({ match: null, isPaused: false, ballPhase: "ready", practice: null, challenge: null });
    get().goTo("menu");
  },

  setDifficulty: (d) => {
    set((s) => {
      const save = { ...s.save, settings: { ...s.save.settings, difficulty: d } };
      writeSave(save);
      return { save, setup: { ...s.setup, difficulty: d } };
    });
  },

  setVolume: (channel, value) => {
    AudioManager.setVolume(channel, value);
    set((s) => {
      const save = { ...s.save, settings: { ...s.save.settings, volumes: { ...s.save.settings.volumes, [channel]: value } } };
      writeSave(save);
      return { save };
    });
  },

  setGraphics: (g) => {
    set((s) => {
      const save = { ...s.save, settings: { ...s.save.settings, graphics: g } };
      writeSave(save);
      return { save };
    });
  },

  toggleSetting: (key) => {
    set((s) => {
      const save = { ...s.save, settings: { ...s.save.settings, [key]: !s.save.settings[key] } };
      writeSave(save);
      return { save };
    });
  },

  setKeyBinding: (action, key) => {
    set((s) => {
      const save = { ...s.save, settings: { ...s.save.settings, keyBindings: { ...s.save.settings.keyBindings, [action]: key.toLowerCase() } } };
      writeSave(save);
      return { save };
    });
  },

  createCareerPlayer: (profile) => {
    set((s) => {
      const player: CareerPlayer = { ...profile, level: 1, xp: 0 };
      const save = { ...s.save, career: { ...s.save.career, player } };
      writeSave(save);
      return { save, careerDraft: {} };
    });
  },

  startTournament: () => {
    const teamIds = TEAMS.slice(0, 6).map((t) => t.id);
    const fixtures: TournamentState["fixtures"] = [];
    for (let i = 0; i < teamIds.length; i++) {
      for (let j = i + 1; j < teamIds.length; j++) {
        fixtures.push({ a: teamIds[i], b: teamIds[j], played: false });
      }
    }
    const table: TournamentTeamRow[] = teamIds.map((id) => ({ teamId: id, played: 0, won: 0, lost: 0, tied: 0, points: 0, nrr: 0, runsFor: 0, oversFor: 0, runsAgainst: 0, oversAgainst: 0 }));
    set({ tournament: { active: true, teamIds, table, fixtures, stage: "group" } });
    get().goTo("tournament");
  },

  simulateFixture: (idx) => {
    const t = get().tournament;
    const fixture = t.stage === "group" ? t.fixtures[idx] : t.stage === "semi" ? t.semiFixtures?.[idx] : t.finalFixture;
    if (!fixture || fixture.played) return;
    const result = fastSimulateMatch(fixture.a, fixture.b, get().setup);
    applyTournamentResult(fixture, result);
  },

  playTournamentFixture: (idx) => {
    const t = get().tournament;
    const fixture = t.stage === "group" ? t.fixtures[idx] : t.stage === "semi" ? t.semiFixtures?.[idx] : t.finalFixture;
    if (!fixture) return;
    set((s) => ({ setup: { ...s.setup, teamAId: fixture.a, teamBId: fixture.b, mode: "tournament" } }));
    get().goTo("toss");
    get().startTossFlow();
  },

  startPractice: (kind) => {
    set({ practice: { kind, ballsFaced: 0, runs: 0, sixes: 0, fours: 0, wickets: 0, active: true } });
    const setup = get().setup;
    const battingFirst = kind === "batting" ? setup.teamAId : setup.teamBId;
    const match = createMatch(
      { teamAId: setup.teamAId, teamBId: setup.teamBId, stadiumId: setup.stadiumId, formatId: "QUICK", difficulty: setup.difficulty, playerTeamId: kind === "batting" ? setup.teamAId : setup.teamBId, localMultiplayer: false },
      battingFirst,
      battingFirst,
      "Bat"
    );
    match.innings[0].target = undefined;
    match.format = { ...match.format, overs: 999, wicketsPerInnings: 999 };
    set({ match, ballPhase: "ready" });
    get().goTo("practice");
    get().nextBall();
  },

  endPractice: () => {
    set({ practice: null, match: null });
    get().goTo("menu");
  },

  startChallenge: (id) => {
    const def = CHALLENGES.find((c) => c.id === id);
    if (!def) return;
    const setup = get().setup;
    const battingFirst = def.mode === "bat" ? setup.teamAId : setup.teamBId;
    const match = createMatch(
      { teamAId: setup.teamAId, teamBId: setup.teamBId, stadiumId: setup.stadiumId, formatId: "QUICK", difficulty: setup.difficulty, playerTeamId: def.mode === "bat" ? setup.teamAId : setup.teamBId, localMultiplayer: false },
      battingFirst,
      battingFirst,
      "Bat"
    );
    match.format = { ...match.format, overs: def.overs, wicketsPerInnings: def.wickets };
    match.innings[0].target = def.target;
    set({ challenge: { def, finished: false }, match, ballPhase: "ready" });
    get().goTo("challenge-play");
    get().nextBall();
  },

  resetSaveData: () => {
    const save = loadSave();
    writeSave(save);
    set({ save });
  },
}));

function structuredCloneSafe<T>(v: T): T {
  return JSON.parse(JSON.stringify(v));
}

function proceedToShotPhase(isBattingHuman: boolean) {
  const store = useGameStore.getState();
  const match = store.match!;
  const innings = match.innings[match.currentInningsIndex];

  if (isBattingHuman) {
    useGameStore.setState({ ballPhase: "need-shot" });
    return;
  }
  // AI batting
  const batter = getPlayer(innings.strikerId);
  const ballsRemaining = match.format.overs * 6 - innings.legalBalls;
  const situation = {
    wicketsDown: innings.wickets,
    wicketsAvailable: match.format.wicketsPerInnings,
    ballsRemaining,
    runsNeeded: innings.target != null ? innings.target - innings.runs : undefined,
    battingConfidence: innings.batters[innings.strikerId]?.confidence ?? 55,
    delivery: store.pendingDelivery!.type,
    batter,
  };
  const choice = chooseAIBatting(situation, match.config.difficulty, rand);
  resolveCurrentBall(choice.shot, choice.timingInput, choice.intent);
}

function resolveCurrentBall(shot: ShotType, timingInput: number, intent: Intent) {
  const store = useGameStore.getState();
  const match = store.match!;
  const innings = match.innings[match.currentInningsIndex];
  const delivery = store.pendingDelivery!;
  const batter = getPlayer(innings.strikerId);
  const bowler = getPlayer(innings.currentBowlerId);
  const stadium = match.stadium;
  const isBowlingHuman = store.isTeamHuman(innings.bowlingTeamId);
  const fieldingBase = avgFieldingRating(innings.bowlingTeamId);
  const profile = DIFFICULTIES[match.config.difficulty] ?? DIFFICULTIES.Normal;
  const fieldingSkill = isBowlingHuman ? fieldingBase * 0.9 : fieldingBase * 0.5 + profile.aiFieldingSkill * 0.5;
  const batterStats = innings.batters[innings.strikerId];

  const outcome = resolveBall(
    {
      batter,
      bowler,
      pitchType: stadium.pitchType,
      stadium,
      delivery: delivery.type,
      deliveryQuality: delivery.quality,
      shot,
      timingInput,
      intent,
      fieldingSkill,
      difficulty: match.config.difficulty,
      battingConfidence: batterStats?.confidence ?? 55,
      isNewBatter: (batterStats?.balls ?? 0) < 3,
    },
    rand
  );

  const wasHatTrick = checkHatTrickSetup(innings, bowler.id);
  const { match: newMatch, commentaryCtx, wicketFallen, overCompleted, inningsCompleted } = applyBallOutcome(match, outcome);
  commentaryCtx.isHatTrickBall = wasHatTrick && outcome.isWicket;

  const commentary = generateCommentary(outcome, batter, bowler, commentaryCtx);

  if (outcome.isSix) AudioManager.playSix();
  else if (outcome.isBoundary) AudioManager.playBoundary();
  else if (outcome.isWicket) AudioManager.playWicket();
  else AudioManager.playBatHit();
  if (wicketFallen) AudioManager.playAppeal();

  useGameStore.setState((s) => ({
    match: newMatch,
    lastOutcome: outcome,
    lastCommentary: commentary,
    ballPhase: "showing-outcome",
    commentaryFeed: [commentary, ...s.commentaryFeed].slice(0, 40),
    lastOverCompleted: overCompleted && !inningsCompleted,
  }));

  // practice / challenge tracking hooks
  const practice = useGameStore.getState().practice;
  if (practice) {
    useGameStore.setState({
      practice: {
        ...practice,
        ballsFaced: practice.ballsFaced + 1,
        runs: practice.runs + outcome.runs,
        sixes: practice.sixes + (outcome.isSix ? 1 : 0),
        fours: practice.fours + (outcome.isBoundary && !outcome.isSix ? 1 : 0),
        wickets: practice.wickets + (outcome.isWicket ? 1 : 0),
      },
    });
  }
}

function checkHatTrickSetup(innings: InningsState, bowlerId: string): boolean {
  const log = innings.log;
  if (log.length < 2) return false;
  const last = log[log.length - 1];
  const secondLast = log[log.length - 2];
  return last.bowlerId === bowlerId && secondLast.bowlerId === bowlerId && last.isWicket && secondLast.isWicket;
}

function handleInningsCompletion() {
  const store = useGameStore.getState();
  const match = store.match!;
  const isLastInnings = match.currentInningsIndex >= match.format.inningsPerSide * 2 - 1 || (match.currentInningsIndex === 1);

  if (!isLastInnings) {
    const first = match.innings[0];
    const secondBattingTeam = first.bowlingTeamId;
    const secondBowlingTeam = first.battingTeamId;
    const target = first.runs + 1;
    const secondInnings = createInnings(secondBattingTeam, secondBowlingTeam, target);
    const newMatch: MatchState = { ...match, innings: [...match.innings, secondInnings], currentInningsIndex: 1 };
    useGameStore.setState({ match: newMatch, ballPhase: "ready" });
    useGameStore.getState().goTo("innings-break");
    return;
  }

  // match complete -> compute result
  finalizeMatch();
}

function finalizeMatch() {
  const store = useGameStore.getState();
  const match = store.match!;
  const first = match.innings[0];
  const second = match.innings[1];

  let winnerTeamId: string | undefined;
  let margin = "";
  if (second.runs > first.runs) {
    winnerTeamId = second.battingTeamId;
    margin = `${match.format.wicketsPerInnings - second.wickets} wicket(s)`;
  } else if (second.runs < first.runs) {
    winnerTeamId = first.battingTeamId;
    margin = `${first.runs - second.runs} run(s)`;
  } else {
    margin = "Tie";
  }

  const pom = findPlayerOfMatch(match);
  const summary = winnerTeamId
    ? `${getTeam(winnerTeamId).name} won by ${margin}`
    : "Match tied!";

  const newMatch: MatchState = { ...match, result: { winnerTeamId, margin, playerOfMatchId: pom, summary } };
  useGameStore.setState({ match: newMatch, ballPhase: "match-over" });

  if (winnerTeamId) {
    AudioManager.playVictoryFanfare();
  }
  awardRewardsAndSave(newMatch);

  const challenge = useGameStore.getState().challenge;
  if (challenge) {
    const success = evaluateChallenge(challenge.def, newMatch);
    useGameStore.setState({ challenge: { ...challenge, success, finished: true } });
  }

  const tournament = useGameStore.getState().tournament;
  if (tournament.active) {
    updateTournamentFromMatch(newMatch);
  }

  useGameStore.getState().goTo("result");
}

function findPlayerOfMatch(match: MatchState): string {
  let best = "";
  let bestScore = -1;
  for (const innings of match.innings) {
    for (const b of Object.values(innings.batters)) {
      const score = b.runs + b.fours * 1 + b.sixes * 2;
      if (score > bestScore) {
        bestScore = score;
        best = b.playerId;
      }
    }
    for (const bw of Object.values(innings.bowlers)) {
      const score = bw.wickets * 22 - bw.runsConceded * 0.3;
      if (score > bestScore) {
        bestScore = score;
        best = bw.playerId;
      }
    }
  }
  return best || match.innings[0].battingOrder[0];
}

function evaluateChallenge(def: ChallengeDef, match: MatchState): boolean {
  const innings = match.innings[0];
  const totalRuns = innings.runs;
  const totalSixes = Object.values(innings.batters).reduce((s, b) => s + b.sixes, 0);
  const totalWickets = innings.wickets;
  switch (def.successCondition) {
    case "runs>=30":
      return totalRuns >= (def.target ?? 30);
    case "sixes>=3":
      return totalSixes >= 3;
    case "wickets>=3":
      return totalWickets >= 3;
    case "concededLessThanTarget":
      return totalRuns < (def.target ?? 9) + 1;
    case "runs>=target":
      return def.target != null && totalRuns >= def.target;
    default:
      return false;
  }
}

function awardRewardsAndSave(match: MatchState) {
  const store = useGameStore.getState();
  const playerTeamId = match.config.playerTeamId;
  const isLocalMp = match.config.localMultiplayer;
  const playerWon = !isLocalMp && match.result?.winnerTeamId === playerTeamId;

  let coins = 20;
  let xp = 25;
  for (const innings of match.innings) {
    const isPlayerBatting = innings.battingTeamId === playerTeamId;
    if (!isPlayerBatting && !isLocalMp) continue;
    for (const b of Object.values(innings.batters)) {
      coins += Math.floor(b.runs * 0.5) + b.fours * 1 + b.sixes * 2;
      xp += Math.floor(b.runs * 0.6) + b.fours * 1 + b.sixes * 3;
    }
  }
  for (const innings of match.innings) {
    const isPlayerBowling = innings.bowlingTeamId === playerTeamId;
    if (!isPlayerBowling && !isLocalMp) continue;
    for (const bw of Object.values(innings.bowlers)) {
      coins += bw.wickets * 8;
      xp += bw.wickets * 15;
    }
  }
  if (playerWon) {
    coins += 60;
    xp += 80;
  }

  const save = structuredCloneSafe(store.save);
  save.coins += coins;
  save.xp += xp;
  const prevLevel = save.level;
  save.level = Math.floor(save.xp / 500) + 1;
  const leveledUp = save.level > prevLevel;

  // Career stats tracking, if a career player exists — attribute the player's own
  // team aggregate performance as a simplified stand-in for a dedicated inserted
  // player record (keeps career progress meaningful without requiring a full
  // custom-roster injection pipeline).
  if (save.career.player) {
    const stats: CareerStats = save.career.stats;
    stats.matches += 1;
    if (match.result?.winnerTeamId === playerTeamId) stats.wins += 1;
    else if (!match.result?.winnerTeamId) stats.ties += 1;
    else stats.losses += 1;
    for (const innings of match.innings) {
      if (innings.battingTeamId !== playerTeamId) continue;
      stats.innings += 1;
      const strikerHighlight = Object.values(innings.batters).sort((a, b) => b.runs - a.runs)[0];
      if (strikerHighlight) {
        stats.runs += strikerHighlight.runs;
        stats.ballsFaced += strikerHighlight.balls;
        stats.fours += strikerHighlight.fours;
        stats.sixes += strikerHighlight.sixes;
        if (strikerHighlight.runs >= 100) stats.hundreds += 1;
        else if (strikerHighlight.runs >= 50) stats.fifties += 1;
        stats.highestScore = Math.max(stats.highestScore, strikerHighlight.runs);
      }
    }
    for (const innings of match.innings) {
      if (innings.bowlingTeamId !== playerTeamId) continue;
      const topBowler = Object.values(innings.bowlers).sort((a, b) => b.wickets - a.wickets)[0];
      if (topBowler) {
        stats.wickets += topBowler.wickets;
        stats.runsConceded += topBowler.runsConceded;
        stats.ballsBowled += topBowler.legalBalls;
      }
    }
  }

  writeSave(save);
  useGameStore.setState({ save, rewardSummary: { coins, xp, leveledUp } });
}

// ---------------- Tournament helpers ----------------
function fastSimulateMatch(teamAId: string, teamBId: string, setup: SetupState): MatchState {
  const battingFirst = rand() < 0.5 ? teamAId : teamBId;
  const bowlingFirst = battingFirst === teamAId ? teamBId : teamAId;
  let match = createMatch(
    { teamAId, teamBId, stadiumId: setup.stadiumId, formatId: "T20", difficulty: "Normal", playerTeamId: "__none__", localMultiplayer: false, isTournamentMatch: true },
    battingFirst,
    battingFirst,
    "Bat"
  );

  const simInnings = () => {
    const innings = match.innings[match.currentInningsIndex];
    let guard = 0;
    while (!innings.isComplete && guard < 400) {
      guard += 1;
      const bowler = getPlayer(innings.currentBowlerId);
      const bowlChoice = chooseAIBowling(
        {
          over: Math.floor(innings.legalBalls / 6),
          ballInOver: innings.legalBalls % 6,
          totalOvers: match.format.overs,
          wicketsDown: innings.wickets,
          runsConceded: innings.runs,
          requiredRunRate: innings.target != null ? ((innings.target - innings.runs) / Math.max(1, match.format.overs * 6 - innings.legalBalls)) * 6 : undefined,
          bowler,
          bouncersUsedThisOver: innings.bouncersThisOver,
          maxBouncersPerOver: match.format.bouncersPerOver,
        },
        "Normal",
        rand
      );
      const batter = getPlayer(innings.strikerId);
      const batChoice = chooseAIBatting(
        {
          wicketsDown: innings.wickets,
          wicketsAvailable: match.format.wicketsPerInnings,
          ballsRemaining: match.format.overs * 6 - innings.legalBalls,
          runsNeeded: innings.target != null ? innings.target - innings.runs : undefined,
          battingConfidence: innings.batters[innings.strikerId]?.confidence ?? 55,
          delivery: bowlChoice.delivery,
          batter,
        },
        "Normal",
        rand
      );
      const fieldingSkill = avgFieldingRating(innings.bowlingTeamId) * 0.6 + 0.3;
      const outcome = resolveBall(
        {
          batter,
          bowler,
          pitchType: match.stadium.pitchType,
          stadium: match.stadium,
          delivery: bowlChoice.delivery,
          deliveryQuality: bowlChoice.intendedQuality,
          shot: batChoice.shot,
          timingInput: batChoice.timingInput,
          intent: batChoice.intent,
          fieldingSkill,
          difficulty: "Normal",
          battingConfidence: innings.batters[innings.strikerId]?.confidence ?? 55,
          isNewBatter: (innings.batters[innings.strikerId]?.balls ?? 0) < 3,
        },
        rand
      );
      const applied = applyBallOutcome(match, outcome);
      match = applied.match;
    }
  };

  simInnings();
  const first = match.innings[0];
  const target = first.runs + 1;
  const second = createInnings(bowlingFirst, battingFirst, target);
  match = { ...match, innings: [first, second], currentInningsIndex: 1 };
  simInnings();

  const secondInnings = match.innings[1];
  let winnerTeamId: string | undefined;
  let margin = "";
  if (secondInnings.runs > first.runs) {
    winnerTeamId = secondInnings.battingTeamId;
    margin = `${match.format.wicketsPerInnings - secondInnings.wickets} wicket(s)`;
  } else if (secondInnings.runs < first.runs) {
    winnerTeamId = first.battingTeamId;
    margin = `${first.runs - secondInnings.runs} run(s)`;
  } else margin = "Tie";

  match = { ...match, result: { winnerTeamId, margin, playerOfMatchId: findPlayerOfMatch(match), summary: winnerTeamId ? `${getTeam(winnerTeamId).name} won by ${margin}` : "Tie" } };
  return match;
}

function applyTournamentResult(fixture: { a: string; b: string; played: boolean; result?: string }, match: MatchState) {
  fixture.played = true;
  fixture.result = match.result?.summary;
  useGameStore.setState((s) => {
    const tournament = structuredCloneSafe(s.tournament);
    updateTable(tournament, fixture.a, fixture.b, match);
    // sync fixture arrays
    if (tournament.stage === "group") {
      const idx = tournament.fixtures.findIndex((f) => f.a === fixture.a && f.b === fixture.b);
      if (idx >= 0) tournament.fixtures[idx] = { ...fixture };
      if (tournament.fixtures.every((f) => f.played)) {
        advanceToSemis(tournament);
      }
    } else if (tournament.stage === "semi" && tournament.semiFixtures) {
      const idx = tournament.semiFixtures.findIndex((f) => f.a === fixture.a && f.b === fixture.b);
      if (idx >= 0) tournament.semiFixtures[idx] = { ...fixture };
      if (tournament.semiFixtures.every((f) => f.played)) {
        const winners = tournament.semiFixtures.map((f) => (f.result?.includes(getTeam(f.a).name) ? f.a : f.b));
        tournament.finalFixture = { a: winners[0], b: winners[1], played: false };
        tournament.stage = "final";
      }
    } else if (tournament.stage === "final" && tournament.finalFixture) {
      tournament.finalFixture = { ...fixture };
      tournament.champion = match.result?.winnerTeamId;
      tournament.stage = "done";
    }
    return { tournament };
  });
}

function updateTable(tournament: TournamentState, aId: string, bId: string, match: MatchState) {
  const rowA = tournament.table.find((r) => r.teamId === aId);
  const rowB = tournament.table.find((r) => r.teamId === bId);
  if (!rowA || !rowB) return;
  const first = match.innings[0];
  const second = match.innings[1];
  const firstOvers = first.legalBalls / 6;
  const secondOvers = second.legalBalls / 6;
  const rowFor = (teamId: string) => (teamId === first.battingTeamId ? { runs: first.runs, overs: firstOvers, against: second.runs, oversAgainst: secondOvers } : { runs: second.runs, overs: secondOvers, against: first.runs, oversAgainst: firstOvers });

  [aId, bId].forEach((teamId) => {
    const row = tournament.table.find((r) => r.teamId === teamId)!;
    const info = rowFor(teamId);
    row.played += 1;
    row.runsFor += info.runs;
    row.oversFor += info.overs || 20;
    row.runsAgainst += info.against;
    row.oversAgainst += info.oversAgainst || 20;
    row.nrr = row.runsFor / (row.oversFor || 1) - row.runsAgainst / (row.oversAgainst || 1);
    if (!match.result?.winnerTeamId) row.tied += 1, (row.points += 1);
    else if (match.result.winnerTeamId === teamId) (row.won += 1), (row.points += 2);
    else row.lost += 1;
  });
}

function advanceToSemis(tournament: TournamentState) {
  const sorted = [...tournament.table].sort((a, b) => b.points - a.points || b.nrr - a.nrr);
  const top4 = sorted.slice(0, 4).map((r) => r.teamId);
  tournament.semiFixtures = [
    { a: top4[0], b: top4[3], played: false },
    { a: top4[1], b: top4[2], played: false },
  ];
  tournament.stage = "semi";
}

function updateTournamentFromMatch(match: MatchState) {
  const store = useGameStore.getState();
  const t = store.tournament;
  let fixture;
  if (t.stage === "group") fixture = t.fixtures.find((f) => !f.played && ((f.a === match.teamA.id && f.b === match.teamB.id) || (f.a === match.teamB.id && f.b === match.teamA.id)));
  else if (t.stage === "semi") fixture = t.semiFixtures?.find((f) => !f.played && ((f.a === match.teamA.id && f.b === match.teamB.id) || (f.a === match.teamB.id && f.b === match.teamA.id)));
  else if (t.stage === "final") fixture = t.finalFixture;
  if (fixture) applyTournamentResult(fixture, match);
}

export { DELIVERY_LIST, PLAYERS_BY_ID };
