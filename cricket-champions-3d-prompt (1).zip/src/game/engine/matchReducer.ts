import { getPlayer, teamXI } from "../data/teams";
import { BallLogEntry, InningsState, MatchState } from "../state/matchTypes";
import { BallOutcome } from "./ballOutcome";
import { freshBatter, freshBowler } from "./matchSetup";

export interface ApplyResult {
  match: MatchState;
  commentaryCtx: { isMilestone50?: boolean; isMilestone100?: boolean; isHatTrickBall?: boolean };
  overCompleted: boolean;
  inningsCompleted: boolean;
  needNewBatter: boolean;
  wicketFallen: boolean;
}

function clone<T>(v: T): T {
  return JSON.parse(JSON.stringify(v));
}

function pickNextBowler(match: MatchState, innings: InningsState): string {
  const xi = teamXI(innings.bowlingTeamId);
  const cap = match.format.maxOversPerBowler;
  const eligible = xi.filter((p) => {
    if (p.id === innings.currentBowlerId) return false; // can't bowl consecutive overs
    if (p.role !== "Fast" && p.role !== "Spinner" && p.role !== "Allrounder") return false;
    if (cap == null) return true;
    const stats = innings.bowlers[p.id];
    const oversSoFar = stats ? stats.legalBalls / 6 : 0;
    return oversSoFar < cap;
  });
  if (eligible.length === 0) {
    // relax constraints: allow anyone who isn't over the cap, even current bowler as last resort
    const relaxed = xi.filter((p) => {
      const stats = innings.bowlers[p.id];
      const oversSoFar = stats ? stats.legalBalls / 6 : 0;
      return cap == null || oversSoFar < cap;
    });
    return relaxed[0]?.id ?? xi[0].id;
  }
  // prefer bowlers (Fast/Spinner) over allrounders, and vary between pace/spin a bit
  eligible.sort((a, b) => {
    const score = (p: typeof a) => (p.role === "Fast" || p.role === "Spinner" ? 2 : 1);
    return score(b) - score(a);
  });
  return eligible[0].id;
}

export function applyBallOutcome(matchIn: MatchState, outcome: BallOutcome): ApplyResult {
  const match = clone(matchIn);
  const innings = match.innings[match.currentInningsIndex];
  const strikerId = innings.strikerId;
  const bowlerId = innings.currentBowlerId;

  if (!innings.batters[strikerId]) innings.batters[strikerId] = freshBatter(strikerId);
  if (!innings.bowlers[bowlerId]) innings.bowlers[bowlerId] = freshBowler(bowlerId);

  const batter = innings.batters[strikerId];
  const bowler = innings.bowlers[bowlerId];

  const isLegal = outcome.extra !== "wide" && outcome.extra !== "no-ball";
  const runsFromBat = outcome.extra ? 0 : outcome.runs;
  const extraRuns = outcome.extra ? outcome.runs : 0;

  // team score
  innings.runs += outcome.runs;
  if (outcome.extra === "wide") innings.extras.wide += extraRuns;
  if (outcome.extra === "no-ball") innings.extras.noBall += extraRuns;

  // bowler figures
  bowler.runsConceded += outcome.runs;
  if (isLegal) bowler.legalBalls += 1;
  if (outcome.extra === "wide") bowler.wides += 1;
  if (outcome.extra === "no-ball") bowler.noBalls += 1;

  // batter figures (extras don't count as ball faced or runs to batter)
  if (isLegal) {
    batter.balls += 1;
    batter.runs += runsFromBat;
    if (outcome.isBoundary && !outcome.isSix) batter.fours += 1;
    if (outcome.isSix) batter.sixes += 1;
    batter.confidence = Math.max(10, Math.min(99, batter.confidence + (outcome.isWicket ? 0 : outcome.runs > 0 ? outcome.runs * 3 : 1)));
  }

  let wicketFallen = false;
  let needNewBatter = false;
  const commentaryCtx: ApplyResult["commentaryCtx"] = {};

  if (outcome.isWicket) {
    wicketFallen = true;
    batter.out = true;
    batter.dismissal = outcome.dismissal;
    batter.bowlerId = outcome.dismissal === "Run Out" ? undefined : bowlerId;
    innings.wickets += 1;
    if (outcome.dismissal !== "Run Out") bowler.wickets += 1;
    innings.fallOfWickets.push({
      score: innings.runs,
      overs: `${Math.floor(innings.legalBalls / 6)}.${innings.legalBalls % 6}`,
      playerId: strikerId,
      dismissal: outcome.dismissal!,
    });
    needNewBatter = innings.wickets < match.format.wicketsPerInnings && innings.nextBatterIdx < innings.battingOrder.length;
    if (needNewBatter) {
      const newBatterId = innings.battingOrder[innings.nextBatterIdx];
      innings.nextBatterIdx += 1;
      innings.batters[newBatterId] = freshBatter(newBatterId);
      innings.strikerId = newBatterId;
    }
  }

  // milestones
  if (isLegal && !outcome.isWicket) {
    if (batter.runs === 50) commentaryCtx.isMilestone50 = true;
    if (batter.runs === 100) commentaryCtx.isMilestone100 = true;
  }

  // strike rotation on odd runs (from bat only)
  if (isLegal && runsFromBat % 2 === 1 && !outcome.isWicket) {
    const tmp = innings.strikerId;
    innings.strikerId = innings.nonStrikerId;
    innings.nonStrikerId = tmp;
  }

  const logEntry: BallLogEntry = {
    inningsIndex: match.currentInningsIndex,
    over: Math.floor(innings.legalBalls / 6),
    ballInOver: (innings.legalBalls % 6) + (isLegal ? 1 : 0),
    runs: outcome.runs,
    extra: outcome.extra,
    isWicket: outcome.isWicket,
    dismissal: outcome.dismissal,
    batterId: strikerId,
    bowlerId,
    commentary: "",
  };
  innings.currentOverEvents.push(logEntry);
  innings.log.push(logEntry);

  let overCompleted = false;
  if (isLegal) {
    innings.legalBalls += 1;
    if (innings.legalBalls % 6 === 0) {
      overCompleted = true;
      bowler.oversBowled += 1;
      if (bowler.maidenBallsThisOver === 6) bowler.maidens += 1;
      bowler.maidenBallsThisOver = 0;
      innings.bouncersThisOver = 0;
      // swap strike at end of over
      const tmp = innings.strikerId;
      innings.strikerId = innings.nonStrikerId;
      innings.nonStrikerId = tmp;
      innings.currentOverEvents = [];
      innings.previousBowlerId = innings.currentBowlerId;
    }
  }
  if (isLegal && outcome.runs === 0 && !outcome.isWicket) {
    bowler.maidenBallsThisOver += 1;
  } else if (isLegal) {
    bowler.maidenBallsThisOver = outcome.runs === 0 ? bowler.maidenBallsThisOver : 0;
  }

  // innings completion checks
  const allOut = innings.wickets >= match.format.wicketsPerInnings || (wicketFallen && !needNewBatter);
  const oversUp = innings.legalBalls >= match.format.overs * 6;
  const targetChased = innings.target != null && innings.runs >= innings.target;
  const inningsCompleted = allOut || oversUp || targetChased;
  if (inningsCompleted) innings.isComplete = true;

  // pick next bowler for the new over if innings continues
  if (overCompleted && !inningsCompleted) {
    innings.currentBowlerId = pickNextBowler(match, innings);
    if (!innings.bowlers[innings.currentBowlerId]) innings.bowlers[innings.currentBowlerId] = freshBowler(innings.currentBowlerId);
  }

  return { match, commentaryCtx, overCompleted, inningsCompleted, needNewBatter: wicketFallen && !needNewBatter, wicketFallen };
}

export function currentBatterPlayer(innings: InningsState) {
  return getPlayer(innings.strikerId);
}
export function currentBowlerPlayer(innings: InningsState) {
  return getPlayer(innings.currentBowlerId);
}
