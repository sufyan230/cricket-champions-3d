import { Difficulty, Player } from "../data/types";
import { DIFFICULTIES } from "../data/formats";
import { DeliveryType, Intent, ShotType } from "../state/matchTypes";
import { DELIVERY_LIST, DELIVERY_META, SHOT_LIST, SHOT_META } from "./ballMeta";

export interface BowlingSituation {
  over: number;
  ballInOver: number;
  totalOvers: number;
  wicketsDown: number;
  runsConceded: number;
  requiredRunRate?: number;
  bowler: Player;
  bouncersUsedThisOver: number;
  maxBouncersPerOver: number;
}

export interface AIBowlingChoice {
  delivery: DeliveryType;
  intendedQuality: number; // 0..1 baseline before execution noise
}

// AIBowlingBrain: picks a delivery based on match situation + death-overs logic,
// and picks the bowler's *intended* execution quality, scaled by the bowler's own
// accuracy attribute and the active difficulty tier.
export function chooseAIBowling(sit: BowlingSituation, difficulty: Difficulty, rand: () => number = Math.random): AIBowlingChoice {
  const profile = DIFFICULTIES[difficulty] ?? DIFFICULTIES.Normal;
  const isDeath = sit.over >= sit.totalOvers - 3;
  const isPowerplay = sit.over < 3;
  const bowler = sit.bowler;
  const preferSpin = bowler.bowlingType.includes("Spin") || bowler.bowlingType.includes("Orthodox") || bowler.bowlingType.includes("Wrist");

  let pool: DeliveryType[];
  if (preferSpin) {
    pool = ["off-spin", "leg-spin", "good-length", "slower"];
  } else if (isDeath) {
    pool = sit.bouncersUsedThisOver < sit.maxBouncersPerOver ? ["yorker", "slower", "bouncer", "fast"] : ["yorker", "slower", "fast"];
  } else if (isPowerplay) {
    pool = ["swing", "seam", "fast", "good-length"];
  } else {
    pool = ["good-length", "seam", "swing", "fast", "slower"];
  }
  const delivery = pool[Math.floor(rand() * pool.length)];

  const baseQuality = clamp(profile.aiBowlingSkill * 0.6 + (bowler.ratings.accuracy / 99) * 0.4, 0.15, 0.98);
  const noise = (rand() * 2 - 1) * (1 - profile.aiBowlingSkill) * 0.35;
  const intendedQuality = clamp(baseQuality + noise, 0.05, 1);

  return { delivery, intendedQuality };
}

export interface BattingSituation {
  wicketsDown: number;
  wicketsAvailable: number;
  ballsRemaining: number;
  runsNeeded?: number;
  battingConfidence: number;
  delivery: DeliveryType;
  batter: Player;
}

export interface AIBattingChoice {
  shot: ShotType;
  intent: Intent;
  timingInput: number;
}

// AIBattingBrain: reasons about required run rate, wickets in hand and overs remaining
// to decide an intent, then picks a shot suited to the incoming delivery length, then
// rolls a timing input scaled by the batter's own skill and difficulty timing accuracy.
export function chooseAIBatting(sit: BattingSituation, difficulty: Difficulty, rand: () => number = Math.random): AIBattingChoice {
  const profile = DIFFICULTIES[difficulty] ?? DIFFICULTIES.Normal;
  const reqRR = sit.runsNeeded && sit.ballsRemaining > 0 ? (sit.runsNeeded / sit.ballsRemaining) * 6 : 6;
  const wicketsInHandRatio = sit.wicketsAvailable > 0 ? 1 - sit.wicketsDown / sit.wicketsAvailable : 0;

  let intent: Intent = "normal";
  if (reqRR > 11 || (sit.runsNeeded !== undefined && sit.ballsRemaining <= 6 && sit.runsNeeded > 6)) intent = "all-out";
  else if (reqRR > 8.5) intent = "attack";
  else if (wicketsInHandRatio < 0.25 && sit.runsNeeded === undefined) intent = "defend";
  else if (profile.aiShotAggression > 0.7 && rand() < 0.3) intent = "attack";

  const dMeta = DELIVERY_META[sit.delivery];
  const candidateShots = SHOT_LIST.filter((s) => SHOT_META[s].bestLengths.includes(dMeta.length));
  const shotsPool = candidateShots.length ? candidateShots : SHOT_LIST;
  let shot: ShotType;
  if (intent === "defend") shot = "defend";
  else if (intent === "all-out") shot = shotsPool.includes("power") ? "power" : shotsPool[Math.floor(rand() * shotsPool.length)];
  else shot = shotsPool[Math.floor(rand() * shotsPool.length)];

  const skillFactor = (sit.batter.ratings.timing + sit.batter.ratings.technique) / 198;
  const accuracy = profile.aiTimingAccuracy * 0.6 + skillFactor * 0.4;
  const noise = (rand() * 2 - 1) * (1 - accuracy);
  const timingInput = clamp(0.55 * accuracy + noise, -1, 1);

  return { shot, intent, timingInput };
}

function clamp(v: number, lo: number, hi: number) {
  return Math.max(lo, Math.min(hi, v));
}

export function pickAIDeliveryTypeForNet(bowler: Player, rand: () => number = Math.random): DeliveryType {
  const preferSpin = bowler.bowlingType.includes("Spin") || bowler.bowlingType.includes("Orthodox") || bowler.bowlingType.includes("Wrist");
  const pool: DeliveryType[] = preferSpin ? ["off-spin", "leg-spin", "good-length"] : DELIVERY_LIST.filter((d) => DELIVERY_META[d].key === "pace");
  return pool[Math.floor(rand() * pool.length)];
}
