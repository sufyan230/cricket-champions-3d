import { Player, PitchType, Stadium, Difficulty } from "../data/types";
import { DeliveryType, DismissalType, Intent, ShotType } from "../state/matchTypes";
import { DELIVERY_META, SHOT_META } from "./ballMeta";
import { DIFFICULTIES } from "../data/formats";

export type TimingLabel = "Perfect" | "Good" | "Early" | "Late" | "Miss";

export interface BallContext {
  batter: Player;
  bowler: Player;
  pitchType: PitchType;
  stadium: Stadium;
  delivery: DeliveryType;
  deliveryQuality: number; // 0..1, 1 = executed perfectly by bowler
  shot: ShotType;
  timingInput: number; // -1..1 raw player/AI timing input, 1 = perfect press
  intent: Intent;
  fieldingSkill: number; // 0..1 average fielding quality of bowling side
  difficulty: Difficulty;
  battingConfidence: number; // 0..100
  isNewBatter: boolean;
}

export interface BallOutcome {
  runs: number;
  extra?: "wide" | "no-ball" | "bye" | "leg-bye";
  isWicket: boolean;
  dismissal?: DismissalType;
  timingLabel: TimingLabel;
  isBoundary: boolean;
  isSix: boolean;
  isDropped?: boolean;
}

function clamp(v: number, lo: number, hi: number) {
  return Math.max(lo, Math.min(hi, v));
}

function avg(...vals: number[]) {
  return vals.reduce((a, b) => a + b, 0) / vals.length;
}

// Pitch modifies effective bowler threat by delivery family.
function pitchModifier(pitch: PitchType, isSpin: boolean): number {
  switch (pitch) {
    case "Green":
      return isSpin ? -0.06 : 0.08;
    case "Dry":
      return isSpin ? 0.1 : -0.03;
    case "Cracked":
      return 0.05;
    case "Flat":
    default:
      return isSpin ? -0.04 : -0.04;
  }
}

export function resolveBall(ctx: BallContext, rand: () => number = Math.random): BallOutcome {
  const dMeta = DELIVERY_META[ctx.delivery];
  const sMeta = SHOT_META[ctx.shot];
  const diffProfile = DIFFICULTIES[ctx.difficulty] ?? DIFFICULTIES.Normal;

  // --- Bowler execution mistake check (wide / no-ball) happens before shot resolution ---
  if (ctx.deliveryQuality < 0.16) {
    const mistakeRoll = rand();
    if (mistakeRoll < 0.35) {
      return { runs: 1, extra: "wide", isWicket: false, timingLabel: "Miss", isBoundary: false, isSix: false };
    }
    if (mistakeRoll < 0.5) {
      return { runs: 1, extra: "no-ball", isWicket: false, timingLabel: "Miss", isBoundary: false, isSix: false };
    }
  }

  // --- Skill differential ---
  const bowlSkillRaw = dMeta.key === "spin"
    ? avg(ctx.bowler.ratings.spin, ctx.bowler.ratings.variation)
    : avg(ctx.bowler.ratings.pace, ctx.bowler.ratings.swing, ctx.bowler.ratings.seam);
  const bowlerSkill = avg(bowlSkillRaw, ctx.bowler.ratings.accuracy) * (0.55 + 0.45 * ctx.deliveryQuality);

  const batSkill = dMeta.key === "spin" ? ctx.batter.ratings.vsSpin : ctx.batter.ratings.vsPace;
  const batterSkill = avg(batSkill, ctx.batter.ratings.technique, ctx.batter.ratings.timing);

  const lengthMatch = sMeta.bestLengths.includes(dMeta.length) ? 0.18 : -0.22;
  const pitchMod = pitchModifier(ctx.pitchType, dMeta.key === "spin");
  const confidenceMod = (ctx.battingConfidence - 50) / 400;
  const newBatterPenalty = ctx.isNewBatter ? -0.08 : 0;
  const skillDelta = (batterSkill - bowlerSkill) / 260;
  const difficultyExecution = clamp(dMeta.difficulty - 0.5, -0.3, 0.3) * -1;

  let effectiveTiming = clamp(
    ctx.timingInput + skillDelta + lengthMatch + pitchMod + confidenceMod + newBatterPenalty + difficultyExecution * 0.4,
    -1,
    1
  );

  // classify timing label
  let timingLabel: TimingLabel;
  const missThreshold = -0.15 - (diffProfile.assist ? 0.12 : 0);
  if (effectiveTiming >= 0.72) timingLabel = "Perfect";
  else if (effectiveTiming >= 0.3) timingLabel = "Good";
  else if (effectiveTiming >= missThreshold) timingLabel = ctx.timingInput >= 0 ? "Early" : "Late";
  else timingLabel = "Miss";

  const intentAggro = ctx.intent === "all-out" ? 0.18 : ctx.intent === "attack" ? 0.09 : ctx.intent === "defend" ? -0.15 : 0;

  if (timingLabel === "Miss") {
    // Wicket chance depends on shot risk, delivery difficulty and intent
    const wicketChance = clamp(0.4 + sMeta.riskMult * 0.35 + dMeta.difficulty * 0.25 + intentAggro - (diffProfile.assist ? 0.15 : 0), 0.1, 0.9);
    if (rand() < wicketChance) {
      const dismissal = pickDismissal(ctx, sMeta, dMeta, rand);
      return { runs: 0, isWicket: true, dismissal, timingLabel, isBoundary: false, isSix: false };
    }
    // survived a miss - edge/scramble for a single, occasionally a lucky boundary
    const edgeRoll = rand();
    if (edgeRoll < 0.08) {
      return { runs: 4, isWicket: false, timingLabel, isBoundary: true, isSix: false };
    }
    if (edgeRoll < 0.35) {
      return { runs: 1, isWicket: false, timingLabel, isBoundary: false, isSix: false };
    }
    return { runs: 0, isWicket: false, timingLabel, isBoundary: false, isSix: false };
  }

  // --- Non-miss: compute runs ---
  const timingFactor = timingLabel === "Perfect" ? 1 : timingLabel === "Good" ? 0.65 : 0.35;
  const power = avg(ctx.batter.ratings.power, ctx.batter.ratings.sixHitting) / 99;
  const boundaryEase = clamp(1.15 - (ctx.stadium.boundaryStraight - 55) / 60, 0.6, 1.3);

  const shotPower = timingFactor * sMeta.powerMult * (0.5 + 0.5 * power) * boundaryEase * (1 + intentAggro);
  const isAerial = rand() < sMeta.aerialChance * (0.6 + 0.4 * timingFactor) * (1 + (ctx.intent === "attack" || ctx.intent === "all-out" ? 0.3 : 0));

  if (isAerial) {
    // chance of a catch if mistimed enough or fielding is strong
    const catchChance = clamp((1 - timingFactor) * 0.5 + ctx.fieldingSkill * 0.35 - power * 0.1, 0.05, 0.85);
    if (rand() < catchChance) {
      return { runs: 0, isWicket: true, dismissal: "Caught", timingLabel, isBoundary: false, isSix: false };
    }
    if (shotPower > 0.95 || (timingLabel === "Perfect" && shotPower > 0.6)) {
      return { runs: 6, isWicket: false, timingLabel, isBoundary: true, isSix: true };
    }
    // dropped / cleared the infield
    const runs = shotPower > 0.55 ? 3 : shotPower > 0.35 ? 2 : 1;
    return { runs, isWicket: false, timingLabel, isBoundary: false, isSix: false, isDropped: rand() < 0.1 };
  }

  if (shotPower > 0.8) return { runs: 4, isWicket: false, timingLabel, isBoundary: true, isSix: false };
  if (shotPower > 0.55) return { runs: rand() < 0.5 ? 3 : 2, isWicket: false, timingLabel, isBoundary: false, isSix: false };
  if (shotPower > 0.3) return { runs: rand() < 0.7 ? 1 : 2, isWicket: false, timingLabel, isBoundary: false, isSix: false };
  if (shotPower > 0.12) return { runs: rand() < 0.6 ? 1 : 0, isWicket: false, timingLabel, isBoundary: false, isSix: false };
  return { runs: 0, isWicket: false, timingLabel, isBoundary: false, isSix: false };
}

function pickDismissal(ctx: BallContext, _sMeta: unknown, dMeta: any, rand: () => number): DismissalType {
  const roll = rand();
  if (dMeta.length === "yorker" || dMeta.length === "full") {
    if (roll < 0.4) return "Bowled";
    if (roll < 0.7) return "LBW";
    return "Caught";
  }
  if (dMeta.isSpin) {
    if (roll < 0.25) return "Stumped";
    if (roll < 0.55) return "LBW";
    if (roll < 0.85) return "Caught";
    return "Bowled";
  }
  if (ctx.shot === "loft" || ctx.shot === "pull" || ctx.shot === "power" || ctx.shot === "sweep") {
    if (roll < 0.75) return "Caught";
    return "Bowled";
  }
  if (roll < 0.4) return "Bowled";
  if (roll < 0.75) return "LBW";
  return "Caught";
}
