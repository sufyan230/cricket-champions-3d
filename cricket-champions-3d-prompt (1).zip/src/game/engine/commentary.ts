import { Player } from "../data/types";
import { BallOutcome } from "./ballOutcome";

// CommentaryManager: rules-based text generation keyed on match events (not random
// flavor text). Picks from a small pool per situation for variety.
function pick<T>(arr: T[], rand: () => number = Math.random): T {
  return arr[Math.floor(rand() * arr.length)];
}

export function generateCommentary(
  outcome: BallOutcome,
  batter: Player,
  bowler: Player,
  extraCtx: { isMilestone50?: boolean; isMilestone100?: boolean; isHatTrickBall?: boolean; pressureChase?: boolean }
): string {
  if (extraCtx.isHatTrickBall && outcome.isWicket) {
    return `HAT-TRICK BALL! ${bowler.shortName} has ${batter.shortName} out — hat-trick delivered!`;
  }
  if (outcome.extra === "wide") return `Wide down the leg side from ${bowler.shortName}, extra run.`;
  if (outcome.extra === "no-ball") return `No ball! ${bowler.shortName} oversteps — free hit coming up.`;

  if (outcome.isWicket) {
    const lines: Record<string, string[]> = {
      Bowled: [`${bowler.shortName} cleans up ${batter.shortName}! Timber!`, `Right through the gate — ${batter.shortName} is bowled!`],
      LBW: [`Given LBW! ${batter.shortName} trapped in front by ${bowler.shortName}.`, `Huge appeal, and the finger goes up — ${batter.shortName} LBW.`],
      Caught: [`Skied it, and it's taken! ${batter.shortName} departs, caught off ${bowler.shortName}.`, `Great catch! ${batter.shortName} has to go.`],
      Stumped: [`Quick work behind the stumps — ${batter.shortName} is stumped off ${bowler.shortName}!`],
      "Run Out": [`Direct hit! ${batter.shortName} is run out!`],
      "Hit Wicket": [`Disaster for ${batter.shortName} — hit wicket!`],
      "Retired Hurt": [`${batter.shortName} retires hurt.`],
    };
    return pick(lines[outcome.dismissal ?? "Bowled"] ?? [`${batter.shortName} is out!`]);
  }

  if (outcome.isSix) {
    return pick([
      `That's HUGE! ${batter.shortName} launches ${bowler.shortName} for SIX!`,
      `Into the stands! ${batter.shortName} smashes a maximum!`,
      `SIX! Middled all the way, no contest.`,
    ]);
  }
  if (outcome.isBoundary) {
    return pick([
      `FOUR! ${batter.shortName} finds the gap perfectly.`,
      `Cracking shot from ${batter.shortName} — races away for four.`,
      `Beautifully timed, that's four more.`,
    ]);
  }
  if (extraCtx.isMilestone100) return `A superb century for ${batter.shortName}! Take a bow!`;
  if (extraCtx.isMilestone50) return `Fifty for ${batter.shortName}! Well played.`;

  if (outcome.runs === 0) {
    return pick([`Dot ball. Good areas from ${bowler.shortName}.`, `Defended solidly, no run.`, `Well bowled, no run taken.`]);
  }
  if (outcome.runs === 1) return pick([`Quick single taken.`, `Tucked away for a single.`]);
  if (outcome.runs === 2) return pick([`Good running, they get two.`, `Pushed into the gap for a couple.`]);
  return pick([`They run three! Excellent running between the wickets.`, `Three runs added.`]);
}

export function overSummaryLine(over: number, runs: number, wickets: number): string {
  return `End of over ${over}: ${runs} run${runs === 1 ? "" : "s"}${wickets ? `, ${wickets} wicket${wickets > 1 ? "s" : ""}` : ""} from the over.`;
}
