import { DeliveryType, ShotType } from "../state/matchTypes";

export type Length = "yorker" | "full" | "good" | "short" | "full-toss";

export interface DeliveryMeta {
  label: string;
  isSpin: boolean;
  length: Length;
  difficulty: number; // 0-1, higher = harder for batter to execute cleanly
  swingSeamFactor: number; // 0-1 extra deviation
  key: "pace" | "spin";
}

export const DELIVERY_META: Record<DeliveryType, DeliveryMeta> = {
  fast: { label: "Fast", isSpin: false, length: "good", difficulty: 0.45, swingSeamFactor: 0.1, key: "pace" },
  yorker: { label: "Yorker", isSpin: false, length: "yorker", difficulty: 0.75, swingSeamFactor: 0.15, key: "pace" },
  bouncer: { label: "Bouncer", isSpin: false, length: "short", difficulty: 0.55, swingSeamFactor: 0.05, key: "pace" },
  "good-length": { label: "Good Length", isSpin: false, length: "good", difficulty: 0.5, swingSeamFactor: 0.1, key: "pace" },
  "full-toss": { label: "Full Toss", isSpin: false, length: "full-toss", difficulty: 0.15, swingSeamFactor: 0, key: "pace" },
  slower: { label: "Slower Ball", isSpin: false, length: "good", difficulty: 0.65, swingSeamFactor: 0.1, key: "pace" },
  swing: { label: "Swing", isSpin: false, length: "good", difficulty: 0.6, swingSeamFactor: 0.35, key: "pace" },
  seam: { label: "Seam Up", isSpin: false, length: "good", difficulty: 0.55, swingSeamFactor: 0.3, key: "pace" },
  "off-spin": { label: "Off Spin", isSpin: true, length: "good", difficulty: 0.5, swingSeamFactor: 0.25, key: "spin" },
  "leg-spin": { label: "Leg Spin", isSpin: true, length: "good", difficulty: 0.58, swingSeamFactor: 0.3, key: "spin" },
};

export interface ShotMeta {
  label: string;
  bestLengths: Length[];
  powerMult: number;
  riskMult: number;
  aerialChance: number;
}

export const SHOT_META: Record<ShotType, ShotMeta> = {
  defend: { label: "Defend", bestLengths: ["good", "yorker", "full", "short", "full-toss"], powerMult: 0.05, riskMult: 0.05, aerialChance: 0.02 },
  drive: { label: "Drive", bestLengths: ["full", "good", "full-toss"], powerMult: 0.85, riskMult: 0.3, aerialChance: 0.12 },
  loft: { label: "Loft", bestLengths: ["full", "good", "full-toss"], powerMult: 1.15, riskMult: 0.6, aerialChance: 0.85 },
  sweep: { label: "Sweep", bestLengths: ["good", "short"], powerMult: 0.7, riskMult: 0.4, aerialChance: 0.3 },
  cut: { label: "Cut", bestLengths: ["short", "good"], powerMult: 0.8, riskMult: 0.32, aerialChance: 0.1 },
  pull: { label: "Pull", bestLengths: ["short", "yorker"], powerMult: 1.0, riskMult: 0.42, aerialChance: 0.35 },
  power: { label: "Power Shot", bestLengths: ["full", "good", "short", "full-toss", "yorker"], powerMult: 1.35, riskMult: 0.7, aerialChance: 0.55 },
};

export const DELIVERY_LIST: DeliveryType[] = [
  "fast",
  "yorker",
  "bouncer",
  "good-length",
  "full-toss",
  "slower",
  "swing",
  "seam",
  "off-spin",
  "leg-spin",
];

export const SHOT_LIST: ShotType[] = ["defend", "drive", "loft", "sweep", "cut", "pull", "power"];
