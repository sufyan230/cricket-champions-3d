import { Difficulty } from "../data/types";

// SaveManager — persistent JSON save via localStorage. Never throws; always falls
// back to DEFAULT_SAVE and logs a warning if the stored data is missing/corrupt.
export interface CareerPlayer {
  name: string;
  country: string;
  battingHand: "Right" | "Left";
  bowlingType: string;
  battingStyle: "Aggressive" | "Balanced" | "Defensive";
  level: number;
  xp: number;
}

export interface CareerStats {
  matches: number;
  innings: number;
  runs: number;
  ballsFaced: number;
  fifties: number;
  hundreds: number;
  highestScore: number;
  fours: number;
  sixes: number;
  wickets: number;
  runsConceded: number;
  ballsBowled: number;
  bestBowling: string;
  catches: number;
  wins: number;
  losses: number;
  ties: number;
}

export interface SaveData {
  version: number;
  coins: number;
  xp: number;
  level: number;
  unlockedStadiums: string[];
  unlockedTeams: string[];
  settings: {
    graphics: "Low" | "Medium" | "High";
    volumes: { master: number; commentary: number; crowd: number; effects: number; music: number };
    difficulty: Difficulty;
    autoFielding: boolean;
    autoRunning: boolean;
    vibration: boolean;
    useRealNames: boolean;
    keyBindings: Record<string, string>;
  };
  career: {
    player: CareerPlayer | null;
    stats: CareerStats;
  };
  tournamentProgress: Record<string, unknown>;
}

export const DEFAULT_SAVE: SaveData = {
  version: 1,
  coins: 200,
  xp: 0,
  level: 1,
  unlockedStadiums: ["wankhede", "eden", "mcg", "lords"],
  unlockedTeams: ["IND", "PAK", "AUS", "ENG", "NZ", "SA", "SL", "BAN", "AFG", "WI"],
  settings: {
    graphics: "Medium",
    volumes: { master: 0.8, commentary: 0.7, crowd: 0.6, effects: 0.9, music: 0.5 },
    difficulty: "Normal",
    autoFielding: true,
    autoRunning: true,
    vibration: true,
    useRealNames: true,
    keyBindings: {
      run: "w",
      stop: "s",
      loft: "w",
      defend: "s",
      shotLeg: "a",
      shotOff: "d",
      shotStraight: " ",
      power: "shift",
      pause: "escape",
    },
  },
  career: {
    player: null,
    stats: {
      matches: 0,
      innings: 0,
      runs: 0,
      ballsFaced: 0,
      fifties: 0,
      hundreds: 0,
      highestScore: 0,
      fours: 0,
      sixes: 0,
      wickets: 0,
      runsConceded: 0,
      ballsBowled: 0,
      bestBowling: "0/0",
      catches: 0,
      wins: 0,
      losses: 0,
      ties: 0,
    },
  },
  tournamentProgress: {},
};

const SAVE_KEY = "cricket_champions_3d_save_v1";

export function loadSave(): SaveData {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return structuredCloneSafe(DEFAULT_SAVE);
    const parsed = JSON.parse(raw);
    // shallow-merge to survive schema additions safely
    return {
      ...structuredCloneSafe(DEFAULT_SAVE),
      ...parsed,
      settings: { ...DEFAULT_SAVE.settings, ...(parsed.settings ?? {}), volumes: { ...DEFAULT_SAVE.settings.volumes, ...(parsed.settings?.volumes ?? {}) }, keyBindings: { ...DEFAULT_SAVE.settings.keyBindings, ...(parsed.settings?.keyBindings ?? {}) } },
      career: { player: parsed.career?.player ?? null, stats: { ...DEFAULT_SAVE.career.stats, ...(parsed.career?.stats ?? {}) } },
    };
  } catch (e) {
    console.warn("[SaveManager] Save file missing or corrupt, using defaults.", e);
    return structuredCloneSafe(DEFAULT_SAVE);
  }
}

export function writeSave(data: SaveData) {
  try {
    localStorage.setItem(SAVE_KEY, JSON.stringify(data));
  } catch (e) {
    console.warn("[SaveManager] Failed to write save.", e);
  }
}

export function resetSave() {
  try {
    localStorage.removeItem(SAVE_KEY);
  } catch {
    /* ignore */
  }
}

function structuredCloneSafe<T>(obj: T): T {
  try {
    return JSON.parse(JSON.stringify(obj));
  } catch {
    return obj;
  }
}
