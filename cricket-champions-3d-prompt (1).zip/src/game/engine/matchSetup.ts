import { getTeam, teamXI, getPlayer } from "../data/teams";
import { getStadium } from "../data/stadiums";
import { FORMATS } from "../data/formats";
import { MatchConfig, MatchState, InningsState, BatterStats, BowlerStats } from "../state/matchTypes";

export function freshBatter(playerId: string): BatterStats {
  return { playerId, runs: 0, balls: 0, fours: 0, sixes: 0, out: false, confidence: 55 };
}

export function freshBowler(playerId: string): BowlerStats {
  return { playerId, legalBalls: 0, runsConceded: 0, wickets: 0, maidenBallsThisOver: 0, maidens: 0, oversBowled: 0, wides: 0, noBalls: 0 };
}

function pickOpeningBowler(bowlingTeamId: string): string {
  const xi = teamXI(bowlingTeamId);
  const bowler = xi.find((p) => p.role === "Fast") ?? xi.find((p) => p.role === "Allrounder") ?? xi[xi.length - 1];
  return bowler.id;
}

export function createInnings(battingTeamId: string, bowlingTeamId: string, target?: number): InningsState {
  const order = teamXI(battingTeamId).map((p) => p.id);
  const striker = order[0];
  const nonStriker = order[1];
  const bowlerId = pickOpeningBowler(bowlingTeamId);
  return {
    battingTeamId,
    bowlingTeamId,
    battingOrder: order,
    nextBatterIdx: 2,
    runs: 0,
    wickets: 0,
    legalBalls: 0,
    extras: { wide: 0, noBall: 0, bye: 0, legBye: 0 },
    batters: { [striker]: freshBatter(striker), [nonStriker]: freshBatter(nonStriker) },
    bowlers: { [bowlerId]: freshBowler(bowlerId) },
    strikerId: striker,
    nonStrikerId: nonStriker,
    currentBowlerId: bowlerId,
    fallOfWickets: [],
    target,
    isComplete: false,
    currentOverEvents: [],
    log: [],
    bouncersThisOver: 0,
  };
}

export function createMatch(config: MatchConfig, battingFirstTeamId: string, tossWinnerId: string, tossChoice: "Bat" | "Bowl"): MatchState {
  const format = FORMATS[config.formatId] ?? FORMATS.QUICK;
  const stadium = getStadium(config.stadiumId);
  const teamA = getTeam(config.teamAId);
  const teamB = getTeam(config.teamBId);
  const bowlingFirstTeamId = battingFirstTeamId === teamA.id ? teamB.id : teamA.id;
  const weatherPool: MatchState["weather"][] = stadium.lighting === "Night" ? ["Night"] : stadium.lighting === "Evening" ? ["Cloudy", "Evening" as any] : ["Sunny", "Cloudy"];
  return {
    config,
    format,
    stadium,
    teamA,
    teamB,
    tossWinnerId,
    tossChoice,
    battingFirstTeamId,
    innings: [createInnings(battingFirstTeamId, bowlingFirstTeamId)],
    currentInningsIndex: 0,
    isSuperOver: false,
    weather: (weatherPool[0] as MatchState["weather"]) ?? "Sunny",
  };
}

export function otherTeam(match: MatchState, teamId: string): string {
  return match.teamA.id === teamId ? match.teamB.id : match.teamA.id;
}

export function ensurePlayerExists(id: string) {
  return getPlayer(id);
}
