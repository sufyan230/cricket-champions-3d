// AudioManager — FALLBACK PROCEDURAL AUDIO.
// No licensed sound assets are available in this environment, so every "clip" here
// is a synthesized Web Audio tone/noise-burst standing in for a real sound file.
// To use real audio later: replace the body of each play*() method with an
// `new Audio('/audio/xyz.mp3').play()` call — the public method names/signatures
// (and therefore every call site in the UI) do not need to change.
export type AudioChannel = "master" | "commentary" | "crowd" | "effects" | "music";

class AudioManagerImpl {
  private ctx: AudioContext | null = null;
  private volumes: Record<AudioChannel, number> = {
    master: 0.8,
    commentary: 0.7,
    crowd: 0.6,
    effects: 0.9,
    music: 0.5,
  };
  private musicNodes: { osc: OscillatorNode; gain: GainNode }[] = [];

  private getCtx(): AudioContext | null {
    if (typeof window === "undefined") return null;
    if (!this.ctx) {
      try {
        const Ctor = window.AudioContext || (window as any).webkitAudioContext;
        this.ctx = new Ctor();
      } catch (e) {
        console.warn("[AudioManager] Web Audio unavailable, sound disabled.", e);
        return null;
      }
    }
    if (this.ctx.state === "suspended") this.ctx.resume().catch(() => {});
    return this.ctx;
  }

  setVolume(channel: AudioChannel, value: number) {
    this.volumes[channel] = Math.max(0, Math.min(1, value));
  }

  getVolume(channel: AudioChannel) {
    return this.volumes[channel];
  }

  private gainFor(channel: AudioChannel) {
    return this.volumes.master * this.volumes[channel];
  }

  private tone(freq: number, durationMs: number, channel: AudioChannel, type: OscillatorType = "sine", startGain = 0.25) {
    const ctx = this.getCtx();
    if (!ctx) return;
    const g = this.gainFor(channel);
    if (g <= 0) return;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.value = freq;
    gain.gain.value = startGain * g;
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + durationMs / 1000);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + durationMs / 1000);
  }

  private noise(durationMs: number, channel: AudioChannel, gainScale = 0.2) {
    const ctx = this.getCtx();
    if (!ctx) return;
    const g = this.gainFor(channel);
    if (g <= 0) return;
    const bufferSize = Math.floor((ctx.sampleRate * durationMs) / 1000);
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / bufferSize);
    const src = ctx.createBufferSource();
    src.buffer = buffer;
    const gain = ctx.createGain();
    gain.gain.value = gainScale * g;
    src.connect(gain);
    gain.connect(ctx.destination);
    src.start();
  }

  playBatHit() {
    this.noise(90, "effects", 0.5);
    this.tone(1200, 80, "effects", "square", 0.15);
  }
  playBallImpact() {
    this.noise(60, "effects", 0.3);
  }
  playBoundary() {
    this.tone(660, 220, "crowd", "sawtooth", 0.2);
    this.noise(400, "crowd", 0.15);
  }
  playSix() {
    this.tone(880, 320, "crowd", "sawtooth", 0.25);
    this.tone(1046, 380, "crowd", "sawtooth", 0.2);
    this.noise(500, "crowd", 0.2);
  }
  playWicket() {
    this.tone(180, 400, "effects", "sawtooth", 0.3);
    this.tone(120, 500, "effects", "square", 0.2);
  }
  playAppeal() {
    this.tone(500, 250, "crowd", "triangle", 0.2);
  }
  playUmpireCall() {
    this.tone(300, 150, "commentary", "square", 0.2);
  }
  playCrowdCheer() {
    this.noise(700, "crowd", 0.25);
  }
  playButtonClick() {
    this.tone(700, 60, "effects", "square", 0.15);
  }
  playMenuMusicLoop() {
    // Simple ambient two-note pad loop as a placeholder for real menu music.
    const ctx = this.getCtx();
    if (!ctx) return;
    this.stopMusic();
    [220, 277].forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.value = freq;
      gain.gain.value = 0.05 * this.gainFor("music");
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      this.musicNodes.push({ osc, gain });
      void i;
    });
  }
  stopMusic() {
    this.musicNodes.forEach(({ osc }) => {
      try {
        osc.stop();
      } catch {
        /* already stopped */
      }
    });
    this.musicNodes = [];
  }
  playVictoryFanfare() {
    [523, 659, 784, 1046].forEach((f, i) => {
      setTimeout(() => this.tone(f, 300, "music", "triangle", 0.25), i * 150);
    });
  }
}

export const AudioManager = new AudioManagerImpl();
