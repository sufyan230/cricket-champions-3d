import { ButtonHTMLAttributes, ReactNode } from "react";
import { cn } from "../../../utils/cn";
import { AudioManager } from "../../engine/audio";

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  children: ReactNode;
  variant?: "primary" | "secondary" | "ghost" | "danger" | "gold";
  size?: "sm" | "md" | "lg";
}

export function Button({ children, variant = "primary", size = "md", className, onClick, ...rest }: ButtonProps) {
  const base = "inline-flex items-center justify-center gap-2 rounded-xl font-semibold tracking-wide transition-all duration-150 active:scale-95 disabled:opacity-40 disabled:cursor-not-allowed select-none";
  const variants: Record<string, string> = {
    primary: "bg-gradient-to-b from-emerald-400 to-emerald-600 text-white shadow-lg shadow-emerald-900/40 hover:from-emerald-300 hover:to-emerald-500",
    secondary: "bg-slate-800 text-slate-100 border border-slate-600 hover:bg-slate-700",
    ghost: "bg-white/5 text-slate-200 hover:bg-white/10 border border-white/10",
    danger: "bg-gradient-to-b from-rose-500 to-rose-700 text-white hover:from-rose-400 hover:to-rose-600",
    gold: "bg-gradient-to-b from-amber-300 to-amber-500 text-amber-950 shadow-lg shadow-amber-900/40 hover:from-amber-200 hover:to-amber-400",
  };
  const sizes: Record<string, string> = {
    sm: "px-3 py-1.5 text-sm",
    md: "px-5 py-2.5 text-base",
    lg: "px-8 py-4 text-lg",
  };
  return (
    <button
      className={cn(base, variants[variant], sizes[size], className)}
      onClick={(e) => {
        AudioManager.playButtonClick();
        onClick?.(e);
      }}
      {...rest}
    >
      {children}
    </button>
  );
}

export function Panel({ children, className }: { children: ReactNode; className?: string }) {
  return <div className={cn("rounded-2xl border border-white/10 bg-slate-900/70 backdrop-blur-sm shadow-2xl", className)}>{children}</div>;
}

export function SectionTitle({ children, className }: { children: ReactNode; className?: string }) {
  return <h2 className={cn("text-xl font-bold tracking-tight text-white", className)}>{children}</h2>;
}
