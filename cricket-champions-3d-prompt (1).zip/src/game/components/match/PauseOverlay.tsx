import { useGameStore } from "../../state/store";
import { Button, Panel, SectionTitle } from "../ui/Button";

export function PauseOverlay() {
  const setPaused = useGameStore((s) => s.setPaused);
  const goTo = useGameStore((s) => s.goTo);
  const quitToMenu = useGameStore((s) => s.quitToMenu);
  const restartMatch = useGameStore((s) => s.restartMatch);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm">
      <Panel className="w-80 p-6 text-center text-white">
        <SectionTitle className="mb-4">Paused</SectionTitle>
        <div className="flex flex-col gap-3">
          <Button onClick={() => setPaused(false)}>Resume</Button>
          <Button variant="secondary" onClick={() => { setPaused(false); goTo("settings"); }}>
            Settings
          </Button>
          <Button variant="secondary" onClick={() => { setPaused(false); restartMatch(); }}>
            Restart Match
          </Button>
          <Button
            variant="danger"
            onClick={() => {
              setPaused(false);
              quitToMenu();
            }}
          >
            Quit Match
          </Button>
        </div>
      </Panel>
    </div>
  );
}
