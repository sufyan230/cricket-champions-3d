import { useGameStore } from "../../state/store";
import { getPlayer, getTeam } from "../../data/teams";

export function Scoreboard() {
  const match = useGameStore((s) => s.match);
  if (!match) return null;
  const innings = match.innings[match.currentInningsIndex];
  const battingTeam = getTeam(innings.battingTeamId);
  const bowlingTeam = getTeam(innings.bowlingTeamId);
  const striker = innings.batters[innings.strikerId];
  const nonStriker = innings.batters[innings.nonStrikerId];
  const bowler = innings.bowlers[innings.currentBowlerId];
  const overs = `${Math.floor(innings.legalBalls / 6)}.${innings.legalBalls % 6}`;
  const bowlerOvers = bowler ? `${Math.floor(bowler.legalBalls / 6)}.${bowler.legalBalls % 6}` : "0.0";

  const ballsLeft = match.format.overs * 6 - innings.legalBalls;
  const rrr = innings.target != null && ballsLeft > 0 ? ((innings.target - innings.runs) / ballsLeft) * 6 : null;
  const crr = innings.legalBalls > 0 ? (innings.runs / innings.legalBalls) * 6 : 0;

  return (
    <div className="w-full bg-slate-950/90 px-3 py-2 text-white sm:px-6 sm:py-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <div className="flex items-center gap-2">
            <span className="h-3 w-3 rounded-full" style={{ backgroundColor: battingTeam.color }} />
            <span className="text-lg font-extrabold sm:text-2xl">
              {battingTeam.shortName} {innings.runs}/{innings.wickets}
            </span>
            <span className="text-sm text-slate-400">({overs} ov)</span>
          </div>
          {innings.target != null && (
            <div className="text-xs text-amber-300">
              Need {Math.max(0, innings.target - innings.runs)} from {ballsLeft} balls {rrr ? `· RRR ${rrr.toFixed(2)}` : ""}
            </div>
          )}
          {innings.target == null && <div className="text-xs text-slate-400">CRR {crr.toFixed(2)} · vs {bowlingTeam.shortName}</div>}
        </div>
        <div className="text-right text-sm">
          <div>
            <span className="font-semibold">{striker ? getPlayer(striker.playerId).shortName : "-"}</span>{" "}
            <span className="text-emerald-400">
              {striker?.runs ?? 0}({striker?.balls ?? 0})*
            </span>
          </div>
          <div className="text-slate-400">
            {nonStriker ? getPlayer(nonStriker.playerId).shortName : "-"} {nonStriker?.runs ?? 0}({nonStriker?.balls ?? 0})
          </div>
          <div className="mt-1 text-xs text-slate-500">
            {bowler ? getPlayer(bowler.playerId).shortName : "-"}: {bowlerOvers}-{bowler?.maidens ?? 0}-{bowler?.runsConceded ?? 0}-{bowler?.wickets ?? 0}
          </div>
        </div>
      </div>
      <OverDots />
    </div>
  );
}

function OverDots() {
  const match = useGameStore((s) => s.match);
  if (!match) return null;
  const innings = match.innings[match.currentInningsIndex];
  const events = innings.currentOverEvents;
  return (
    <div className="mt-1 flex gap-1">
      {events.map((e, i) => (
        <span
          key={i}
          className={`flex h-6 w-6 items-center justify-center rounded-full text-[10px] font-bold ${
            e.isWicket ? "bg-rose-600" : e.runs === 4 ? "bg-blue-500" : e.runs === 6 ? "bg-purple-500" : e.extra ? "bg-amber-500" : e.runs === 0 ? "bg-slate-700" : "bg-emerald-600"
          }`}
        >
          {e.isWicket ? "W" : e.extra ? (e.extra === "wide" ? "Wd" : e.extra === "no-ball" ? "Nb" : e.runs) : e.runs}
        </span>
      ))}
    </div>
  );
}
