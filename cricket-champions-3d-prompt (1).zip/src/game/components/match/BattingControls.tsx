import { useEffect, useRef, useState } from "react";
import { useGameStore } from "../../state/store";
import { getPlayer } from "../../data/teams";
import { MeterBar, MeterHandle, meterTiming } from "./MeterBar";
import { DELIVERY_META } from "../../engine/ballMeta";
import { DeliveryType, Intent, ShotType } from "../../state/matchTypes";
import { DIFFICULTIES } from "../../data/formats";
import { Button } from "../ui/Button";

const SHOT_BUTTONS: { type: ShotType; label: string; hint: string }[] = [
  { type: "defend", label: "Defend", hint: "S" },
  { type: "drive", label: "Drive", hint: "Space" },
  { type: "loft", label: "Loft", hint: "W" },
  { type: "sweep", label: "Sweep", hint: "" },
  { type: "cut", label: "Cut", hint: "D" },
  { type: "pull", label: "Pull", hint: "A" },
  { type: "power", label: "Power", hint: "Shift" },
];

function resolveFamily(family: "leg" | "off" | "straight" | "loft" | "power", delivery: DeliveryType): ShotType {
  const meta = DELIVERY_META[delivery];
  if (family === "loft") return "loft";
  if (family === "power") return "power";
  if (family === "straight") return meta.length === "short" ? "pull" : meta.length === "yorker" ? "defend" : "drive";
  if (family === "leg") return meta.isSpin ? "sweep" : meta.length === "short" ? "pull" : "drive";
  // off
  return meta.length === "short" ? "cut" : "drive";
}

export function BattingControls() {
  const match = useGameStore((s) => s.match)!;
  const ballPhase = useGameStore((s) => s.ballPhase);
  const pendingDelivery = useGameStore((s) => s.pendingDelivery);
  const humanBat = useGameStore((s) => s.humanBat);
  const save = useGameStore((s) => s.save);
  const meterRef = useRef<MeterHandle>(null);
  const [intent, setIntent] = useState<Intent>("normal");
  const [locked, setLocked] = useState(false);

  const innings = match.innings[match.currentInningsIndex];
  const bowler = getPlayer(innings.currentBowlerId);
  const period = Math.max(480, 1150 - bowler.ratings.pace * 5);
  const profile = DIFFICULTIES[match.config.difficulty] ?? DIFFICULTIES.Normal;
  const multiplier = 4 / (profile.playerTimingWindowMs / 200);

  useEffect(() => {
    setLocked(false);
  }, [ballPhase]);

  function attemptShot(shot: ShotType) {
    if (locked || ballPhase !== "need-shot") return;
    setLocked(true);
    const value = meterRef.current?.getValue() ?? 0.5;
    const timing = meterTiming(value, multiplier);
    humanBat(shot, timing, intent);
  }

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (ballPhase !== "need-shot") return;
      const key = e.key.toLowerCase();
      const kb = save.settings.keyBindings;
      const delivery = pendingDelivery?.type ?? "good-length";
      if (key === kb.loft) attemptShot(resolveFamily("loft", delivery));
      else if (key === kb.defend) attemptShot("defend");
      else if (key === kb.shotLeg) attemptShot(resolveFamily("leg", delivery));
      else if (key === kb.shotOff) attemptShot(resolveFamily("off", delivery));
      else if (key === kb.shotStraight || key === " ") attemptShot(resolveFamily("straight", delivery));
      else if (key === kb.power || key === "shift") attemptShot(resolveFamily("power", delivery));
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ballPhase, pendingDelivery, locked, intent]);

  if (ballPhase !== "need-shot") {
    return (
      <div className="flex h-full items-center justify-center text-sm text-slate-400">
        {ballPhase === "need-delivery" ? "Waiting for bowler…" : "…"}
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-3 p-3">
      <div className="flex items-center justify-between">
        <div className="text-xs text-slate-400">Bowler: {bowler.shortName} ({bowler.bowlingType})</div>
        <div className="flex gap-1">
          {(["defend", "normal", "attack", "all-out"] as Intent[]).map((i) => (
            <button
              key={i}
              onClick={() => setIntent(i)}
              className={`rounded-md px-2 py-1 text-[10px] font-semibold uppercase ${intent === i ? "bg-emerald-500 text-white" : "bg-slate-800 text-slate-400"}`}
            >
              {i}
            </button>
          ))}
        </div>
      </div>
      <MeterBar ref={meterRef} periodMs={period} label="Timing — swing/tap on the sweet spot" running={ballPhase === "need-shot"} />
      <div className="grid grid-cols-4 gap-2 sm:grid-cols-7">
        {SHOT_BUTTONS.map((b) => (
          <Button key={b.type} size="sm" variant={b.type === "power" ? "gold" : "secondary"} onClick={() => attemptShot(b.type)} disabled={locked}>
            <span className="flex flex-col items-center leading-tight">
              <span>{b.label}</span>
              {b.hint && <span className="text-[9px] opacity-60">{b.hint}</span>}
            </span>
          </Button>
        ))}
      </div>
      <p className="text-center text-[10px] text-slate-500">PC: A/D/W/S/Space/Shift · Mobile: tap a shot button</p>
    </div>
  );
}
