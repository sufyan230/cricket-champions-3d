import { Canvas, useFrame } from "@react-three/fiber";
import { useMemo, useRef, useState, useEffect } from "react";
import * as THREE from "three";
import { Stadium } from "../../data/types";
import { BallOutcome } from "../../engine/ballOutcome";

interface CricketSceneProps {
  stadium: Stadium;
  phase: string;
  outcome?: BallOutcome;
  outcomeTick: number;
  teamAColor: string;
  teamBColor: string;
  battingColor: string;
  bowlingColor: string;
  graphics: "Low" | "Medium" | "High";
  shotSide: "leg" | "off" | "straight";
}

function Stumps({ position }: { position: [number, number, number] }) {
  return (
    <group position={position}>
      {[-0.11, 0, 0.11].map((x) => (
        <mesh key={x} position={[x, 0.35, 0]} castShadow>
          <cylinderGeometry args={[0.02, 0.02, 0.7, 8]} />
          <meshStandardMaterial color="#f5deb3" />
        </mesh>
      ))}
    </group>
  );
}

function Fielders({ boundary, color }: { boundary: number; color: string }) {
  const positions = useMemo(() => {
    const arr: [number, number, number][] = [];
    const count = 8;
    for (let i = 0; i < count; i++) {
      const angle = (i / count) * Math.PI * 2 + 0.3;
      const r = boundary * (0.55 + Math.random() * 0.25);
      arr.push([Math.sin(angle) * r, 0.5, Math.cos(angle) * r]);
    }
    return arr;
  }, [boundary]);
  return (
    <>
      {positions.map((p, i) => (
        <mesh key={i} position={p} castShadow>
          <capsuleGeometry args={[0.25, 0.6, 4, 8]} />
          <meshStandardMaterial color={color} />
        </mesh>
      ))}
    </>
  );
}

function AnimatedBall({ phase, outcome, outcomeTick, shotSide }: { phase: string; outcome?: BallOutcome; outcomeTick: number; shotSide: "leg" | "off" | "straight" }) {
  const ref = useRef<THREE.Mesh>(null);
  const startT = useRef(performance.now());
  const [, setForce] = useState(0);

  useEffect(() => {
    startT.current = performance.now();
    setForce((f) => f + 1);
  }, [outcomeTick, phase]);

  useFrame(() => {
    if (!ref.current) return;
    const elapsed = (performance.now() - startT.current) / 1000;
    const bowlerZ = 9.5;
    const batterZ = -9.5;

    if (phase === "need-shot" || phase === "need-delivery" || phase === "ready") {
      const t = Math.min(1, elapsed / 0.9);
      ref.current.position.set(0, 0.4 + Math.sin(t * Math.PI) * 0.3, THREE.MathUtils.lerp(bowlerZ, batterZ, t));
      return;
    }

    if (phase === "showing-outcome" && outcome) {
      const flightT = Math.min(1, elapsed / 0.5);
      const sideX = shotSide === "leg" ? -1 : shotSide === "off" ? 1 : 0;
      if (outcome.isWicket) {
        ref.current.position.set(0, 0.4, THREE.MathUtils.lerp(bowlerZ, batterZ - 0.5, flightT));
        return;
      }
      const impactT = Math.min(1, Math.max(0, (elapsed - 0.35) / 1.1));
      const bx = THREE.MathUtils.lerp(0, sideX * (outcome.isSix ? 16 : outcome.isBoundary ? 13 : 3 + outcome.runs * 1.5), impactT);
      const bz = THREE.MathUtils.lerp(batterZ, batterZ - (outcome.isSix ? 22 : outcome.isBoundary ? 17 : 4 + outcome.runs * 2), impactT);
      const height = outcome.isSix ? Math.sin(impactT * Math.PI) * 6 : outcome.isBoundary ? Math.sin(impactT * Math.PI) * 0.6 : Math.sin(impactT * Math.PI) * 1.2;
      const approach = Math.min(1, elapsed / 0.35);
      const preZ = THREE.MathUtils.lerp(bowlerZ, batterZ, approach);
      if (elapsed < 0.35) {
        ref.current.position.set(0, 0.4 + Math.sin(approach * Math.PI) * 0.3, preZ);
      } else {
        ref.current.position.set(bx, 0.35 + height, bz);
      }
    }
  });

  return (
    <mesh ref={ref} position={[0, 0.4, 9.5]} castShadow>
      <sphereGeometry args={[0.12, 12, 12]} />
      <meshStandardMaterial color="#dc2626" />
    </mesh>
  );
}

function Batter({ color }: { color: string }) {
  return (
    <mesh position={[0.3, 0.6, -9.3]} castShadow>
      <capsuleGeometry args={[0.28, 0.9, 4, 8]} />
      <meshStandardMaterial color={color} />
    </mesh>
  );
}

function Bowler({ color, phase }: { color: string; phase: string }) {
  const ref = useRef<THREE.Mesh>(null);
  const start = useRef(performance.now());
  useEffect(() => {
    start.current = performance.now();
  }, [phase]);
  useFrame(() => {
    if (!ref.current) return;
    const elapsed = (performance.now() - start.current) / 1000;
    const t = Math.min(1, elapsed / 0.9);
    const z = THREE.MathUtils.lerp(12.5, 9.7, phase === "need-shot" ? t : 0);
    ref.current.position.set(0, 0.6, z);
  });
  return (
    <mesh ref={ref} position={[0, 0.6, 12.5]} castShadow>
      <capsuleGeometry args={[0.28, 0.9, 4, 8]} />
      <meshStandardMaterial color={color} />
    </mesh>
  );
}

function Ground({ stadium, graphics }: { stadium: Stadium; graphics: string }) {
  const r = Math.max(stadium.boundaryStraight, stadium.boundarySquare) * 0.95;
  return (
    <group>
      <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <circleGeometry args={[r, graphics === "Low" ? 24 : 48]} />
        <meshStandardMaterial color="#2f9e44" />
      </mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.01, 0]}>
        <ringGeometry args={[r - 0.4, r, graphics === "Low" ? 24 : 64]} />
        <meshStandardMaterial color="#e2e8f0" />
      </mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.015, 0]}>
        <planeGeometry args={[3.6, 22]} />
        <meshStandardMaterial color="#d6b370" />
      </mesh>
      {/* simple stands ring */}
      {graphics !== "Low" &&
        Array.from({ length: 16 }).map((_, i) => {
          const angle = (i / 16) * Math.PI * 2;
          return (
            <mesh key={i} position={[Math.sin(angle) * (r + 3), 2.2, Math.cos(angle) * (r + 3)]} rotation={[0, angle, 0]} castShadow>
              <boxGeometry args={[6, 4.4, 1.4]} />
              <meshStandardMaterial color={stadium.primaryColor} />
            </mesh>
          );
        })}
      {Array.from({ length: 4 }).map((_, i) => {
        const angle = (i / 4) * Math.PI * 2 + Math.PI / 4;
        return (
          <group key={i} position={[Math.sin(angle) * (r + 5), 0, Math.cos(angle) * (r + 5)]}>
            <mesh position={[0, 4, 0]} castShadow>
              <cylinderGeometry args={[0.15, 0.2, 8, 8]} />
              <meshStandardMaterial color="#94a3b8" />
            </mesh>
            <mesh position={[0, 8.2, 0]}>
              <boxGeometry args={[1.6, 0.5, 1.6]} />
              <meshStandardMaterial color="#e2e8f0" emissive="#fef9c3" emissiveIntensity={stadium.lighting === "Night" ? 1.4 : 0.15} />
            </mesh>
          </group>
        );
      })}
    </group>
  );
}

export function CricketScene({ stadium, phase, outcome, outcomeTick, battingColor, bowlingColor, graphics, shotSide }: CricketSceneProps) {
  const isNight = stadium.lighting === "Night";
  return (
    <Canvas shadows={graphics === "High"} dpr={graphics === "Low" ? 1 : [1, 1.5]} camera={{ position: [0, 6.5, 20], fov: 45 }}>
      <color attach="background" args={[isNight ? "#0a0f1f" : "#7dd3fc"]} />
      {isNight ? <fog attach="fog" args={["#0a0f1f", 20, 70]} /> : <fog attach="fog" args={["#bae6fd", 30, 90]} />}
      <ambientLight intensity={isNight ? 0.35 : 0.75} />
      <directionalLight position={[10, 20, 5]} intensity={isNight ? 0.3 : 1.1} castShadow={graphics === "High"} />
      {isNight && (
        <>
          <pointLight position={[15, 15, 15]} intensity={40} color="#fef9c3" />
          <pointLight position={[-15, 15, -15]} intensity={40} color="#fef9c3" />
        </>
      )}
      <Ground stadium={stadium} graphics={graphics} />
      <Stumps position={[0, 0, -9.8]} />
      <Stumps position={[0, 0, 9.8]} />
      <Batter color={battingColor} />
      <Bowler color={bowlingColor} phase={phase} />
      <AnimatedBall phase={phase} outcome={outcome} outcomeTick={outcomeTick} shotSide={shotSide} />
      {graphics !== "Low" && <Fielders boundary={Math.max(stadium.boundaryStraight, stadium.boundarySquare) * 0.85} color={bowlingColor} />}
    </Canvas>
  );
}
