import { useGameStore } from "../../state/store";

export function OutcomeBanner() {
  const outcome = useGameStore((s) => s.lastOutcome);
  const commentary = useGameStore((s) => s.lastCommentary);
  const phase = useGameStore((s) => s.ballPhase);
  if (phase !== "showing-outcome" || !outcome) return null;

  let big = "";
  let colorClass = "text-white";
  if (outcome.isWicket) {
    big = "WICKET!";
    colorClass = "text-rose-400";
  } else if (outcome.isSix) {
    big = "SIX!";
    colorClass = "text-purple-400";
  } else if (outcome.isBoundary) {
    big = "FOUR!";
    colorClass = "text-blue-400";
  } else if (outcome.extra === "wide") {
    big = "WIDE";
    colorClass = "text-amber-400";
  } else if (outcome.extra === "no-ball") {
    big = "NO BALL";
    colorClass = "text-amber-400";
  } else if (outcome.runs > 0) {
    big = `${outcome.runs} RUN${outcome.runs > 1 ? "S" : ""}`;
  } else {
    big = "DOT BALL";
    colorClass = "text-slate-400";
  }

  return (
    <div className="pointer-events-none absolute inset-x-0 top-16 z-20 flex flex-col items-center gap-2">
      <div className={`animate-[fadeIn_0.25s_ease-out] text-4xl font-black drop-shadow-lg sm:text-5xl ${colorClass}`}>{big}</div>
      {outcome.isWicket && outcome.dismissal && <div className="rounded bg-black/60 px-3 py-1 text-sm font-semibold text-white">{outcome.dismissal}</div>}
      {commentary && <div className="max-w-md rounded-lg bg-black/60 px-4 py-2 text-center text-sm text-slate-100">{commentary}</div>}
    </div>
  );
}
