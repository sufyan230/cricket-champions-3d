import { useEffect, useRef, useState } from "react";
import { useGameStore } from "../../state/store";
import { getPlayer } from "../../data/teams";
import { MeterBar, MeterHandle, meterQuality } from "./MeterBar";
import { DELIVERY_META } from "../../engine/ballMeta";
import { DeliveryType } from "../../state/matchTypes";
import { Button } from "../ui/Button";

const PACE_DELIVERIES: DeliveryType[] = ["fast", "yorker", "bouncer", "good-length", "slower", "swing", "seam"];
const SPIN_DELIVERIES: DeliveryType[] = ["off-spin", "leg-spin", "good-length", "slower"];

export function BowlingControls() {
  const match = useGameStore((s) => s.match)!;
  const ballPhase = useGameStore((s) => s.ballPhase);
  const humanBowl = useGameStore((s) => s.humanBowl);
  const [selected, setSelected] = useState<DeliveryType | null>(null);
  const meterRef = useRef<MeterHandle>(null);

  const innings = match.innings[match.currentInningsIndex];
  const bowler = getPlayer(innings.currentBowlerId);
  const isSpinner = bowler.bowlingType.includes("Spin") || bowler.bowlingType.includes("Orthodox") || bowler.bowlingType.includes("Wrist");
  const pool = isSpinner ? SPIN_DELIVERIES : PACE_DELIVERIES;

  useEffect(() => {
    setSelected(null);
  }, [ballPhase]);

  function release() {
    if (!selected) return;
    const value = meterRef.current?.getValue() ?? 0.5;
    const quality = meterQuality(value);
    humanBowl(selected, quality);
  }

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (ballPhase !== "need-delivery") return;
      if (e.key === "Enter" || e.key === " ") release();
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ballPhase, selected]);

  if (ballPhase !== "need-delivery") {
    return <div className="flex h-full items-center justify-center text-sm text-slate-400">…</div>;
  }

  return (
    <div className="flex flex-col gap-3 p-3">
      <div className="text-xs text-slate-400">Bowling: {bowler.shortName} ({bowler.bowlingType})</div>
      {!selected ? (
        <div className="grid grid-cols-3 gap-2 sm:grid-cols-4">
          {pool.map((d) => (
            <Button key={d} size="sm" variant="secondary" onClick={() => setSelected(d)}>
              {DELIVERY_META[d].label}
            </Button>
          ))}
        </div>
      ) : (
        <div className="flex flex-col gap-3">
          <div className="text-sm">
            Delivery: <span className="font-bold text-emerald-400">{DELIVERY_META[selected].label}</span>
          </div>
          <MeterBar ref={meterRef} periodMs={650} colorClass="bg-amber-400" label="Line & Length — release in the green zone" running />
          <div className="flex gap-2">
            <Button variant="gold" onClick={release}>
              Bowl (Click / Enter)
            </Button>
            <Button variant="ghost" onClick={() => setSelected(null)}>
              Change Delivery
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
