import { forwardRef, useEffect, useImperativeHandle, useRef } from "react";

export interface MeterHandle {
  getValue: () => number; // 0..1, current oscillator position
}

interface MeterBarProps {
  periodMs: number;
  colorClass?: string;
  label?: string;
  running?: boolean;
  narrow?: boolean;
}

// Shared oscillating meter used by BOTH the bowling accuracy meter and the batting
// timing system (Section 8/9/31/32). A marker bounces left-right across the bar;
// the caller reads getValue() at the instant of the player's key press / tap, so
// the exact same mechanic drives "line & length accuracy" for bowling and "shot
// timing" for batting, matching the architecture's ShotTimingSystem / BowlingMeter.
export const MeterBar = forwardRef<MeterHandle, MeterBarProps>(function MeterBar({ periodMs, colorClass = "bg-emerald-400", label, running = true, narrow }, ref) {
  const markerRef = useRef<HTMLDivElement>(null);
  const valueRef = useRef(0);
  const rafRef = useRef<number | null>(null);
  const startRef = useRef<number>(performance.now());

  useImperativeHandle(ref, () => ({ getValue: () => valueRef.current }));

  useEffect(() => {
    startRef.current = performance.now();
    function tick(t: number) {
      const elapsed = (t - startRef.current) % periodMs;
      const phase = elapsed / periodMs; // 0..1
      // triangle wave 0->1->0
      const v = phase < 0.5 ? phase * 2 : 2 - phase * 2;
      valueRef.current = v;
      if (markerRef.current) {
        markerRef.current.style.left = `${v * 100}%`;
      }
      if (running) rafRef.current = requestAnimationFrame(tick);
    }
    if (running) rafRef.current = requestAnimationFrame(tick);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, [periodMs, running]);

  return (
    <div className="w-full select-none">
      {label && <div className="mb-1 text-xs font-semibold uppercase tracking-wider text-slate-300">{label}</div>}
      <div className={`relative w-full ${narrow ? "h-3" : "h-5"} rounded-full bg-slate-800 border border-slate-600 overflow-hidden`}>
        <div className="absolute inset-y-0 left-[40%] right-[40%] bg-emerald-500/30 border-x border-emerald-400/50" />
        <div className="absolute inset-y-0 left-[46%] right-[46%] bg-emerald-400/60" />
        <div
          ref={markerRef}
          className={`absolute top-1/2 h-4 w-1.5 -translate-x-1/2 -translate-y-1/2 rounded-sm ${colorClass} shadow`}
          style={{ left: "0%" }}
        />
      </div>
    </div>
  );
});

export function meterQuality(value: number): number {
  return Math.max(0, Math.min(1, 1 - Math.abs(value - 0.5) * 2.1));
}

export function meterTiming(value: number, multiplier: number): number {
  return Math.max(-1, Math.min(1, 1 - Math.abs(value - 0.5) * multiplier));
}
