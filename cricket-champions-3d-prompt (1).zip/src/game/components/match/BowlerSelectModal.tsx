import { useGameStore } from "../../state/store";
import { teamXI } from "../../data/teams";
import { Button, Panel, SectionTitle } from "../ui/Button";

export function BowlerSelectModal() {
  const match = useGameStore((s) => s.match)!;
  const selectNextBowler = useGameStore((s) => s.selectNextBowler);
  const innings = match.innings[match.currentInningsIndex];
  const xi = teamXI(innings.bowlingTeamId).filter((p) => p.role === "Fast" || p.role === "Spinner" || p.role === "Allrounder");
  const cap = match.format.maxOversPerBowler;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4">
      <Panel className="w-full max-w-md p-6 text-white">
        <SectionTitle className="mb-4">Select Next Bowler</SectionTitle>
        <div className="flex max-h-80 flex-col gap-2 overflow-y-auto">
          {xi.map((p) => {
            const stats = innings.bowlers[p.id];
            const overs = stats ? stats.legalBalls / 6 : 0;
            const capped = cap != null && overs >= cap;
            const sameAsLast = p.id === innings.currentBowlerId;
            return (
              <Button key={p.id} variant="secondary" disabled={capped || sameAsLast} onClick={() => selectNextBowler(p.id)} className="justify-between">
                <span>{p.displayName}</span>
                <span className="text-xs opacity-60">
                  {stats ? `${Math.floor(stats.legalBalls / 6)}.${stats.legalBalls % 6}-${stats.runsConceded}-${stats.wickets}` : "0.0-0-0"}
                </span>
              </Button>
            );
          })}
        </div>
      </Panel>
    </div>
  );
}
