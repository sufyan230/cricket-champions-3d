import { useState } from "react";
import { useGameStore } from "../../state/store";
import { DIFFICULTIES } from "../../data/formats";
import { Difficulty } from "../../data/types";
import { Button, Panel, SectionTitle } from "../ui/Button";

const CHANNELS = ["master", "commentary", "crowd", "effects", "music"] as const;

export function SettingsScreen() {
  const save = useGameStore((s) => s.save);
  const goTo = useGameStore((s) => s.goTo);
  const previousScreen = useGameStore((s) => s.previousScreen);
  const setVolume = useGameStore((s) => s.setVolume);
  const setGraphics = useGameStore((s) => s.setGraphics);
  const setDifficulty = useGameStore((s) => s.setDifficulty);
  const toggleSetting = useGameStore((s) => s.toggleSetting);
  const setKeyBinding = useGameStore((s) => s.setKeyBinding);
  const [listening, setListening] = useState<string | null>(null);

  return (
    <div
      className="min-h-screen bg-slate-950 px-4 py-8 text-white"
      onKeyDown={(e) => {
        if (listening) {
          setKeyBinding(listening, e.key);
          setListening(null);
        }
      }}
      tabIndex={-1}
    >
      <div className="mx-auto max-w-2xl">
        <div className="mb-6 flex items-center justify-between">
          <SectionTitle>Settings</SectionTitle>
          <Button variant="secondary" onClick={() => goTo(previousScreen === "settings" ? "menu" : previousScreen)}>
            Back
          </Button>
        </div>

        <Panel className="mb-4 p-5">
          <h3 className="mb-3 font-bold text-emerald-400">Audio</h3>
          {CHANNELS.map((c) => (
            <div key={c} className="mb-2 flex items-center gap-3">
              <span className="w-28 text-sm capitalize">{c}</span>
              <input
                type="range"
                min={0}
                max={1}
                step={0.05}
                value={save.settings.volumes[c]}
                onChange={(e) => setVolume(c, parseFloat(e.target.value))}
                className="flex-1"
              />
              <span className="w-10 text-right text-xs text-slate-400">{Math.round(save.settings.volumes[c] * 100)}%</span>
            </div>
          ))}
        </Panel>

        <Panel className="mb-4 p-5">
          <h3 className="mb-3 font-bold text-emerald-400">Graphics</h3>
          <div className="flex gap-2">
            {(["Low", "Medium", "High"] as const).map((g) => (
              <Button key={g} size="sm" variant={save.settings.graphics === g ? "primary" : "secondary"} onClick={() => setGraphics(g)}>
                {g}
              </Button>
            ))}
          </div>
        </Panel>

        <Panel className="mb-4 p-5">
          <h3 className="mb-3 font-bold text-emerald-400">Gameplay</h3>
          <div className="mb-3 flex gap-2 flex-wrap">
            {Object.values(DIFFICULTIES).map((d) => (
              <Button key={d.id} size="sm" variant={save.settings.difficulty === d.id ? "primary" : "secondary"} onClick={() => setDifficulty(d.id as Difficulty)}>
                {d.id}
              </Button>
            ))}
          </div>
          <div className="flex flex-col gap-2 text-sm">
            <ToggleRow label="Auto Fielding" value={save.settings.autoFielding} onToggle={() => toggleSetting("autoFielding")} />
            <ToggleRow label="Auto Running" value={save.settings.autoRunning} onToggle={() => toggleSetting("autoRunning")} />
            <ToggleRow label="Vibration (mobile)" value={save.settings.vibration} onToggle={() => toggleSetting("vibration")} />
            <ToggleRow label="Use Real Player/Team Names" value={save.settings.useRealNames} onToggle={() => toggleSetting("useRealNames")} />
          </div>
        </Panel>

        <Panel className="p-5">
          <h3 className="mb-3 font-bold text-emerald-400">Controls (PC key bindings)</h3>
          <div className="grid grid-cols-2 gap-2 text-sm">
            {Object.entries(save.settings.keyBindings).map(([action, key]) => (
              <button
                key={action}
                onClick={() => setListening(action)}
                className="flex items-center justify-between rounded-lg bg-slate-800 px-3 py-2 hover:bg-slate-700"
              >
                <span className="capitalize text-slate-300">{action}</span>
                <span className="rounded bg-slate-900 px-2 py-0.5 font-mono text-emerald-400">
                  {listening === action ? "press a key…" : key === " " ? "Space" : key}
                </span>
              </button>
            ))}
          </div>
          <p className="mt-2 text-xs text-slate-500">Click a binding then press any key to remap it.</p>
        </Panel>
      </div>
    </div>
  );
}

function ToggleRow({ label, value, onToggle }: { label: string; value: boolean; onToggle: () => void }) {
  return (
    <div className="flex items-center justify-between">
      <span>{label}</span>
      <button onClick={onToggle} className={`h-6 w-11 rounded-full transition ${value ? "bg-emerald-500" : "bg-slate-700"}`}>
        <span className={`block h-5 w-5 translate-y-0.5 rounded-full bg-white transition ${value ? "translate-x-5" : "translate-x-0.5"}`} />
      </button>
    </div>
  );
}
