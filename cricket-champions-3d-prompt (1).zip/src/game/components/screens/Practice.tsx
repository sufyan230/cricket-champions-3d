import { useGameStore } from "../../state/store";
import { MatchScreen } from "./MatchScreen";
import { Button, Panel, SectionTitle } from "../ui/Button";

export function PracticeScreen() {
  const practice = useGameStore((s) => s.practice);
  const startPractice = useGameStore((s) => s.startPractice);
  const endPractice = useGameStore((s) => s.endPractice);
  const goTo = useGameStore((s) => s.goTo);

  if (practice && practice.active) {
    return (
      <div className="relative h-screen">
        <MatchScreen chrome="practice" />
        <div className="absolute left-3 bottom-[200px] z-30 rounded-lg bg-black/70 p-3 text-xs text-white">
          <div>Balls: {practice.ballsFaced}</div>
          <div>Runs: {practice.runs}</div>
          <div>4s/6s: {practice.fours}/{practice.sixes}</div>
          <div>Wickets: {practice.wickets}</div>
          <button onClick={endPractice} className="mt-2 rounded bg-rose-600 px-2 py-1 font-bold">
            End Practice
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-slate-950 px-4 text-white">
      <SectionTitle className="mb-6">Practice Nets</SectionTitle>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <Panel className="p-6 text-center">
          <div className="mb-2 text-3xl">🏏</div>
          <div className="mb-3 font-bold">Batting Practice</div>
          <Button onClick={() => startPractice("batting")}>Start</Button>
        </Panel>
        <Panel className="p-6 text-center">
          <div className="mb-2 text-3xl">🎯</div>
          <div className="mb-3 font-bold">Bowling Practice</div>
          <Button onClick={() => startPractice("bowling")}>Start</Button>
        </Panel>
      </div>
      <Button variant="secondary" className="mt-8" onClick={() => goTo("menu")}>
        Back to Menu
      </Button>
    </div>
  );
}
