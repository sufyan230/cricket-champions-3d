import { useGameStore } from "../../state/store";
import { Button, Panel, SectionTitle } from "../ui/Button";

const SECTIONS = [
  {
    title: "Batting",
    body:
      "When it's your team's turn to bat, watch the oscillating Timing meter. Press a shot key (or tap a shot button on mobile) the instant the marker sits in the bright green centre zone for a Perfect timed shot. PC: A = leg-side shot, D = off-side shot, W = Loft, S = Defend, Space = Straight, Shift = Power shot. Mobile: tap Defend / Drive / Loft / Sweep / Cut / Pull / Power directly.",
  },
  {
    title: "Bowling",
    body:
      "Pick a delivery type suited to your bowler (pace bowlers get yorkers/bouncers/swing, spinners get off-spin/leg-spin), then release when the accuracy marker is in the green zone for a well-executed ball. Poor releases risk wides, no-balls and cheap boundaries.",
  },
  {
    title: "Running & Scoring",
    body:
      "Runs, boundaries and wickets are resolved automatically from your shot quality versus the bowler and fielding side, exactly like a real ball's outcome — dot balls, 1s/2s/3s, fours, sixes, and all dismissal types (Bowled, LBW, Caught, Stumped, Run Out, Hit Wicket) are tracked ball by ball on the scoreboard.",
  },
  {
    title: "Fielding",
    body:
      "Fielding is AI-assisted automatically based on your bowling side's fielding ratings and the active difficulty — sharper fielding sides catch more mishits and cut down boundaries.",
  },
  {
    title: "Match Flow",
    body:
      "Win the toss (or let the AI decide if you lose it), choose to bat or bowl, play out your innings, then chase or defend in the second innings. Ties in limited-overs formats trigger a Super Over.",
  },
];

export function TutorialScreen() {
  const goTo = useGameStore((s) => s.goTo);
  return (
    <div className="min-h-screen bg-slate-950 px-4 py-10 text-white">
      <div className="mx-auto max-w-2xl">
        <SectionTitle className="mb-6">How To Play</SectionTitle>
        <div className="flex flex-col gap-4">
          {SECTIONS.map((s) => (
            <Panel key={s.title} className="p-5">
              <h3 className="mb-2 font-bold text-emerald-400">{s.title}</h3>
              <p className="text-sm text-slate-300">{s.body}</p>
            </Panel>
          ))}
        </div>
        <div className="mt-8 flex justify-center">
          <Button variant="gold" onClick={() => goTo("menu")}>
            Got it
          </Button>
        </div>
      </div>
    </div>
  );
}
