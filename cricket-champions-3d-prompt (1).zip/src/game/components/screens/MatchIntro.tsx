import { useGameStore } from "../../state/store";

export function MatchIntro() {
  const match = useGameStore((s) => s.match);
  if (!match) return null;
  const battingFirst = match.battingFirstTeamId === match.teamA.id ? match.teamA : match.teamB;
  const bowlingFirst = match.battingFirstTeamId === match.teamA.id ? match.teamB : match.teamA;

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-black text-white">
      <div className="flex items-center gap-10">
        <TeamBadge name={battingFirst.name} color={battingFirst.color} />
        <div className="text-3xl font-black text-slate-500">VS</div>
        <TeamBadge name={bowlingFirst.name} color={bowlingFirst.color} />
      </div>
      <p className="mt-8 text-lg text-slate-300">{match.stadium.name}, {match.stadium.city}</p>
      <p className="text-sm text-slate-500">{match.format.name} · {match.weather}</p>
      <p className="mt-2 font-semibold text-emerald-400">{battingFirst.name} chose to bat first</p>
    </div>
  );
}

function TeamBadge({ name, color }: { name: string; color: string }) {
  return (
    <div className="flex flex-col items-center gap-3 animate-[fadeIn_0.6s_ease-out]">
      <div className="h-24 w-24 rounded-full border-4 border-white/20" style={{ backgroundColor: color }} />
      <div className="text-xl font-bold">{name}</div>
    </div>
  );
}
