import { useGameStore } from "../../state/store";
import { getPlayer, getTeam } from "../../data/teams";
import { InningsState } from "../../state/matchTypes";
import { Button, Panel, SectionTitle } from "../ui/Button";

export function Scorecard() {
  const match = useGameStore((s) => s.match);
  const goTo = useGameStore((s) => s.goTo);
  const previousScreen = useGameStore((s) => s.previousScreen);
  if (!match) return null;

  return (
    <div className="min-h-screen bg-slate-950 px-4 py-8 text-white">
      <div className="mx-auto max-w-3xl">
        <div className="mb-6 flex items-center justify-between">
          <SectionTitle>Full Scorecard</SectionTitle>
          <Button
            variant="secondary"
            onClick={() => goTo(previousScreen === "scorecard" ? "menu" : previousScreen)}
          >
            Back
          </Button>
        </div>
        {match.innings.map((inn, idx) => (
          <InningsCard key={idx} innings={inn} label={`Innings ${idx + 1}`} />
        ))}
      </div>
    </div>
  );
}

function InningsCard({ innings, label }: { innings: InningsState; label: string }) {
  const team = getTeam(innings.battingTeamId);
  const batters = innings.battingOrder.map((id) => innings.batters[id]).filter(Boolean);
  const bowlers = Object.values(innings.bowlers);

  return (
    <Panel className="mb-6 p-5">
      <div className="mb-3 flex items-center justify-between">
        <div className="font-bold">
          {label}: {team.name}
        </div>
        <div className="font-black text-emerald-400">
          {innings.runs}/{innings.wickets} ({Math.floor(innings.legalBalls / 6)}.{innings.legalBalls % 6})
        </div>
      </div>
      <table className="mb-4 w-full text-sm">
        <thead className="text-left text-slate-400">
          <tr>
            <th className="py-1">Batter</th>
            <th>R</th>
            <th>B</th>
            <th>4s</th>
            <th>6s</th>
            <th>SR</th>
            <th>Dismissal</th>
          </tr>
        </thead>
        <tbody>
          {batters.map((b) => (
            <tr key={b.playerId} className="border-t border-white/5">
              <td className="py-1">{getPlayer(b.playerId).displayName}</td>
              <td>{b.runs}</td>
              <td>{b.balls}</td>
              <td>{b.fours}</td>
              <td>{b.sixes}</td>
              <td>{b.balls ? ((b.runs / b.balls) * 100).toFixed(1) : "0.0"}</td>
              <td className="text-slate-400">{b.out ? b.dismissal : "not out"}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="mb-2 text-xs text-slate-500">
        Extras: {innings.extras.wide + innings.extras.noBall + innings.extras.bye + innings.extras.legBye} (wd {innings.extras.wide}, nb {innings.extras.noBall}, b {innings.extras.bye}, lb {innings.extras.legBye})
      </div>
      <table className="w-full text-sm">
        <thead className="text-left text-slate-400">
          <tr>
            <th className="py-1">Bowler</th>
            <th>O</th>
            <th>M</th>
            <th>R</th>
            <th>W</th>
            <th>Econ</th>
          </tr>
        </thead>
        <tbody>
          {bowlers.map((b) => (
            <tr key={b.playerId} className="border-t border-white/5">
              <td className="py-1">{getPlayer(b.playerId).displayName}</td>
              <td>
                {Math.floor(b.legalBalls / 6)}.{b.legalBalls % 6}
              </td>
              <td>{b.maidens}</td>
              <td>{b.runsConceded}</td>
              <td>{b.wickets}</td>
              <td>{b.legalBalls ? (b.runsConceded / (b.legalBalls / 6)).toFixed(2) : "0.00"}</td>
            </tr>
          ))}
        </tbody>
      </table>
      {innings.fallOfWickets.length > 0 && (
        <div className="mt-3 text-xs text-slate-400">
          FoW: {innings.fallOfWickets.map((f, i) => `${f.score}-${i + 1} (${getPlayer(f.playerId).shortName}, ${f.overs} ov)`).join(", ")}
        </div>
      )}
    </Panel>
  );
}
