import { useGameStore } from "../../state/store";
import { CHALLENGES } from "../../data/formats";
import { MatchScreen } from "./MatchScreen";
import { Button, Panel, SectionTitle } from "../ui/Button";

export function ChallengesScreen() {
  const challenge = useGameStore((s) => s.challenge);
  const startChallenge = useGameStore((s) => s.startChallenge);
  const goTo = useGameStore((s) => s.goTo);

  if (challenge && !challenge.finished) {
    return <MatchScreen chrome="challenge" />;
  }

  return (
    <div className="flex min-h-screen flex-col items-center bg-slate-950 px-4 py-10 text-white">
      <SectionTitle className="mb-6">Challenges</SectionTitle>
      <div className="grid w-full max-w-3xl grid-cols-1 gap-4 sm:grid-cols-2">
        {CHALLENGES.map((c) => (
          <Panel key={c.id} className="p-5">
            <div className="mb-1 font-bold text-amber-400">{c.title}</div>
            <div className="mb-3 text-sm text-slate-400">{c.description}</div>
            <Button size="sm" onClick={() => startChallenge(c.id)}>
              Attempt
            </Button>
          </Panel>
        ))}
      </div>
      <Button variant="secondary" className="mt-8" onClick={() => goTo("menu")}>
        Back to Menu
      </Button>
    </div>
  );
}
