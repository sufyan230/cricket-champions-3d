import { useState } from "react";
import { useGameStore } from "../../state/store";
import { TEAMS } from "../../data/teams";
import { Button, Panel, SectionTitle } from "../ui/Button";

export function CareerScreen() {
  const save = useGameStore((s) => s.save);
  const goTo = useGameStore((s) => s.goTo);
  const createCareerPlayer = useGameStore((s) => s.createCareerPlayer);
  const updateSetup = useGameStore((s) => s.updateSetup);

  const [name, setName] = useState("");
  const [country, setCountry] = useState(TEAMS[0].id);
  const [battingHand, setBattingHand] = useState<"Right" | "Left">("Right");
  const [battingStyle, setBattingStyle] = useState<"Aggressive" | "Balanced" | "Defensive">("Balanced");
  const [bowlingType, setBowlingType] = useState("Medium");

  if (!save.career.player) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-950 px-4 py-10 text-white">
        <Panel className="w-full max-w-lg p-6">
          <SectionTitle className="mb-4">Create Your Player</SectionTitle>
          <div className="flex flex-col gap-3">
            <input
              className="rounded-lg bg-slate-800 px-3 py-2 outline-none"
              placeholder="Player name"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
            <select className="rounded-lg bg-slate-800 px-3 py-2" value={country} onChange={(e) => setCountry(e.target.value)}>
              {TEAMS.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.name}
                </option>
              ))}
            </select>
            <div className="flex gap-2">
              {(["Right", "Left"] as const).map((h) => (
                <Button key={h} size="sm" variant={battingHand === h ? "primary" : "secondary"} onClick={() => setBattingHand(h)}>
                  {h}-handed
                </Button>
              ))}
            </div>
            <div className="flex gap-2">
              {(["Aggressive", "Balanced", "Defensive"] as const).map((b) => (
                <Button key={b} size="sm" variant={battingStyle === b ? "primary" : "secondary"} onClick={() => setBattingStyle(b)}>
                  {b}
                </Button>
              ))}
            </div>
            <select className="rounded-lg bg-slate-800 px-3 py-2" value={bowlingType} onChange={(e) => setBowlingType(e.target.value)}>
              {["Fast", "Medium Fast", "Swing", "Off Spin", "Leg Spin"].map((b) => (
                <option key={b} value={b}>
                  {b}
                </option>
              ))}
            </select>
            <div className="mt-3 flex gap-3">
              <Button variant="secondary" onClick={() => goTo("menu")}>
                Cancel
              </Button>
              <Button
                variant="gold"
                disabled={!name.trim()}
                onClick={() => {
                  createCareerPlayer({ name, country, battingHand, bowlingType, battingStyle });
                  updateSetup({ mode: "career", teamAId: country });
                }}
              >
                Start Career
              </Button>
            </div>
          </div>
        </Panel>
      </div>
    );
  }

  const stats = save.career.stats;
  const avg = stats.innings > 0 ? (stats.runs / Math.max(1, stats.innings - (stats.matches - stats.innings))).toFixed(1) : "0.0";
  const sr = stats.ballsFaced > 0 ? ((stats.runs / stats.ballsFaced) * 100).toFixed(1) : "0.0";
  const econ = stats.ballsBowled > 0 ? (stats.runsConceded / (stats.ballsBowled / 6)).toFixed(2) : "0.00";

  return (
    <div className="min-h-screen bg-slate-950 px-4 py-8 text-white">
      <div className="mx-auto max-w-3xl">
        <div className="mb-6 flex items-center justify-between">
          <SectionTitle>{save.career.player.name}'s Career</SectionTitle>
          <Button variant="secondary" onClick={() => goTo("menu")}>
            Back
          </Button>
        </div>
        <Panel className="mb-4 p-5">
          <div className="flex flex-wrap items-center gap-6 text-sm">
            <Stat label="Level" value={save.level} />
            <Stat label="XP" value={save.xp} />
            <Stat label="Coins" value={save.coins} />
            <Stat label="Matches" value={stats.matches} />
            <Stat label="W/L/T" value={`${stats.wins}/${stats.losses}/${stats.ties}`} />
          </div>
        </Panel>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <Panel className="p-5">
            <h3 className="mb-2 font-bold text-emerald-400">Batting</h3>
            <Stat label="Runs" value={stats.runs} />
            <Stat label="Average" value={avg} />
            <Stat label="Strike Rate" value={sr} />
            <Stat label="50s / 100s" value={`${stats.fifties} / ${stats.hundreds}`} />
            <Stat label="Highest Score" value={stats.highestScore} />
            <Stat label="4s / 6s" value={`${stats.fours} / ${stats.sixes}`} />
          </Panel>
          <Panel className="p-5">
            <h3 className="mb-2 font-bold text-emerald-400">Bowling</h3>
            <Stat label="Wickets" value={stats.wickets} />
            <Stat label="Economy" value={econ} />
            <Stat label="Runs Conceded" value={stats.runsConceded} />
          </Panel>
        </div>
        <div className="mt-6 flex justify-center">
          <Button
            variant="gold"
            size="lg"
            onClick={() => {
              updateSetup({ mode: "career", teamAId: save.career.player!.country, localMultiplayer: false });
              goTo("team-select");
            }}
          >
            Play Career Match
          </Button>
        </div>
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="flex justify-between gap-4 border-b border-white/5 py-1 text-sm">
      <span className="text-slate-400">{label}</span>
      <span className="font-bold">{value}</span>
    </div>
  );
}
