import { useGameStore } from "../../state/store";
import { getTeam } from "../../data/teams";
import { Button, Panel, SectionTitle } from "../ui/Button";

export function TournamentScreen() {
  const tournament = useGameStore((s) => s.tournament);
  const startTournament = useGameStore((s) => s.startTournament);
  const simulateFixture = useGameStore((s) => s.simulateFixture);
  const playTournamentFixture = useGameStore((s) => s.playTournamentFixture);
  const goTo = useGameStore((s) => s.goTo);
  const setup = useGameStore((s) => s.setup);

  if (!tournament.active) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center bg-slate-950 px-4 text-white">
        <SectionTitle className="mb-4">World Championship</SectionTitle>
        <p className="mb-6 max-w-md text-center text-slate-400">
          6 teams, round robin group stage, top 4 advance to semi-finals, then the final. Play your team's fixtures — the rest simulate instantly.
        </p>
        <div className="flex gap-3">
          <Button variant="secondary" onClick={() => goTo("menu")}>
            Back
          </Button>
          <Button variant="gold" size="lg" onClick={startTournament}>
            Start Tournament
          </Button>
        </div>
      </div>
    );
  }

  const humanTeam = setup.teamAId;

  return (
    <div className="min-h-screen bg-slate-950 px-4 py-8 text-white">
      <div className="mx-auto max-w-4xl">
        <div className="mb-6 flex items-center justify-between">
          <SectionTitle>Tournament — {tournament.stage.toUpperCase()}</SectionTitle>
          <Button variant="secondary" onClick={() => goTo("menu")}>
            Menu
          </Button>
        </div>

        <Panel className="mb-6 overflow-x-auto p-4">
          <table className="w-full text-sm">
            <thead className="text-left text-slate-400">
              <tr>
                <th className="py-1">Team</th>
                <th>P</th>
                <th>W</th>
                <th>L</th>
                <th>T</th>
                <th>Pts</th>
                <th>NRR</th>
              </tr>
            </thead>
            <tbody>
              {[...tournament.table]
                .sort((a, b) => b.points - a.points || b.nrr - a.nrr)
                .map((r) => (
                  <tr key={r.teamId} className="border-t border-white/5">
                    <td className="py-1 font-semibold">{getTeam(r.teamId).name}</td>
                    <td>{r.played}</td>
                    <td>{r.won}</td>
                    <td>{r.lost}</td>
                    <td>{r.tied}</td>
                    <td className="font-bold text-emerald-400">{r.points}</td>
                    <td>{r.nrr.toFixed(2)}</td>
                  </tr>
                ))}
            </tbody>
          </table>
        </Panel>

        {tournament.stage === "group" && (
          <FixtureList fixtures={tournament.fixtures} humanTeam={humanTeam} onPlay={playTournamentFixture} onSim={simulateFixture} />
        )}
        {tournament.stage === "semi" && tournament.semiFixtures && (
          <FixtureList fixtures={tournament.semiFixtures} humanTeam={humanTeam} onPlay={playTournamentFixture} onSim={simulateFixture} title="Semi-Finals" />
        )}
        {tournament.stage === "final" && tournament.finalFixture && (
          <FixtureList fixtures={[tournament.finalFixture]} humanTeam={humanTeam} onPlay={playTournamentFixture} onSim={simulateFixture} title="Final" />
        )}
        {tournament.stage === "done" && tournament.champion && (
          <Panel className="p-8 text-center">
            <div className="mb-2 text-5xl">🏆</div>
            <div className="text-2xl font-black text-amber-400">{getTeam(tournament.champion).name} are Champions!</div>
          </Panel>
        )}
      </div>
    </div>
  );
}

function FixtureList({
  fixtures,
  humanTeam,
  onPlay,
  onSim,
  title = "Fixtures",
}: {
  fixtures: { a: string; b: string; played: boolean; result?: string }[];
  humanTeam: string;
  onPlay: (idx: number) => void;
  onSim: (idx: number) => void;
  title?: string;
}) {
  return (
    <Panel className="p-4">
      <h3 className="mb-3 font-bold text-emerald-400">{title}</h3>
      <div className="flex flex-col gap-2">
        {fixtures.map((f, i) => (
          <div key={i} className="flex items-center justify-between rounded-lg bg-slate-900 px-3 py-2 text-sm">
            <span>
              {getTeam(f.a).shortName} vs {getTeam(f.b).shortName}
            </span>
            {f.played ? (
              <span className="text-xs text-slate-400">{f.result}</span>
            ) : f.a === humanTeam || f.b === humanTeam ? (
              <Button size="sm" onClick={() => onPlay(i)}>
                Play
              </Button>
            ) : (
              <Button size="sm" variant="secondary" onClick={() => onSim(i)}>
                Simulate
              </Button>
            )}
          </div>
        ))}
      </div>
    </Panel>
  );
}
