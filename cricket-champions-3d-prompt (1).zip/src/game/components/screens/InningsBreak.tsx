import { useGameStore } from "../../state/store";
import { getPlayer, getTeam } from "../../data/teams";
import { Button, Panel, SectionTitle } from "../ui/Button";

export function InningsBreak() {
  const match = useGameStore((s) => s.match);
  const goTo = useGameStore((s) => s.goTo);
  const beginInnings = useGameStore((s) => s.beginInnings);
  if (!match) return null;
  const first = match.innings[0];
  const battingTeam = getTeam(first.battingTeamId);
  const chasingTeam = getTeam(first.bowlingTeamId);
  const topBatters = Object.values(first.batters).sort((a, b) => b.runs - a.runs).slice(0, 3);
  const topBowlers = Object.values(first.bowlers).sort((a, b) => b.wickets - a.wickets).slice(0, 3);

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-slate-950 px-4 py-10 text-white">
      <SectionTitle className="mb-1 text-2xl">Innings Break</SectionTitle>
      <p className="mb-6 text-slate-400">
        {battingTeam.name} posted {first.runs}/{first.wickets} in {Math.floor(first.legalBalls / 6)}.{first.legalBalls % 6} overs
      </p>
      <div className="grid w-full max-w-3xl grid-cols-1 gap-4 sm:grid-cols-2">
        <Panel className="p-4">
          <div className="mb-2 text-sm font-bold uppercase text-emerald-400">Top Batting</div>
          {topBatters.map((b) => (
            <div key={b.playerId} className="flex justify-between text-sm py-1 border-b border-white/5">
              <span>{getPlayer(b.playerId).displayName}</span>
              <span>
                {b.runs}({b.balls}) {b.dismissal ? "" : "*"}
              </span>
            </div>
          ))}
        </Panel>
        <Panel className="p-4">
          <div className="mb-2 text-sm font-bold uppercase text-emerald-400">Top Bowling</div>
          {topBowlers.map((b) => (
            <div key={b.playerId} className="flex justify-between text-sm py-1 border-b border-white/5">
              <span>{getPlayer(b.playerId).displayName}</span>
              <span>
                {Math.floor(b.legalBalls / 6)}.{b.legalBalls % 6}-{b.runsConceded}-{b.wickets}
              </span>
            </div>
          ))}
        </Panel>
      </div>
      <p className="mt-6 text-lg font-semibold text-amber-300">{chasingTeam.name} need {first.runs + 1} runs to win</p>
      <div className="mt-8 flex gap-3">
        <Button variant="secondary" onClick={() => goTo("scorecard")}>
          View Full Scorecard
        </Button>
        <Button
          variant="gold"
          size="lg"
          onClick={() => {
            goTo("innings");
            beginInnings();
          }}
        >
          Start 2nd Innings
        </Button>
      </div>
    </div>
  );
}
