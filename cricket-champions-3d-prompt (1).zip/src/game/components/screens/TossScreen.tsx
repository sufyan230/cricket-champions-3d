import { useState } from "react";
import { useGameStore } from "../../state/store";
import { getTeam } from "../../data/teams";
import { Button, Panel, SectionTitle } from "../ui/Button";

export function TossScreen() {
  const setup = useGameStore((s) => s.setup);
  const tossState = useGameStore((s) => s.tossState);
  const callToss = useGameStore((s) => s.callToss);
  const chooseBatBowl = useGameStore((s) => s.chooseBatBowl);
  const [flipping, setFlipping] = useState(false);

  const teamA = getTeam(setup.teamAId);
  const teamB = getTeam(setup.teamBId);

  function handleCall(call: "Heads" | "Tails") {
    setFlipping(true);
    setTimeout(() => {
      callToss(call);
      setFlipping(false);
    }, 1200);
  }

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-gradient-to-b from-slate-950 to-emerald-950 px-4 text-white">
      <SectionTitle className="mb-2 text-2xl">Toss Time</SectionTitle>
      <p className="mb-8 text-slate-400">
        {teamA.name} vs {teamB.name}
      </p>

      <div className={`mb-8 h-24 w-24 rounded-full bg-gradient-to-br from-amber-300 to-amber-600 shadow-2xl ${flipping ? "animate-spin" : ""}`} />

      {!tossState.result && !flipping && (
        <Panel className="p-6 text-center">
          <p className="mb-4 font-semibold">Call it in the air:</p>
          <div className="flex gap-4">
            <Button onClick={() => handleCall("Heads")}>Heads</Button>
            <Button onClick={() => handleCall("Tails")}>Tails</Button>
          </div>
        </Panel>
      )}

      {tossState.result && (
        <Panel className="p-6 text-center">
          <p className="mb-2 text-lg">
            It's <span className="font-bold text-amber-400">{tossState.result}</span>!
          </p>
          {tossState.winnerIsPlayer ? (
            <>
              <p className="mb-4 font-semibold text-emerald-400">{teamA.name} won the toss!</p>
              {!tossState.choiceMade && (
                <div className="flex justify-center gap-4">
                  <Button onClick={() => chooseBatBowl("Bat")}>Bat First</Button>
                  <Button onClick={() => chooseBatBowl("Bowl")}>Bowl First</Button>
                </div>
              )}
            </>
          ) : (
            <p className="font-semibold text-rose-400">{teamB.name} won the toss and are deciding…</p>
          )}
        </Panel>
      )}
    </div>
  );
}
