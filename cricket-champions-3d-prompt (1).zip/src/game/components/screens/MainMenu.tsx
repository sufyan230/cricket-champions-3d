import { useGameStore } from "../../state/store";
import { Button, Panel } from "../ui/Button";

export function MainMenu() {
  const goTo = useGameStore((s) => s.goTo);
  const updateSetup = useGameStore((s) => s.updateSetup);
  const save = useGameStore((s) => s.save);

  const items: { label: string; desc: string; action: () => void; variant?: "primary" | "gold" | "secondary" }[] = [
    {
      label: "PLAY",
      desc: "Quick Match, T20, ODI",
      action: () => {
        updateSetup({ mode: "quick", localMultiplayer: false });
        goTo("team-select");
      },
      variant: "gold",
    },
    { label: "CAREER", desc: "Create a player & rise to stardom", action: () => goTo("career") },
    { label: "TOURNAMENT", desc: "World Cup style group + knockout", action: () => goTo("tournament") },
    { label: "PRACTICE", desc: "Batting & bowling nets", action: () => goTo("practice") },
    { label: "CHALLENGES", desc: "Beat the scenario", action: () => goTo("challenges") },
    {
      label: "LOCAL MULTIPLAYER",
      desc: "Two players, one device",
      action: () => {
        updateSetup({ mode: "quick", localMultiplayer: true });
        goTo("team-select");
      },
    },
    { label: "SETTINGS", desc: "Graphics, audio, controls", action: () => goTo("settings") },
    { label: "TUTORIAL", desc: "Learn the controls", action: () => goTo("tutorial") },
  ];

  return (
    <div className="relative flex min-h-screen flex-col items-center justify-center overflow-hidden bg-[radial-gradient(circle_at_top,_#134e2a,_#04140a_70%)] px-6 py-10 text-white">
      <div className="pointer-events-none absolute inset-0 opacity-20" style={{ backgroundImage: "repeating-linear-gradient(0deg, transparent, transparent 38px, rgba(255,255,255,0.06) 39px)" }} />
      <div className="z-10 mb-8 text-center">
        <div className="mb-2 inline-block rounded-full bg-emerald-500/20 px-4 py-1 text-xs font-bold uppercase tracking-[0.3em] text-emerald-300">Arcade Cricket</div>
        <h1 className="bg-gradient-to-b from-white to-emerald-200 bg-clip-text text-5xl font-black tracking-tight text-transparent drop-shadow-lg sm:text-6xl">
          CRICKET CHAMPIONS 3D
        </h1>
        <p className="mt-3 text-sm text-emerald-100/80">Level {save.level} · {save.coins} coins · {save.xp} XP</p>
      </div>

      <div className="z-10 grid w-full max-w-4xl grid-cols-1 gap-3 sm:grid-cols-2">
        {items.map((it) => (
          <Panel key={it.label} className="p-0">
            <button
              onClick={it.action}
              className="flex w-full items-center justify-between rounded-2xl px-6 py-5 text-left transition hover:bg-white/5 active:scale-[0.99]"
            >
              <div>
                <div className="text-lg font-extrabold tracking-wide">{it.label}</div>
                <div className="text-sm text-slate-400">{it.desc}</div>
              </div>
              <div className="text-2xl text-emerald-400">›</div>
            </button>
          </Panel>
        ))}
      </div>

      <div className="z-10 mt-8 flex gap-3">
        <Button variant="secondary" size="sm" onClick={() => goTo("roster-editor")}>
          Roster Editor
        </Button>
        <Button
          variant="danger"
          size="sm"
          onClick={() => {
            if (confirm("Exit game?")) window.close();
          }}
        >
          Exit
        </Button>
      </div>
      <p className="z-10 mt-6 max-w-xl text-center text-xs text-slate-500">
        Built as a browser-based 3D cricket experience. Player names are drawn from a data-driven, editable roster file — see Settings to toggle fictional names.
      </p>
    </div>
  );
}
