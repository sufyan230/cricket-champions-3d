import { useEffect, useMemo, useRef } from "react";
import { useGameStore } from "../../state/store";
import { CricketScene } from "../match/CricketScene";
import { Scoreboard } from "../match/Scoreboard";
import { BattingControls } from "../match/BattingControls";
import { BowlingControls } from "../match/BowlingControls";
import { BowlerSelectModal } from "../match/BowlerSelectModal";
import { OutcomeBanner } from "../match/OutcomeBanner";
import { getTeam } from "../../data/teams";

export function MatchScreen({ chrome }: { chrome?: "innings" | "practice" | "challenge" }) {
  const match = useGameStore((s) => s.match);
  const ballPhase = useGameStore((s) => s.ballPhase);
  const continueAfterOutcome = useGameStore((s) => s.continueAfterOutcome);
  const setPaused = useGameStore((s) => s.setPaused);
  const save = useGameStore((s) => s.save);
  const lastOutcome = useGameStore((s) => s.lastOutcome);
  const outcomeTickRef = useRef(0);
  const shotSideRef = useRef<"leg" | "off" | "straight">("straight");

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (e.key.toLowerCase() === save.settings.keyBindings.pause || e.key === "Escape") {
        setPaused(true);
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [save.settings.keyBindings.pause, setPaused]);

  useEffect(() => {
    if (ballPhase === "showing-outcome") {
      outcomeTickRef.current += 1;
      shotSideRef.current = (["leg", "off", "straight"] as const)[Math.floor(Math.random() * 3)];
      const t = setTimeout(() => continueAfterOutcome(), 1700);
      return () => clearTimeout(t);
    }
  }, [ballPhase, continueAfterOutcome]);

  const battingColor = useMemo(() => {
    if (!match) return "#22c55e";
    const innings = match.innings[match.currentInningsIndex];
    return getTeam(innings.battingTeamId).color;
  }, [match]);
  const bowlingColor = useMemo(() => {
    if (!match) return "#ef4444";
    const innings = match.innings[match.currentInningsIndex];
    return getTeam(innings.bowlingTeamId).color;
  }, [match]);

  if (!match) return null;

  return (
    <div className="flex h-screen flex-col bg-black">
      <Scoreboard />
      <div className="relative flex-1 overflow-hidden">
        <CricketScene
          stadium={match.stadium}
          phase={ballPhase}
          outcome={lastOutcome}
          outcomeTick={outcomeTickRef.current}
          teamAColor={match.teamA.color}
          teamBColor={match.teamB.color}
          battingColor={battingColor}
          bowlingColor={bowlingColor}
          graphics={save.settings.graphics}
          shotSide={shotSideRef.current}
        />
        <OutcomeBanner />
        <button
          onClick={() => setPaused(true)}
          className="absolute right-3 top-3 z-30 flex h-10 w-10 items-center justify-center rounded-full bg-black/50 text-white hover:bg-black/70"
          aria-label="Pause"
        >
          ⏸
        </button>
        {chrome === "practice" && (
          <div className="absolute left-3 top-3 z-30 rounded bg-black/50 px-3 py-1 text-xs text-white">Practice Mode</div>
        )}
        {chrome === "challenge" && (
          <div className="absolute left-3 top-3 z-30 rounded bg-black/50 px-3 py-1 text-xs text-white">Challenge Mode</div>
        )}
      </div>
      <div className="min-h-[190px] border-t border-white/10 bg-slate-950">
        {ballPhase === "need-delivery" && <BowlingControls />}
        {ballPhase === "need-shot" && <BattingControls />}
        {(ballPhase === "showing-outcome" || ballPhase === "ready") && (
          <div className="flex h-full items-center justify-center py-8 text-sm text-slate-500">Next ball incoming…</div>
        )}
      </div>
      {ballPhase === "need-bowler-select" && <BowlerSelectModal />}
    </div>
  );
}
