import { useGameStore } from "../../state/store";
import { getPlayer, getTeam } from "../../data/teams";
import { Button, Panel, SectionTitle } from "../ui/Button";

export function MatchResult() {
  const match = useGameStore((s) => s.match);
  const goTo = useGameStore((s) => s.goTo);
  const rewardSummary = useGameStore((s) => s.rewardSummary);
  const quitToMenu = useGameStore((s) => s.quitToMenu);
  const challenge = useGameStore((s) => s.challenge);
  const tournament = useGameStore((s) => s.tournament);
  const setup = useGameStore((s) => s.setup);
  if (!match || !match.result) return null;

  const pom = getPlayer(match.result.playerOfMatchId);
  const winner = match.result.winnerTeamId ? getTeam(match.result.winnerTeamId) : null;

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-gradient-to-b from-amber-950 via-slate-950 to-black px-4 py-10 text-white">
      <div className="mb-2 text-xs uppercase tracking-[0.3em] text-amber-400">Match Result</div>
      <SectionTitle className="mb-6 text-center text-3xl">
        {winner ? `${winner.name} Win!` : "Match Tied!"}
      </SectionTitle>
      <Panel className="w-full max-w-lg p-6 text-center">
        <p className="text-lg font-semibold text-emerald-400">{match.result.summary}</p>
        <div className="mt-4 border-t border-white/10 pt-4">
          <div className="text-xs uppercase text-slate-400">Player of the Match</div>
          <div className="text-xl font-bold">{pom.displayName}</div>
        </div>
        {challenge?.finished && (
          <div className={`mt-4 rounded-lg p-3 font-bold ${challenge.success ? "bg-emerald-600/30 text-emerald-300" : "bg-rose-600/30 text-rose-300"}`}>
            Challenge {challenge.success ? "Completed!" : "Failed"} — {challenge.def.title}
          </div>
        )}
        {rewardSummary && (
          <div className="mt-4 flex justify-center gap-6 text-sm">
            <div>
              <div className="text-2xl font-black text-amber-400">+{rewardSummary.coins}</div>
              <div className="text-slate-400">Coins</div>
            </div>
            <div>
              <div className="text-2xl font-black text-sky-400">+{rewardSummary.xp}</div>
              <div className="text-slate-400">XP</div>
            </div>
            {rewardSummary.leveledUp && <div className="self-center rounded bg-purple-600/40 px-2 py-1 text-xs font-bold text-purple-200">LEVEL UP!</div>}
          </div>
        )}
      </Panel>
      <div className="mt-8 flex flex-wrap justify-center gap-3">
        <Button variant="secondary" onClick={() => goTo("scorecard")}>
          Full Scorecard
        </Button>
        {setup.mode === "tournament" && tournament.active && (
          <Button variant="primary" onClick={() => goTo("tournament")}>
            Back to Tournament
          </Button>
        )}
        <Button variant="gold" onClick={quitToMenu}>
          Main Menu
        </Button>
      </div>
    </div>
  );
}
