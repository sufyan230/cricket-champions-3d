import { useState } from "react";
import { useGameStore } from "../../state/store";
import { TEAMS, teamXI } from "../../data/teams";
import { STADIUMS } from "../../data/stadiums";
import { FORMATS, DIFFICULTIES } from "../../data/formats";
import { Difficulty } from "../../data/types";
import { Button, Panel, SectionTitle } from "../ui/Button";

type Step = "teamA" | "teamB" | "stadium" | "format" | "difficulty" | "confirm";

export function QuickMatchSetup() {
  const setup = useGameStore((s) => s.setup);
  const updateSetup = useGameStore((s) => s.updateSetup);
  const goTo = useGameStore((s) => s.goTo);
  const startTossFlow = useGameStore((s) => s.startTossFlow);
  const [step, setStep] = useState<Step>("teamA");

  const steps: Step[] = setup.localMultiplayer ? ["teamA", "teamB", "stadium", "format", "confirm"] : ["teamA", "teamB", "stadium", "format", "difficulty", "confirm"];
  const idx = steps.indexOf(step);

  function next() {
    if (idx < steps.length - 1) setStep(steps[idx + 1]);
  }
  function back() {
    if (idx > 0) setStep(steps[idx - 1]);
    else goTo("menu");
  }

  return (
    <div className="min-h-screen bg-slate-950 px-4 py-8 text-white">
      <div className="mx-auto max-w-4xl">
        <div className="mb-6 flex items-center justify-between">
          <button onClick={back} className="text-slate-400 hover:text-white">
            ← Back
          </button>
          <div className="text-xs uppercase tracking-widest text-slate-500">
            Step {idx + 1} / {steps.length}
          </div>
        </div>

        {step === "teamA" && (
          <TeamPicker
            title={setup.localMultiplayer ? "Player 1 — Choose Your Team" : "Choose Your Team"}
            selected={setup.teamAId}
            exclude={setup.teamBId}
            onPick={(id) => {
              updateSetup({ teamAId: id });
              next();
            }}
          />
        )}
        {step === "teamB" && (
          <TeamPicker
            title={setup.localMultiplayer ? "Player 2 — Choose Your Team" : "Choose Opponent"}
            selected={setup.teamBId}
            exclude={setup.teamAId}
            onPick={(id) => {
              updateSetup({ teamBId: id });
              next();
            }}
          />
        )}
        {step === "stadium" && (
          <div>
            <SectionTitle className="mb-4">Select Stadium</SectionTitle>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 md:grid-cols-3">
              {STADIUMS.map((st) => (
                <Panel
                  key={st.id}
                  className={`cursor-pointer p-4 hover:border-emerald-400 ${setup.stadiumId === st.id ? "border-emerald-400" : ""}`}
                >
                  <button className="w-full text-left" onClick={() => updateSetup({ stadiumId: st.id })}>
                    <div className="font-bold">{st.name}</div>
                    <div className="text-xs text-slate-400">{st.city}</div>
                    <div className="mt-2 flex flex-wrap gap-1 text-[10px]">
                      <span className="rounded bg-slate-800 px-2 py-0.5">{st.pitchType}</span>
                      <span className="rounded bg-slate-800 px-2 py-0.5">{st.lighting}</span>
                      <span className="rounded bg-slate-800 px-2 py-0.5">Cap {(st.capacity / 1000).toFixed(0)}k</span>
                    </div>
                    <div className="mt-1 text-[11px] text-slate-500">{st.pitchTendency}</div>
                  </button>
                </Panel>
              ))}
            </div>
            <div className="mt-6 flex justify-end">
              <Button onClick={next}>Continue</Button>
            </div>
          </div>
        )}
        {step === "format" && (
          <div>
            <SectionTitle className="mb-4">Select Format</SectionTitle>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              {Object.values(FORMATS).map((f) => (
                <Panel key={f.id} className={`cursor-pointer p-5 hover:border-emerald-400 ${setup.formatId === f.id ? "border-emerald-400" : ""}`}>
                  <button className="w-full text-left" onClick={() => updateSetup({ formatId: f.id })}>
                    <div className="text-lg font-bold">{f.name}</div>
                    <div className="text-sm text-slate-400">
                      {f.overs} overs · {f.wicketsPerInnings} wickets · Powerplay {f.powerplayOvers} ov
                    </div>
                  </button>
                </Panel>
              ))}
            </div>
            <div className="mt-6 flex justify-end">
              <Button onClick={next}>Continue</Button>
            </div>
          </div>
        )}
        {step === "difficulty" && !setup.localMultiplayer && (
          <div>
            <SectionTitle className="mb-4">Select Difficulty</SectionTitle>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              {Object.values(DIFFICULTIES).map((d) => (
                <Panel key={d.id} className={`cursor-pointer p-4 text-center hover:border-emerald-400 ${setup.difficulty === d.id ? "border-emerald-400" : ""}`}>
                  <button className="w-full" onClick={() => updateSetup({ difficulty: d.id as Difficulty })}>
                    <div className="font-bold">{d.id}</div>
                  </button>
                </Panel>
              ))}
            </div>
            <div className="mt-6 flex justify-end">
              <Button onClick={next}>Continue</Button>
            </div>
          </div>
        )}
        {step === "confirm" && (
          <div>
            <SectionTitle className="mb-4">Match Summary</SectionTitle>
            <Panel className="space-y-2 p-6">
              <SummaryRow label="Teams" value={`${TEAMS.find((t) => t.id === setup.teamAId)?.name} vs ${TEAMS.find((t) => t.id === setup.teamBId)?.name}`} />
              <SummaryRow label="Stadium" value={STADIUMS.find((s) => s.id === setup.stadiumId)?.name ?? ""} />
              <SummaryRow label="Format" value={FORMATS[setup.formatId]?.name ?? ""} />
              {!setup.localMultiplayer && <SummaryRow label="Difficulty" value={setup.difficulty} />}
            </Panel>
            <div className="mt-6 flex justify-end">
              <Button
                variant="gold"
                size="lg"
                onClick={() => {
                  goTo("toss");
                  startTossFlow();
                }}
              >
                Proceed to Toss
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function SummaryRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between border-b border-white/5 py-1 text-sm">
      <span className="text-slate-400">{label}</span>
      <span className="font-semibold">{value}</span>
    </div>
  );
}

function TeamPicker({ title, selected, exclude, onPick }: { title: string; selected: string; exclude: string; onPick: (id: string) => void }) {
  return (
    <div>
      <SectionTitle className="mb-4">{title}</SectionTitle>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-5">
        {TEAMS.filter((t) => t.id !== exclude).map((t) => {
          const xi = teamXI(t.id);
          const captain = xi.find((p) => t.captainId === p.id);
          return (
            <Panel key={t.id} className={`cursor-pointer p-4 text-center hover:border-emerald-400 ${selected === t.id ? "border-emerald-400" : ""}`}>
              <button className="w-full" onClick={() => onPick(t.id)}>
                <div className="mx-auto mb-2 h-10 w-10 rounded-full border-2 border-white/20" style={{ backgroundColor: t.color }} />
                <div className="font-bold">{t.shortName}</div>
                <div className="text-[11px] text-slate-400">{t.name}</div>
                <div className="mt-1 text-[10px] text-slate-500">C: {captain?.shortName}</div>
              </button>
            </Panel>
          );
        })}
      </div>
    </div>
  );
}
