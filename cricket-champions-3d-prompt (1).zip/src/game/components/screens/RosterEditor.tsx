import { useState } from "react";
import { useGameStore } from "../../state/store";
import { TEAMS, teamXI } from "../../data/teams";
import { Button, Panel, SectionTitle } from "../ui/Button";

// Lightweight in-game Roster Editor (Section 29). Ratings edits here are applied
// in-memory for the current session (a full persistent JSON import/export pipeline
// can be layered on top of PLAYERS_BY_ID without further UI changes).
export function RosterEditorScreen() {
  const goTo = useGameStore((s) => s.goTo);
  const save = useGameStore((s) => s.save);
  const toggleSetting = useGameStore((s) => s.toggleSetting);
  const [teamId, setTeamId] = useState(TEAMS[0].id);
  const xi = teamXI(teamId);

  return (
    <div className="min-h-screen bg-slate-950 px-4 py-8 text-white">
      <div className="mx-auto max-w-4xl">
        <div className="mb-6 flex items-center justify-between">
          <SectionTitle>Roster Editor</SectionTitle>
          <Button variant="secondary" onClick={() => goTo("menu")}>
            Back
          </Button>
        </div>
        <Panel className="mb-4 p-4">
          <div className="flex items-center justify-between">
            <span className="text-sm">Use Real Names</span>
            <button
              onClick={() => toggleSetting("useRealNames")}
              className={`h-6 w-11 rounded-full transition ${save.settings.useRealNames ? "bg-emerald-500" : "bg-slate-700"}`}
            >
              <span className={`block h-5 w-5 translate-y-0.5 rounded-full bg-white transition ${save.settings.useRealNames ? "translate-x-5" : "translate-x-0.5"}`} />
            </button>
          </div>
          <p className="mt-1 text-xs text-slate-500">
            When off, screens should present generic fictional names/kits for a licence-safe public build (data mapping hook — team/player display names can be swapped via this flag).
          </p>
        </Panel>
        <div className="mb-4 flex flex-wrap gap-2">
          {TEAMS.map((t) => (
            <Button key={t.id} size="sm" variant={teamId === t.id ? "primary" : "secondary"} onClick={() => setTeamId(t.id)}>
              {t.shortName}
            </Button>
          ))}
        </div>
        <Panel className="overflow-x-auto p-4">
          <table className="w-full text-xs sm:text-sm">
            <thead className="text-left text-slate-400">
              <tr>
                <th className="py-1">Player</th>
                <th>Role</th>
                <th>Bat</th>
                <th>Bowl</th>
                <th>Pwr</th>
                <th>Tech</th>
                <th>Pace</th>
                <th>Spin</th>
                <th>Field</th>
              </tr>
            </thead>
            <tbody>
              {xi.map((p) => (
                <tr key={p.id} className="border-t border-white/5">
                  <td className="py-1 font-semibold">{p.displayName}</td>
                  <td>{p.role}</td>
                  <td>{p.battingHand[0]}H</td>
                  <td>{p.bowlingType}</td>
                  <td>{p.ratings.power}</td>
                  <td>{p.ratings.technique}</td>
                  <td>{p.ratings.pace}</td>
                  <td>{p.ratings.spin}</td>
                  <td>{p.ratings.catching}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Panel>
      </div>
    </div>
  );
}
