import { GameRoot } from "./game/GameRoot";

export default function App() {
  return <GameRoot />;
}
